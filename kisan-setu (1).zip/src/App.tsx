import React, { useState, useEffect, useCallback } from 'react';
import { AppMode, Language, FarmerTab, Product, FarmerCrop, FarmerOrder, CartItem, EarningsSummary } from './types';
import { translations } from './translations';
import {
  CROP_OPTIONS,
  INITIAL_FARMER_CROPS,
  INITIAL_FARMER_ORDERS,
  INITIAL_EARNINGS,
  MARKETPLACE_PRODUCTS,
} from './data';
import { speakText, stopSpeaking, startSpeechRecognition } from './voice';
import { Navbar } from './components/Navbar';
import { HomeHero } from './components/HomeHero';
import { FarmerHome } from './components/FarmerHome';
import { FarmerSellingFlow } from './components/FarmerSellingFlow';
import { FarmerCropsList } from './components/FarmerCropsList';
import { FarmerOrders } from './components/FarmerOrders';
import { FarmerEarnings } from './components/FarmerEarnings';
import { FarmerBuyersList } from './components/FarmerBuyersList';
import { FarmerBottomNav } from './components/FarmerBottomNav';
import { ConsumerMarketplace } from './components/ConsumerMarketplace';
import { CartModal } from './components/CartModal';
import { PriceTransparencyModal } from './components/PriceTransparencyModal';
import { BlockchainModal } from './components/BlockchainModal';
import { KisanSathiModal } from './components/KisanSathiModal';
import { NewOrderAlertModal } from './components/NewOrderAlertModal';
import { ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // 1. Language State (Section 20: Persisted in localStorage)
  const [language, setLanguage] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('kisan_setu_lang');
      if (saved === 'en' || saved === 'hi' || saved === 'mr') {
        return saved;
      }
    }
    return 'hi'; // Default warm Hindi for Indian farmer accessibility
  });

  // Save language to localStorage on change
  useEffect(() => {
    localStorage.setItem('kisan_setu_lang', language);
    // Cancel any ongoing speech when language switches so voice remains in sync
    stopSpeaking();
    setIsSpeaking(false);
  }, [language]);

  const t = translations[language];

  // 2. Navigation State
  const [mode, setMode] = useState<AppMode>('home');
  const [farmerTab, setFarmerTab] = useState<FarmerTab>('home');

  // 3. Data State
  const [farmerCrops, setFarmerCrops] = useState<FarmerCrop[]>(INITIAL_FARMER_CROPS);
  const [farmerOrders, setFarmerOrders] = useState<FarmerOrder[]>(INITIAL_FARMER_ORDERS);
  const [earnings, setEarnings] = useState<EarningsSummary>(INITIAL_EARNINGS);
  const [marketplaceProducts, setMarketplaceProducts] = useState<Product[]>(MARKETPLACE_PRODUCTS);

  // 4. Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // 5. Modals State
  const [selectedProductForHistory, setSelectedProductForHistory] = useState<Product | null>(null);
  const [isPriceTransparencyOpen, setIsPriceTransparencyOpen] = useState<boolean>(false);
  const [isKisanSathiOpen, setIsKisanSathiOpen] = useState<boolean>(false);
  const [isOrderAlertOpen, setIsOrderAlertOpen] = useState<boolean>(false);
  const [alertOrder, setAlertOrder] = useState<FarmerOrder | null>(null);

  // 6. Voice & Audio State
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isListeningVoiceSearch, setIsListeningVoiceSearch] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // 7. Toast Feedback State
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'info' | 'error'>('success');

  const showToast = useCallback((msg: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  }, []);

  // Voice narration handler for active screen
  const handleToggleGlobalVoice = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    let summaryText = "";
    if (mode === 'home') {
      summaryText = `${t.appName}. ${t.tagline}. ${t.heroTitleFarmer} ${t.heroTitleConsumer}`;
    } else if (mode === 'farmer') {
      if (farmerTab === 'home') {
        const pendingCount = farmerOrders.filter((o) => o.status === 'pending').length;
        summaryText = `${t.farmerGreeting}. ${t.earningsToday}: ₹${earnings.today}. ${t.earningsThisWeek}: ₹${earnings.thisWeek}. ${pendingCount} ${t.newOrder}. ${t.farmerMainAction}`;
      } else if (farmerTab === 'sell') {
        summaryText = `${t.sellingStep1Title}. ${t.sellingStep1Sub}`;
      } else if (farmerTab === 'crops') {
        summaryText = `${t.activeCropsTitle}. ${farmerCrops.length} ${t.itemsCount}`;
      } else if (farmerTab === 'orders') {
        summaryText = `${t.ordersTitle}. ${farmerOrders.filter((o) => o.status === 'pending').length} ${t.newOrder}`;
      } else if (farmerTab === 'earnings') {
        summaryText = `${t.earningsTitle}. ${t.earningsTotal}: ₹${earnings.total}`;
      }
    } else if (mode === 'consumer') {
      summaryText = `${t.consumerGreeting}. ${t.consumerQuestion}. ${t.freshNearYou}`;
    }

    speakText(
      summaryText,
      language,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      (errMsg) => {
        setIsSpeaking(false);
        showToast(errMsg, 'error');
      }
    );
  };

  const handleSpeakCustomText = (text: string) => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    speakText(
      text,
      language,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      (errMsg) => {
        setIsSpeaking(false);
        showToast(errMsg, 'error');
      }
    );
  };

  // Voice search helper (Section 22)
  const handleStartVoiceSearch = () => {
    if (isListeningVoiceSearch) return;

    setIsListeningVoiceSearch(true);
    startSpeechRecognition(
      language,
      (transcript) => {
        setSearchQuery(transcript);
        setIsListeningVoiceSearch(false);
        showToast(`🔍 "${transcript}"`, 'info');
      },
      (err) => {
        setIsListeningVoiceSearch(false);
        showToast(err, 'error');
      },
      () => {
        setIsListeningVoiceSearch(false);
      }
    );
  };

  // Cart operations (Section 28)
  const handleAddToCart = (product: Product, quantity: number) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(t.addedToBasketToast, 'success');
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleCheckoutComplete = () => {
    // Also create a pending order for farmer Ramesh if Tomato or Onion purchased
    const farmerItem = cart.find((c) => c.product.farmerName.includes('Ramesh'));
    if (farmerItem) {
      const newOrder: FarmerOrder = {
        id: `ord-${Date.now()}`,
        buyerName: 'Priya Sharma',
        buyerLocation: 'Kothrud, Pune',
        cropName: t[farmerItem.product.nameKey as keyof typeof t] as string || farmerItem.product.nameDefault,
        cropEmoji: farmerItem.product.emoji,
        quantity: farmerItem.quantity,
        unit: 'kg',
        totalPrice: farmerItem.product.pricePerKg * farmerItem.quantity,
        pricePerUnit: farmerItem.product.pricePerKg,
        status: 'pending',
        time: 'Just now',
        orderDate: 'Today',
      };
      setFarmerOrders((prev) => [newOrder, ...prev]);
      setAlertOrder(newOrder);
      setIsOrderAlertOpen(true);
    }

    setCart([]);
    showToast(t.orderPlacedTitle, 'success');
  };

  // Farmer operations
  const handleFarmerAddCrop = (newCrop: FarmerCrop) => {
    setFarmerCrops((prev) => [newCrop, ...prev]);

    // Also inject into marketplace products so consumers can purchase it
    const newMarketProduct: Product = {
      id: `prod-${Date.now()}`,
      nameKey: newCrop.cropId ? `crop${newCrop.cropId.charAt(0).toUpperCase() + newCrop.cropId.slice(1)}` : 'cropVegetables',
      nameDefault: newCrop.name,
      emoji: newCrop.emoji,
      pricePerKg: newCrop.pricePerUnit,
      farmerName: 'Ramesh Patil',
      farmerLocation: 'Wagholi, Pune',
      distanceKm: 4.2,
      availableKg: newCrop.quantity,
      isVerified: true,
      category: 'vegetable',
      image: newCrop.image,
      harvestDate: 'Today, Just listed',
      batchId: `KS-PUN-${Date.now().toString().slice(-4)}`,
      soilTested: true,
    };
    setMarketplaceProducts((prev) => [newMarketProduct, ...prev]);
    showToast(t.listingSuccessTitle, 'success');
  };

  const handleToggleCropStatus = (cropId: string) => {
    setFarmerCrops((prev) =>
      prev.map((c) =>
        c.id === cropId
          ? { ...c, status: c.status === 'active' ? 'sold_out' : 'active' }
          : c
      )
    );
  };

  const handleAcceptOrder = (orderId: string) => {
    const order = farmerOrders.find((o) => o.id === orderId);
    if (!order) return;

    setFarmerOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'accepted' } : o))
    );

    // Update earnings
    setEarnings((prev) => ({
      today: prev.today + order.totalPrice,
      thisWeek: prev.thisWeek + order.totalPrice,
      total: prev.total + order.totalPrice,
      recentPayouts: [
        {
          id: `p-${Date.now()}`,
          buyerName: order.buyerName,
          crop: `${order.cropName} (${order.quantity} ${order.unit})`,
          amount: order.totalPrice,
          date: 'Just now',
        },
        ...prev.recentPayouts,
      ],
    }));

    showToast(t.orderAcceptedToast, 'success');
  };

  const handleRejectOrder = (orderId: string) => {
    setFarmerOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'rejected' } : o))
    );
    showToast(t.orderRejectedToast, 'info');
  };

  // Real-world alert simulation (allows instant testing in the hackathon prototype)
  const handleSimulateOrderAlert = () => {
    const demoAlertOrder: FarmerOrder = {
      id: `ord-demo-${Date.now()}`,
      buyerName: 'Priya Sharma',
      buyerLocation: 'Kothrud, Pune (6.2 km)',
      cropName: language === 'hi' ? 'ताज़ा टमाटर' : language === 'mr' ? 'ताजा टोमॅटो' : 'Fresh Tomatoes',
      cropEmoji: '🍅',
      quantity: 10,
      unit: 'kg',
      totalPrice: 240,
      pricePerUnit: 24,
      status: 'pending',
      time: 'Just now',
      orderDate: 'Today',
    };
    setFarmerOrders((prev) => [demoAlertOrder, ...prev]);
    setAlertOrder(demoAlertOrder);
    setIsOrderAlertOpen(true);
  };

  const handleAcceptOrderFromAlert = (orderId: string) => {
    handleAcceptOrder(orderId);
    setIsOrderAlertOpen(false);
  };

  const handleReviewOrderFromAlert = (orderId: string) => {
    setIsOrderAlertOpen(false);
    setMode('farmer');
    setFarmerTab('orders');
  };

  const pendingOrdersCount = farmerOrders.filter((o) => o.status === 'pending').length;
  const cartTotalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-stone-900 flex flex-col selection:bg-emerald-200">
      
      {/* Universal Top Navigation */}
      <Navbar
        mode={mode}
        onSelectMode={(newMode) => {
          setMode(newMode);
          if (newMode === 'farmer') setFarmerTab('home');
        }}
        language={language}
        onSelectLanguage={setLanguage}
        cartCount={cartTotalItems}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenPriceTransparency={() => setIsPriceTransparencyOpen(true)}
        onOpenKisanSathi={() => setIsKisanSathiOpen(true)}
        isSpeaking={isSpeaking}
        onToggleVoice={handleToggleGlobalVoice}
      />

      {/* Floating Toast Feedback */}
      {toastMessage && (
        <div
          id="global-toast-notification"
          className={`fixed top-20 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs sm:text-sm font-bold animate-in fade-in slide-in-from-top-4 duration-200 ${
            toastType === 'success'
              ? 'bg-emerald-800 text-white border-emerald-900'
              : toastType === 'error'
              ? 'bg-red-700 text-white border-red-800'
              : 'bg-stone-900 text-white border-stone-800'
          }`}
        >
          {toastType === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-300" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-300" />
          )}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main View Container */}
      <main className="flex-1 pb-24 md:pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full pt-4">
        
        {/* VIEW 1: Landing / Homepage */}
        {mode === 'home' && (
          <HomeHero
            language={language}
            onSelectFarmer={() => {
              setMode('farmer');
              setFarmerTab('home');
            }}
            onSelectConsumer={() => setMode('consumer')}
            onOpenPriceTransparency={() => setIsPriceTransparencyOpen(true)}
            onOpenKisanSathi={() => setIsKisanSathiOpen(true)}
            onSpeakWelcome={handleToggleGlobalVoice}
            isSpeaking={isSpeaking}
          />
        )}

        {/* VIEW 2: Farmer Mode (Highest Priority) */}
        {mode === 'farmer' && (
          <div className="space-y-6">
            
            {/* Desktop / Tablet Sub-navigation header for Farmer */}
            <div className="hidden md:flex items-center justify-between bg-white p-3.5 rounded-2xl border border-stone-200 shadow-2xs max-w-4xl mx-auto">
              <div className="flex items-center gap-2">
                <button
                  id="farmer-subnav-home"
                  type="button"
                  onClick={() => setFarmerTab('home')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'home' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  🏠 {t.home}
                </button>
                <button
                  id="farmer-subnav-sell"
                  type="button"
                  onClick={() => setFarmerTab('sell')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'sell' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  🌾 {t.sellMyCrop}
                </button>
                <button
                  id="farmer-subnav-crops"
                  type="button"
                  onClick={() => setFarmerTab('crops')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'crops' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  🌱 {t.myCrops} ({farmerCrops.length})
                </button>
                <button
                  id="farmer-subnav-orders"
                  type="button"
                  onClick={() => setFarmerTab('orders')}
                  className={`relative px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'orders' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  📦 {t.myOrders}
                  {pendingOrdersCount > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-black">
                      {pendingOrdersCount}
                    </span>
                  )}
                </button>
                <button
                  id="farmer-subnav-earnings"
                  type="button"
                  onClick={() => setFarmerTab('earnings')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'earnings' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  💰 {t.myEarnings}
                </button>
                <button
                  id="farmer-subnav-buyers"
                  type="button"
                  onClick={() => setFarmerTab('buyers')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    farmerTab === 'buyers' ? 'bg-emerald-700 text-white' : 'text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  📍 {t.findBuyersTitle}
                </button>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-stone-500">
                  👨‍🌾 Ramesh Patil
                </span>
                <span className="text-xs text-emerald-800 font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                  {t.verifiedFarmer}
                </span>
              </div>
            </div>

            {/* Farmer Sub-Tabs */}
            {farmerTab === 'home' && (
              <FarmerHome
                language={language}
                earnings={earnings}
                pendingOrdersCount={pendingOrdersCount}
                activeCropsCount={farmerCrops.filter((c) => c.status === 'active').length}
                onNavigateTab={(tab) => setFarmerTab(tab)}
                onOpenKisanSathi={() => setIsKisanSathiOpen(true)}
                onSpeakSummary={handleToggleGlobalVoice}
                onSimulateOrderAlert={handleSimulateOrderAlert}
                isSpeaking={isSpeaking}
              />
            )}

            {farmerTab === 'sell' && (
              <FarmerSellingFlow
                language={language}
                onListingComplete={handleFarmerAddCrop}
                onGoBack={() => setFarmerTab('home')}
                onViewMyCrops={() => setFarmerTab('crops')}
                onSpeakStep={handleSpeakCustomText}
                isSpeaking={isSpeaking}
              />
            )}

            {farmerTab === 'crops' && (
              <FarmerCropsList
                language={language}
                crops={farmerCrops}
                onAddNewCrop={() => setFarmerTab('sell')}
                onToggleStatus={handleToggleCropStatus}
                onGoBack={() => setFarmerTab('home')}
              />
            )}

            {farmerTab === 'orders' && (
              <FarmerOrders
                language={language}
                orders={farmerOrders}
                onAcceptOrder={handleAcceptOrder}
                onRejectOrder={handleRejectOrder}
                onGoBack={() => setFarmerTab('home')}
              />
            )}

            {farmerTab === 'earnings' && (
              <FarmerEarnings
                language={language}
                earnings={earnings}
                onGoBack={() => setFarmerTab('home')}
              />
            )}

            {farmerTab === 'buyers' && (
              <FarmerBuyersList
                language={language}
                onGoBack={() => setFarmerTab('home')}
              />
            )}

            {/* Mobile Bottom Navigation for Farmer Mode */}
            <FarmerBottomNav
              language={language}
              activeTab={farmerTab}
              onSelectTab={setFarmerTab}
              pendingOrdersCount={pendingOrdersCount}
            />

          </div>
        )}

        {/* VIEW 3: Consumer Marketplace */}
        {mode === 'consumer' && (
          <ConsumerMarketplace
            language={language}
            products={marketplaceProducts}
            onAddToCart={handleAddToCart}
            onOpenProductHistory={(prod) => setSelectedProductForHistory(prod)}
            onOpenPriceTransparency={() => setIsPriceTransparencyOpen(true)}
            onStartVoiceSearch={handleStartVoiceSearch}
            isListeningVoiceSearch={isListeningVoiceSearch}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            cartCount={cartTotalItems}
            onOpenCart={() => setIsCartOpen(true)}
          />
        )}

      </main>

      {/* Cart Drawer / Modal */}
      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        language={language}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckoutComplete={handleCheckoutComplete}
      />

      {/* New Order Alert Modal (High urgency notification for farmer with audio + speech) */}
      {alertOrder && (
        <NewOrderAlertModal
          language={language}
          order={alertOrder}
          isOpen={isOrderAlertOpen}
          onClose={() => setIsOrderAlertOpen(false)}
          onAcceptOrder={handleAcceptOrderFromAlert}
          onReviewDetails={handleReviewOrderFromAlert}
        />
      )}

      {/* Price Transparency Modal */}
      <PriceTransparencyModal
        isOpen={isPriceTransparencyOpen}
        onClose={() => setIsPriceTransparencyOpen(false)}
        language={language}
      />

      {/* Blockchain Provenance Traceability Modal */}
      <BlockchainModal
        isOpen={!!selectedProductForHistory}
        onClose={() => setSelectedProductForHistory(null)}
        language={language}
        product={selectedProductForHistory}
      />

      {/* Kisan Sathi AI Companion Modal */}
      <KisanSathiModal
        isOpen={isKisanSathiOpen}
        onClose={() => setIsKisanSathiOpen(false)}
        language={language}
        onSpeakText={handleSpeakCustomText}
        isSpeaking={isSpeaking}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-stone-200/80 bg-white py-6 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 font-bold text-stone-700">
            <span>🌾 {t.appName}</span>
            <span>•</span>
            <span>{t.tagline}</span>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setIsPriceTransparencyOpen(true)}
              className="hover:text-emerald-800 cursor-pointer"
            >
              {t.priceBreakdownLink}
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => setIsKisanSathiOpen(true)}
              className="hover:text-emerald-800 cursor-pointer"
            >
              {t.kisanSathiTitle}
            </button>
            <span>•</span>
            <span className="text-stone-400">
              Pune, Maharashtra • {t.demoBadge}
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
}
