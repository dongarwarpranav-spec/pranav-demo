export type Language = 'en' | 'hi' | 'mr';

export type AppMode = 'home' | 'farmer' | 'consumer';

export type FarmerTab = 'home' | 'sell' | 'crops' | 'orders' | 'earnings' | 'buyers';

export interface NearbyBuyer {
  id: string;
  name: string;
  businessType: string;
  location: string;
  distanceKm: number;
  cropNeeded: string;
  cropEmoji: string;
  quantityNeeded: number;
  unit: string;
  offeredPrice: number;
  phone: string;
  verified: boolean;
  urgency: 'urgent' | 'regular' | 'weekly';
}

export interface CropOption {
  id: string;
  nameKey: string;
  emoji: string;
  defaultPrice: number;
  benchmarkMin: number;
  benchmarkMax: number;
  category: 'vegetable' | 'fruit' | 'grain' | 'dairy';
  image: string;
}

export interface FarmerCrop {
  id: string;
  cropId: string;
  name: string;
  emoji: string;
  quantity: number;
  unit: string;
  pricePerUnit: number;
  dateListed: string;
  status: 'active' | 'sold_out';
  image: string;
}

export interface FarmerOrder {
  id: string;
  buyerName: string;
  buyerLocation: string;
  cropName: string;
  cropEmoji: string;
  quantity: number;
  unit: string;
  totalPrice: number;
  pricePerUnit: number;
  status: 'pending' | 'accepted' | 'rejected' | 'delivered';
  time: string;
  orderDate: string;
}

export interface Product {
  id: string;
  nameKey: string;
  nameDefault: string;
  emoji: string;
  pricePerKg: number;
  farmerName: string;
  farmerLocation: string;
  distanceKm: number;
  availableKg: number;
  isVerified: boolean;
  category: 'vegetable' | 'fruit' | 'grain' | 'dairy';
  image: string;
  harvestDate: string;
  batchId: string;
  soilTested: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface EarningsSummary {
  today: number;
  thisWeek: number;
  total: number;
  recentPayouts: {
    id: string;
    buyerName: string;
    crop: string;
    amount: number;
    date: string;
  }[];
}
