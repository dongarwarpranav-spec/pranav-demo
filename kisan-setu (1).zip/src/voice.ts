import { Language } from './types';

// Speech synthesis helper
let currentUtterance: SpeechSynthesisUtterance | null = null;

export function isSpeechSynthesisAvailable(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function stopSpeaking(): void {
  if (isSpeechSynthesisAvailable()) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
  currentUtterance = null;
}

export function getVoiceForLanguage(lang: Language): SpeechSynthesisVoice | null {
  if (!isSpeechSynthesisAvailable()) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) return null;

  const targetLangCode = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
  const prefix = lang === 'hi' ? 'hi' : lang === 'mr' ? 'mr' : 'en';

  // 1. Exact match (e.g., hi-IN)
  let matched = voices.find((v) => v.lang.toLowerCase() === targetLangCode.toLowerCase());
  if (matched) return matched;

  // 2. Starts with language prefix (e.g., hi, mr, en)
  matched = voices.find((v) => v.lang.toLowerCase().startsWith(prefix));
  if (matched) return matched;

  // 3. Name includes Hindi or Marathi
  if (lang === 'hi') {
    matched = voices.find((v) => v.name.toLowerCase().includes('hindi'));
    if (matched) return matched;
  }
  if (lang === 'mr') {
    matched = voices.find((v) => v.name.toLowerCase().includes('marathi') || v.name.toLowerCase().includes('hindi'));
    if (matched) return matched;
  }

  // Fallback to Indian English or first voice
  matched = voices.find((v) => v.lang.toLowerCase().includes('in'));
  return matched || voices[0] || null;
}

export function speakText(
  text: string,
  lang: Language,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (msg: string) => void
): boolean {
  if (!isSpeechSynthesisAvailable()) {
    if (onError) onError("Voice is not available on this device.");
    return false;
  }

  try {
    stopSpeaking();

    // Clean text of emojis and special characters for clearer synthesis
    const cleanText = text.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '').trim();

    if (!cleanText) {
      if (onEnd) onEnd();
      return true;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    currentUtterance = utterance;

    const langCode = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
    utterance.lang = langCode;

    const chosenVoice = getVoiceForLanguage(lang);
    if (chosenVoice) {
      utterance.voice = chosenVoice;
    }

    utterance.rate = 0.95; // slightly relaxed natural speed for agricultural comprehension
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      if (onStart) onStart();
    };

    utterance.onend = () => {
      currentUtterance = null;
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      currentUtterance = null;
      if (e.error !== 'canceled') {
        if (onError) onError("Could not play audio. Please try again.");
      }
      if (onEnd) onEnd();
    };

    window.speechSynthesis.speak(utterance);
    return true;
  } catch (err) {
    if (onError) onError("Voice is not available on this device.");
    return false;
  }
}

// Web Speech API for voice search
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type SpeechRecognitionInstance = any;

export function isSpeechRecognitionAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  return 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;
}

export function startSpeechRecognition(
  lang: Language,
  onResult: (transcript: string) => void,
  onError: (errorMsg: string) => void,
  onEnd?: () => void
): SpeechRecognitionInstance | null {
  if (!isSpeechRecognitionAvailable()) {
    onError("Voice search is not supported on this browser.");
    return null;
  }

  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    const langCode = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
    recognition.lang = langCode;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      if (event.results && event.results.length > 0 && event.results[0][0]) {
        const transcript = event.results[0][0].transcript;
        onResult(transcript);
      }
    };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onerror = (event: any) => {
      if (event.error === 'not-allowed') {
        onError("Microphone permission was denied.");
      } else if (event.error === 'no-speech') {
        onError("No speech was detected. Please try again.");
      } else {
        onError("Could not recognize voice. Please try again.");
      }
      if (onEnd) onEnd();
    };

    recognition.onend = () => {
      if (onEnd) onEnd();
    };

    recognition.start();
    return recognition;
  } catch (err) {
    onError("Could not start microphone.");
    return null;
  }
}

// Audio chime for new order notification using Web Audio API
export function playOrderAlertChime(): void {
  if (typeof window === 'undefined') return;
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // First tone (pleasant warm tone)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.25, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.3);

    // Second tone (higher cheerful tone)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, now + 0.18); // A5
    gain2.gain.setValueAtTime(0.25, now + 0.18);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.18);
    osc2.stop(now + 0.65);
  } catch {
    // ignore audio restriction
  }
}

