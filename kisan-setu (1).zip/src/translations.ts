import { Language } from './types';

export interface Translations {
  // Common & Branding
  appName: string;
  tagline: string;
  subtitle: string;
  demoBadge: string;
  prototypeBadge: string;
  verifiedFarmer: string;
  languageSelect: string;
  back: string;
  home: string;
  continueBtn: string;
  cancel: string;
  confirm: string;
  close: string;
  loading: string;
  errorGeneric: string;
  errorInternet: string;
  
  // Voice
  listenText: string;
  speakingText: string;
  stopListening: string;
  voiceUnavailable: string;
  speakToSearch: string;
  listeningNow: string;
  voiceSearchPrompt: string;
  
  // Homepage
  heroTitleFarmer: string;
  heroTitleConsumer: string;
  heroTagline: string;
  sellMyCrop: string;
  buyFresh: string;
  heroSubtext: string;
  switchRolePrompt: string;
  fairDirectSimple: string;
  pillar1Title: string;
  pillar1Desc: string;
  pillar2Title: string;
  pillar2Desc: string;
  pillar3Title: string;
  pillar3Desc: string;
  
  // Farmer Dashboard
  farmerGreeting: string;
  farmerQuestion: string;
  farmerMainAction: string;
  farmerMainActionSub: string;
  myCrops: string;
  myOrders: string;
  myEarnings: string;
  earningsToday: string;
  earningsThisWeek: string;
  earningsTotal: string;
  quickActions: string;
  kisanSathiHelp: string;
  kisanSathiTagline: string;
  
  // Farmer Selling Flow
  sellingStep1Title: string;
  sellingStep1Sub: string;
  sellingStep2Title: string;
  sellingStep2Sub: string;
  sellingStep3Title: string;
  sellingStep3Sub: string;
  sellingStep4Title: string;
  sellingStep4Sub: string;
  cropSelected: string;
  quantityLabel: string;
  unitKg: string;
  priceLabel: string;
  nearbyBenchmark: string;
  benchmarkDemoNote: string;
  confirmSellBtn: string;
  listingSuccessTitle: string;
  listingSuccessDesc: string;
  viewMyCropsBtn: string;
  goHomeBtn: string;
  otherCrop: string;
  enterCropName: string;
  
  // Farmer Orders
  ordersTitle: string;
  newOrder: string;
  buyerLabel: string;
  locationLabel: string;
  acceptOrderBtn: string;
  rejectOrderBtn: string;
  orderAcceptedToast: string;
  orderRejectedToast: string;
  acceptedStatus: string;
  rejectedStatus: string;
  noOrdersYet: string;
  noOrdersSub: string;
  
  // Farmer Crops List
  activeCropsTitle: string;
  availableStock: string;
  pricePerKgLabel: string;
  addNewCropBtn: string;
  noCropsYet: string;
  noCropsSub: string;
  markSoldOut: string;
  markActive: string;
  
  // Farmer Earnings Detail
  earningsTitle: string;
  payoutHistoryTitle: string;
  directToBank: string;
  paymentReceived: string;
  
  // Consumer Marketplace
  consumerGreeting: string;
  consumerQuestion: string;
  searchPlaceholder: string;
  locationCity: string;
  freshNearYou: string;
  categoryAll: string;
  categoryVegetables: string;
  categoryFruits: string;
  categoryGrains: string;
  categoryDairy: string;
  perKg: string;
  distanceAway: string;
  addToBasket: string;
  addedToBasketToast: string;
  noCropsFound: string;
  tryAnotherSearch: string;
  viewProductHistory: string;
  priceBreakdownLink: string;
  
  // Basket & Checkout
  basketTitle: string;
  basketEmptyTitle: string;
  basketEmptySub: string;
  startShoppingBtn: string;
  itemsCount: string;
  orderSummary: string;
  subtotal: string;
  deliveryFee: string;
  deliveryFree: string;
  totalAmount: string;
  deliveryAddress: string;
  addressPlaceholder: string;
  checkoutBtn: string;
  orderPlacedTitle: string;
  orderPlacedDesc: string;
  continueShoppingBtn: string;
  
  // Kisan Sathi (AI Assistant)
  kisanSathiTitle: string;
  kisanSathiWelcome: string;
  kisanSathiPrompt1: string;
  kisanSathiPrompt2: string;
  kisanSathiPrompt3: string;
  kisanSathiPrompt4: string;
  kisanSathiAnswer1: string;
  kisanSathiAnswer2: string;
  kisanSathiAnswer3: string;
  kisanSathiAnswer4: string;
  kisanSathiCustomPrompt: string;
  askSathiBtn: string;
  
  // Price Transparency
  transparencyTitle: string;
  transparencySub: string;
  traditionalChain: string;
  kisanSetuChain: string;
  illustrativeNote: string;
  middlemanCostTitle: string;
  middlemanCostDesc: string;
  directGainTitle: string;
  directGainDesc: string;
  
  // Blockchain / Trust Modal
  blockchainTitle: string;
  blockchainSub: string;
  batchIdLabel: string;
  harvestDateLabel: string;
  farmOriginLabel: string;
  qualityCheckLabel: string;
  dispatchLabel: string;
  testedSafe: string;
  directFromFarm: string;
  blockchainDemoNotice: string;
  
  // Crop Names
  cropTomato: string;
  cropOnion: string;
  cropPotato: string;
  cropMango: string;
  cropWheat: string;
  cropVegetables: string;
  cropSpinach: string;
  cropMilk: string;
  cropBanana: string;

  // Sell in 60 Seconds
  sellIn60SecondsTitle: string;
  sellIn60SecondsSub: string;
  step1Visual: string;
  step2Visual: string;
  step3Visual: string;
  step4Visual: string;
  start60sSell: string;
  readyToSellPrompt: string;
  buyersCanSeeCropNow: string;

  // Simple Crop Price Guidance
  priceGuidanceTitle: string;
  priceGuidanceSub: string;
  nearbyFarmersRange: string;
  suggestedRange: string;
  useSuggestedPriceBtn: string;
  priceGuidanceDemoNote: string;

  // Find Nearby Buyers
  findBuyersTitle: string;
  findBuyersSub: string;
  viewBuyerBtn: string;
  contactBuyerBtn: string;
  callNowBtn: string;
  whatsappMessageBtn: string;
  demoBuyerBadge: string;
  neededQuantityLabel: string;
  offeredRateLabel: string;
  urgencyUrgentLabel: string;
  urgencyRegularLabel: string;
  urgencyWeeklyLabel: string;
  buyerDetailsTitle: string;
  buyerContactPrompt: string;

  // New Order Alert
  newOrderAlertTitle: string;
  newOrderAlertSub: string;
  simulateOrderAlertBtn: string;
  testAlertSoundNote: string;
  orderChimeSpeech: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: "Kisan Setu",
    tagline: "Simple. Fair. Direct.",
    subtitle: "Direct Farmer-to-Consumer Marketplace",
    demoBadge: "Demo",
    prototypeBadge: "Prototype",
    verifiedFarmer: "Verified Farmer",
    languageSelect: "Language / भाषा",
    back: "Back",
    home: "Home",
    continueBtn: "Continue",
    cancel: "Cancel",
    confirm: "Confirm",
    close: "Close",
    loading: "Loading...",
    errorGeneric: "Something went wrong. Please try again.",
    errorInternet: "Please check your internet connection.",
    
    listenText: "Listen",
    speakingText: "Speaking...",
    stopListening: "Stop",
    voiceUnavailable: "Voice is not available on this device.",
    speakToSearch: "Speak to search",
    listeningNow: "Listening... speak now",
    voiceSearchPrompt: "Say crop name like 'Tomato' or 'Wheat'",
    
    heroTitleFarmer: "Sell your crops directly.",
    heroTitleConsumer: "Buy fresh produce directly from farmers.",
    heroTagline: "Simple. Fair. Direct.",
    sellMyCrop: "Sell My Crop",
    buyFresh: "Buy Fresh",
    heroSubtext: "Connecting hard-working Indian farmers directly with local consumers. No middlemen, transparent prices, guaranteed freshness.",
    switchRolePrompt: "Are you a farmer or consumer?",
    fairDirectSimple: "Your crop. Your price. Your buyer.",
    pillar1Title: "Direct Profits for Farmers",
    pillar1Desc: "Keep 100% of your listed price. No commission cuts or unfair mandi deductions.",
    pillar2Title: "Farm-Fresh for Consumers",
    pillar2Desc: "Harvested today and delivered directly to your doorstep from nearby farms.",
    pillar3Title: "Transparent & Honest",
    pillar3Desc: "Know exactly who grew your food and where every single rupee goes.",
    
    farmerGreeting: "Namaste, Ramesh Patil! 👋",
    farmerQuestion: "What would you like to do today?",
    farmerMainAction: "Sell My Crop",
    farmerMainActionSub: "List new produce in 3 simple steps",
    myCrops: "My Crops",
    myOrders: "My Orders",
    myEarnings: "My Earnings",
    earningsToday: "Today",
    earningsThisWeek: "This Week",
    earningsTotal: "Total Payout",
    quickActions: "Quick Actions",
    kisanSathiHelp: "Kisan Sathi Voice Help",
    kisanSathiTagline: "Ask questions in Hindi, Marathi, or English",
    
    sellingStep1Title: "What are you selling?",
    sellingStep1Sub: "Tap your crop or select other",
    sellingStep2Title: "How much do you have?",
    sellingStep2Sub: "Set available quantity in kilograms",
    sellingStep3Title: "What price do you want?",
    sellingStep3Sub: "Set your fair price per kilogram",
    sellingStep4Title: "Ready to sell?",
    sellingStep4Sub: "Review your listing before publishing",
    cropSelected: "Selected Crop",
    quantityLabel: "Quantity",
    unitKg: "kg",
    priceLabel: "Price per kg",
    nearbyBenchmark: "Nearby listings: ₹22–₹28/kg",
    benchmarkDemoNote: "Based on recent local farmer listings (Demo benchmark)",
    confirmSellBtn: "Sell My Crop",
    listingSuccessTitle: "🎉 Crop listed!",
    listingSuccessDesc: "Your crop is now available to buyers across Pune & nearby areas.",
    viewMyCropsBtn: "View My Crops",
    goHomeBtn: "Go Home",
    otherCrop: "Other Crop",
    enterCropName: "Enter crop name",
    
    ordersTitle: "Incoming Orders",
    newOrder: "New Order",
    buyerLabel: "Buyer",
    locationLabel: "Location",
    acceptOrderBtn: "Accept Order",
    rejectOrderBtn: "Reject",
    orderAcceptedToast: "🎉 Order accepted! Prepare for pickup.",
    orderRejectedToast: "Order declined.",
    acceptedStatus: "Accepted",
    rejectedStatus: "Declined",
    noOrdersYet: "No orders yet.",
    noOrdersSub: "Your new orders will appear here as soon as buyers purchase.",
    
    activeCropsTitle: "My Listed Crops",
    availableStock: "In stock",
    pricePerKgLabel: "Price",
    addNewCropBtn: "+ List Another Crop",
    noCropsYet: "No crops added yet.",
    noCropsSub: "Start selling by listing your first harvest.",
    markSoldOut: "Mark Sold",
    markActive: "Mark Available",
    
    earningsTitle: "My Earnings",
    payoutHistoryTitle: "Recent Direct Payments",
    directToBank: "Direct Bank Transfer (Demo)",
    paymentReceived: "Payment received!",
    
    consumerGreeting: "Good morning 👋",
    consumerQuestion: "What are you looking for today?",
    searchPlaceholder: "Search vegetables, fruits, grains...",
    locationCity: "Pune, Maharashtra",
    freshNearYou: "Fresh near you",
    categoryAll: "All",
    categoryVegetables: "Vegetables",
    categoryFruits: "Fruits",
    categoryGrains: "Grains",
    categoryDairy: "Dairy",
    perKg: "/ kg",
    distanceAway: "away",
    addToBasket: "Add to Basket",
    addedToBasketToast: "Added to your basket! 🛒",
    noCropsFound: "No crops found.",
    tryAnotherSearch: "Try another search keyword or clear category filter.",
    viewProductHistory: "View Product History",
    priceBreakdownLink: "See price transparency",
    
    basketTitle: "Your Basket",
    basketEmptyTitle: "Your basket is empty.",
    basketEmptySub: "Explore fresh crops harvested directly by local farmers.",
    startShoppingBtn: "Start Shopping",
    itemsCount: "items",
    orderSummary: "Order Summary",
    subtotal: "Subtotal",
    deliveryFee: "Delivery",
    deliveryFree: "FREE",
    totalAmount: "Total Amount",
    deliveryAddress: "Delivery Address",
    addressPlaceholder: "Flat/House no., street, area, Pune",
    checkoutBtn: "Place Direct Order",
    orderPlacedTitle: "🌱 Your order has been placed!",
    orderPlacedDesc: "Farmer Ramesh has received your order and will pack freshly harvested produce for you.",
    continueShoppingBtn: "Continue Shopping",
    
    kisanSathiTitle: "Kisan Sathi",
    kisanSathiWelcome: "Namaste! Speak or tap an option below, I am here to help you sell smoothly.",
    kisanSathiPrompt1: "💰 Check crop price",
    kisanSathiPrompt2: "📍 Find buyers",
    kisanSathiPrompt3: "🌾 Help me sell",
    kisanSathiPrompt4: "📦 Check my order",
    kisanSathiAnswer1: "Current wholesale mandi benchmark in Pune is ₹22–₹26/kg for Tomato and ₹18–₹24/kg for Onion. On Kisan Setu, farmers earn ₹25–₹30/kg directly!",
    kisanSathiAnswer2: "There are currently 48 active buyers looking for fresh vegetables within 10 km in Pune and Wagholi.",
    kisanSathiAnswer3: "To sell: 1) Tap 'Sell My Crop', 2) Choose your crop, 3) Select quantity, 4) Confirm your price. It takes less than 30 seconds!",
    kisanSathiAnswer4: "You have 1 pending order from Aisha in Pune for 20 kg Tomatoes at ₹600. Tap 'Accept Order' to confirm!",
    kisanSathiCustomPrompt: "Ask any farming or selling question...",
    askSathiBtn: "Ask",
    
    transparencyTitle: "Price Transparency",
    transparencySub: "See where every rupee goes when you buy from Kisan Setu",
    traditionalChain: "Traditional Middleman Chain",
    kisanSetuChain: "Kisan Setu Direct Chain",
    illustrativeNote: "Illustrative example based on 1 kg Tomatoes (Market Demo)",
    middlemanCostTitle: "Middlemen take up to 60%",
    middlemanCostDesc: "Farmer gets ₹12 → Commission Agent ₹4 → Transport ₹5 → Wholesaler ₹6 → Retailer ₹8 → Consumer pays ₹35.",
    directGainTitle: "Farmer gets 85%+ directly",
    directGainDesc: "Farmer gets ₹24 direct → Kisan Setu logistics & packaging ₹4 → Consumer pays only ₹28!",
    
    blockchainTitle: "Product Origin & History",
    blockchainSub: "Verified farm traceability record (Prototype Demo)",
    batchIdLabel: "Batch ID",
    harvestDateLabel: "Harvest Date",
    farmOriginLabel: "Farm Origin",
    qualityCheckLabel: "Quality & Pesticide Test",
    dispatchLabel: "Dispatch Status",
    testedSafe: "Passed — Zero harmful chemical residues",
    directFromFarm: "Harvested 6:00 AM • Direct Farm Pickup",
    blockchainDemoNotice: "Note: This is a verified blockchain provenance prototype for food safety demonstration.",
    
    cropTomato: "Fresh Tomato",
    cropOnion: "Red Onion",
    cropPotato: "Farm Potato",
    cropMango: "Alphonso Mango",
    cropWheat: "Sharbati Wheat",
    cropVegetables: "Fresh Spinach",
    cropSpinach: "Organic Palak",
    cropMilk: "Pure Cow Milk",
    cropBanana: "Fresh Banana",

    // Sell in 60 Seconds
    sellIn60SecondsTitle: "Sell in 60 Seconds",
    sellIn60SecondsSub: "Sell your crop in 3 quick taps. No paperwork, no middleman.",
    step1Visual: "① Choose Crop",
    step2Visual: "② Enter Quantity",
    step3Visual: "③ Set Price",
    step4Visual: "🎉 Done!",
    start60sSell: "Sell in 60 Seconds",
    readyToSellPrompt: "Ready to sell?",
    buyersCanSeeCropNow: "Buyers can now see your crop.",

    // Simple Crop Price Guidance
    priceGuidanceTitle: "What price should I keep?",
    priceGuidanceSub: "Real village and mandi pricing guidance",
    nearbyFarmersRange: "Nearby farmers / Mandi",
    suggestedRange: "Suggested range",
    useSuggestedPriceBtn: "Use ₹{price}/kg",
    priceGuidanceDemoNote: "Demo Price / Illustrative Example (Not a live APMC API feed)",

    // Find Nearby Buyers
    findBuyersTitle: "Find Buyers",
    findBuyersSub: "Local shops, restaurants, and residential clubs looking for fresh harvest",
    viewBuyerBtn: "View Buyer",
    contactBuyerBtn: "Contact",
    callNowBtn: "Call Now",
    whatsappMessageBtn: "Message on WhatsApp",
    demoBuyerBadge: "Demo Buyer / Prototype",
    neededQuantityLabel: "Quantity Needed",
    offeredRateLabel: "Target Price",
    urgencyUrgentLabel: "Urgent Need",
    urgencyRegularLabel: "Regular Buyer",
    urgencyWeeklyLabel: "Weekly Bulk",
    buyerDetailsTitle: "Buyer Requirement Details",
    buyerContactPrompt: "Direct connection with verified local buyer. No middlemen commission.",

    // New Order Alert
    newOrderAlertTitle: "New Order Received!",
    newOrderAlertSub: "A nearby buyer just ordered your fresh produce. Review and accept now.",
    simulateOrderAlertBtn: "Test New Order Alert 🔔",
    testAlertSoundNote: "Plays sound chime and voice announcement in current language",
    orderChimeSpeech: "Alert: New order received! A nearby customer ordered your produce.",
  },
  
  hi: {
    appName: "किसान सेतु",
    tagline: "सरल। उचित। सीधा।",
    subtitle: "सीधा किसान से ग्राहक तक बाज़ार",
    demoBadge: "डेमो",
    prototypeBadge: "प्रोटोटाइप",
    verifiedFarmer: "सत्यापित किसान",
    languageSelect: "भाषा / Language",
    back: "पीछे जाएं",
    home: "होम",
    continueBtn: "आगे बढ़ें",
    cancel: "रद्द करें",
    confirm: "पुष्टि करें",
    close: "बंद करें",
    loading: "लोड हो रहा है...",
    errorGeneric: "कुछ गलत हो गया। कृपया पुन: प्रयास करें।",
    errorInternet: "कृपया अपना इंटरनेट कनेक्शन जांचें।",
    
    listenText: "सुनें",
    speakingText: "बोल रहे हैं...",
    stopListening: "रोकें",
    voiceUnavailable: "इस डिवाइस पर आवाज़ उपलब्ध नहीं है।",
    speakToSearch: "बोलकर खोजें",
    listeningNow: "सुन रहे हैं... अब बोलें",
    voiceSearchPrompt: "फसल का नाम बोलें जैसे 'टमाटर' या 'गेहूं'",
    
    heroTitleFarmer: "अपनी फसल सीधे बेचें।",
    heroTitleConsumer: "किसानों से सीधे ताज़ी उपज खरीदें।",
    heroTagline: "सरल। उचित। सीधा।",
    sellMyCrop: "अपनी फसल बेचें",
    buyFresh: "ताज़ा खरीदें",
    heroSubtext: "मेहनती भारतीय किसानों को सीधे स्थानीय ग्राहकों से जोड़ना। बिना बिचौलियों के, पारदर्शी दाम और पक्की ताज़गी।",
    switchRolePrompt: "आप किसान हैं या ग्राहक?",
    fairDirectSimple: "आपकी फसल। आपका दाम। आपका खरीदार।",
    pillar1Title: "किसानों को पूरा मुनाफा",
    pillar1Desc: "अपनी तय की गई पूरी कीमत अपने पास रखें। मंडी की कोई दलाली या अनुचित कटौती नहीं।",
    pillar2Title: "ग्राहकों के लिए खेत से ताज़ा",
    pillar2Desc: "आज ही खेत से तोड़ा हुआ, सीधे आपके घर तक ताज़ा पहुंचता है।",
    pillar3Title: "पारदर्शी और भरोसेमंद",
    pillar3Desc: "जानिए आपकी फसल किसने उगाई और आपके पैसे का एक-एक रुपया कहां जा रहा है।",
    
    farmerGreeting: "नमस्ते रमेश पाटिल! 👋",
    farmerQuestion: "आज क्या करना है?",
    farmerMainAction: "अपनी फसल बेचें",
    farmerMainActionSub: "3 आसान चरणों में अपनी फसल जोड़ें",
    myCrops: "मेरी फसलें",
    myOrders: "मेरे ऑर्डर",
    myEarnings: "मेरी कमाई",
    earningsToday: "आज की कमाई",
    earningsThisWeek: "इस हफ्ते",
    earningsTotal: "कुल कमाई",
    quickActions: "त्वरित कार्य",
    kisanSathiHelp: "किसान साथी बोलकर मदद",
    kisanSathiTagline: "हिंदी, मराठी या अंग्रेजी में प्रश्न पूछें",
    
    sellingStep1Title: "आप क्या बेच रहे हैं?",
    sellingStep1Sub: "अपनी फसल पर टैप करें या अन्य चुनें",
    sellingStep2Title: "आपके पास कितनी फसल है?",
    sellingStep2Sub: "किलोग्राम में मात्रा चुनें",
    sellingStep3Title: "आप क्या कीमत चाहते हैं?",
    sellingStep3Sub: "प्रति किलोग्राम अपनी उचित दर तय करें",
    sellingStep4Title: "बेचने के लिए तैयार?",
    sellingStep4Sub: "जारी करने से पहले अपनी जानकारी देख लें",
    cropSelected: "चुनी गई फसल",
    quantityLabel: "मात्रा",
    unitKg: "किग्रा",
    priceLabel: "कीमत प्रति किग्रा",
    nearbyBenchmark: "आस-पास के दाम: ₹22–₹28/किग्रा",
    benchmarkDemoNote: "आस-पास के किसान भाव के आधार पर (डेमो मानक)",
    confirmSellBtn: "अपनी फसल बेचें",
    listingSuccessTitle: "🎉 फसल जुड़ गई!",
    listingSuccessDesc: "आपकी फसल अब पुणे और आस-पास के सभी खरीदारों को दिख रही है।",
    viewMyCropsBtn: "मेरी फसलें देखें",
    goHomeBtn: "होम पर जाएं",
    otherCrop: "अन्य फसल",
    enterCropName: "फसल का नाम लिखें",
    
    ordersTitle: "आए हुए ऑर्डर",
    newOrder: "नया ऑर्डर",
    buyerLabel: "खरीदार",
    locationLabel: "स्थान",
    acceptOrderBtn: "ऑर्डर स्वीकार करें",
    rejectOrderBtn: "अस्वीकार",
    orderAcceptedToast: "🎉 ऑर्डर स्वीकार किया गया! फसल तैयार रखें।",
    orderRejectedToast: "ऑर्डर अस्वीकार कर दिया गया।",
    acceptedStatus: "स्वीकृत",
    rejectedStatus: "अस्वीकृत",
    noOrdersYet: "अभी कोई नया ऑर्डर नहीं है।",
    noOrdersSub: "जैसे ही कोई खरीदार ऑर्डर देगा, वह तुरंत यहाँ दिखेगा।",
    
    activeCropsTitle: "मेरी सूचीबद्ध फसलें",
    availableStock: "उपलब्ध स्टॉक",
    pricePerKgLabel: "भाव",
    addNewCropBtn: "+ नई फसल जोड़ें",
    noCropsYet: "अभी कोई फसल नहीं जोड़ी गई।",
    noCropsSub: "अपनी पहली फसल जोड़कर सीधे बेचना शुरू करें।",
    markSoldOut: "बिक गया दर्ज करें",
    markActive: "उपलब्ध रखें",
    
    earningsTitle: "मेरी कमाई",
    payoutHistoryTitle: "हालिया सीधे भुगतान",
    directToBank: "सीधे बैंक खाते में (डेमो)",
    paymentReceived: "भुगतान प्राप्त हुआ!",
    
    consumerGreeting: "नमस्ते 👋",
    consumerQuestion: "आज आप क्या ताज़ा खरीदना चाहते हैं?",
    searchPlaceholder: "सब्जियां, फल, अनाज खोजें...",
    locationCity: "पुणे, महाराष्ट्र",
    freshNearYou: "आपके आस-पास ताज़ा उपज",
    categoryAll: "सभी",
    categoryVegetables: "सब्जियां",
    categoryFruits: "फल",
    categoryGrains: "अनाज",
    categoryDairy: "दूध/डेयरी",
    perKg: "/ किग्रा",
    distanceAway: "दूर",
    addToBasket: "टोकरी में जोड़ें",
    addedToBasketToast: "टोकरी में जोड़ दिया गया! 🛒",
    noCropsFound: "कोई फसल नहीं मिली।",
    tryAnotherSearch: "कृपया कोई दूसरा शब्द खोजें या श्रेणी बदलें।",
    viewProductHistory: "फसल का इतिहास देखें",
    priceBreakdownLink: "कीमत की पूरी पारदर्शिता देखें",
    
    basketTitle: "आपकी टोकरी",
    basketEmptyTitle: "आपकी टोकरी खाली है।",
    basketEmptySub: "स्थानीय किसानों द्वारा ताज़ी काटी गई फसलों को देखें।",
    startShoppingBtn: "खरीदारी शुरू करें",
    itemsCount: "सामान",
    orderSummary: "ऑर्डर विवरण",
    subtotal: "कुल मूल्य",
    deliveryFee: "डिलीवरी",
    deliveryFree: "मुफ़्त",
    totalAmount: "कुल भुगतान",
    deliveryAddress: "डिलीवरी का पता",
    addressPlaceholder: "मकान नंबर, गली, इलाका, पुणे",
    checkoutBtn: "सीधा ऑर्डर करें",
    orderPlacedTitle: "🌱 आपका ऑर्डर सफलतापूर्वक दर्ज हुआ!",
    orderPlacedDesc: "किसान रमेश को आपका ऑर्डर मिल गया है और वे खेत से ताज़ा उत्पाद पैक करेंगे।",
    continueShoppingBtn: "खरीदारी जारी रखें",
    
    kisanSathiTitle: "किसान साथी",
    kisanSathiWelcome: "नमस्ते! आप बोलें या नीचे दिए विकल्प चुनें, मैं फसल बेचने में आपकी पूरी मदद करूँगा।",
    kisanSathiPrompt1: "💰 फसल के भाव जांचें",
    kisanSathiPrompt2: "📍 खरीदार खोजें",
    kisanSathiPrompt3: "🌾 फसल बेचने में मदद",
    kisanSathiPrompt4: "📦 मेरा ऑर्डर जांचें",
    kisanSathiAnswer1: "पुणे मंडी में आज टमाटर ₹22–₹26/किग्रा और प्याज ₹18–₹24/किग्रा बिक रहा है। किसान सेतु पर आप सीधे ₹25–₹30/किग्रा पा सकते हैं!",
    kisanSathiAnswer2: "पुणे और वाघोली में 48 खरीदार ताज़ी सब्जियों के इंतज़ार में हैं।",
    kisanSathiAnswer3: "बेचने के 4 चरण: 1) 'अपनी फसल बेचें' दबाएं, 2) फसल चुनें, 3) मात्रा तय करें, 4) कीमत तय करें। केवल 30 सेकंड का काम है!",
    kisanSathiAnswer4: "आयशा (पुणे) से 20 किग्रा टमाटर का ₹600 का ऑर्डर आया है। पुष्टि के लिए 'ऑर्डर स्वीकार करें' पर टैप करें!",
    kisanSathiCustomPrompt: "खेती या बिक्री से जुड़ा कोई भी सवाल पूछें...",
    askSathiBtn: "पूछें",
    
    transparencyTitle: "कीमत की पारदर्शिता",
    transparencySub: "देखिए जब आप किसान सेतु से खरीदते हैं तो आपके पैसे कहाँ जाते हैं",
    traditionalChain: "पारंपरिक बिचौलियों की व्यवस्था",
    kisanSetuChain: "किसान सेतु सीधी व्यवस्था",
    illustrativeNote: "1 किग्रा टमाटर पर आधारित सांकेतिक उदाहरण (डेमो)",
    middlemanCostTitle: "बिचौलिए 60% तक खा जाते हैं",
    middlemanCostDesc: "किसान को ₹12 → दलाल को ₹4 → परिवहन ₹5 → थोक व्यापारी ₹6 → खुदरा दुकानदार ₹8 → ग्राहक देता है ₹35।",
    directGainTitle: "किसान को 85%+ सीधा मिलता है",
    directGainDesc: "किसान को सीधे ₹24 → किसान सेतु पैकेजिंग व डिलीवरी ₹4 → ग्राहक सिर्फ ₹28 देता है!",
    
    blockchainTitle: "उत्पाद का स्रोत और इतिहास",
    blockchainSub: "सत्यापित खेत ट्रेसिबिलिटी रिकॉर्ड (प्रोटोटाइप डेमो)",
    batchIdLabel: "बैच आईडी",
    harvestDateLabel: "कटाई का समय",
    farmOriginLabel: "खेत का स्थान",
    qualityCheckLabel: "गुणवत्ता व कीटनाशक जांच",
    dispatchLabel: "डिलीवरी स्थिति",
    testedSafe: "जांच सफल — हानिकारक रसायनों से पूर्ण मुक्त",
    directFromFarm: "सुबह 6:00 बजे तोड़ा गया • खेत से सीधी लोडिंग",
    blockchainDemoNotice: "नोट: यह खाद्य सुरक्षा और प्रमाणिकता के लिए एक ब्लॉकचेन प्रोटोटाइप डेमो है।",
    
    cropTomato: "ताज़ा टमाटर",
    cropOnion: "लाल प्याज",
    cropPotato: "खेत का आलू",
    cropMango: "हापूस आम",
    cropWheat: "शरबती गेहूं",
    cropVegetables: "ताज़ा पालक",
    cropSpinach: "देशी पालक",
    cropMilk: "शुद्ध गाय का दूध",
    cropBanana: "ताज़ा केला",

    // Sell in 60 Seconds
    sellIn60SecondsTitle: "60 सेकंड में फसल बेचें",
    sellIn60SecondsSub: "केवल 3 आसान चरणों में फसल दर्ज करें। कोई कागजी झंझट नहीं।",
    step1Visual: "① फसल चुनें",
    step2Visual: "② मात्रा दर्ज करें",
    step3Visual: "③ भाव तय करें",
    step4Visual: "🎉 हो गया!",
    start60sSell: "60 सेकंड में फसल बेचें",
    readyToSellPrompt: "फसल बेचने के लिए तैयार हैं?",
    buyersCanSeeCropNow: "खरीदार अब आपकी फसल देख सकते हैं।",

    // Simple Crop Price Guidance
    priceGuidanceTitle: "मैं क्या भाव रखूं?",
    priceGuidanceSub: "आस-पास के किसानों और मंडी का सरल मार्गदर्शन",
    nearbyFarmersRange: "आस-पास के किसान / मंडी",
    suggestedRange: "सुझाया गया भाव",
    useSuggestedPriceBtn: "₹{price}/kg भाव चुनें",
    priceGuidanceDemoNote: "डेमो भाव / सांकेतिक उदाहरण (लाइव सरकारी मंडी एपीआई नहीं)",

    // Find Nearby Buyers
    findBuyersTitle: "खरीदार खोजें",
    findBuyersSub: "स्थानीय दुकानें, रेस्टोरेंट और सोसायटियां जो सीधे किसान से खरीदना चाहते हैं",
    viewBuyerBtn: "खरीदार देखें",
    contactBuyerBtn: "संपर्क करें",
    callNowBtn: "कॉल करें",
    whatsappMessageBtn: "व्हाट्सएप पर संदेश भेजें",
    demoBuyerBadge: "डेमो खरीदार / प्रोटोटाइप",
    neededQuantityLabel: "मांग (जरूरत)",
    offeredRateLabel: "प्रस्तावित भाव",
    urgencyUrgentLabel: "तुरंत चाहिए",
    urgencyRegularLabel: "नियमित खरीदार",
    urgencyWeeklyLabel: "साप्ताहिक मांग",
    buyerDetailsTitle: "खरीदार की मांग का विवरण",
    buyerContactPrompt: "स्थानीय खरीदार से सीधा संपर्क। 0% दलाली।",

    // New Order Alert
    newOrderAlertTitle: "नया ऑर्डर प्राप्त हुआ!",
    newOrderAlertSub: "आस-पास के ग्राहक ने आपकी ताज़ा फसल का ऑर्डर दिया है। अभी स्वीकार करें।",
    simulateOrderAlertBtn: "नया ऑर्डर अलर्ट बजाएं 🔔",
    testAlertSoundNote: "ऑडियो घंटी और भाषा में बोलकर सूचित करता है",
    orderChimeSpeech: "सूचना: नया ऑर्डर आया है! ग्राहक ने आपकी फसल की मांग की है।",
  },
  
  mr: {
    appName: "किसान सेतू",
    tagline: "सोपे. रास्त. थेट.",
    subtitle: "थेट शेतकरी ते ग्राहक कृषी बाजार",
    demoBadge: "डेमो",
    prototypeBadge: "प्रोटोटाइप",
    verifiedFarmer: "प्रमाणित शेतकरी",
    languageSelect: "भाषा / Language",
    back: "मागे या",
    home: "मुख्यपृष्ठ",
    continueBtn: "पुढे जा",
    cancel: "रद्द करा",
    confirm: "खात्री करा",
    close: "बंद करा",
    loading: "लोड होत आहे...",
    errorGeneric: "काहीतरी चूक झाली. कृपया पुन्हा प्रयत्न करा.",
    errorInternet: "कृपया आपले इंटरनेट कनेक्शन तपासा.",
    
    listenText: "ऐका",
    speakingText: "बोलत आहे...",
    stopListening: "थांबवा",
    voiceUnavailable: "या डिव्हाइसवर आवाज उपलब्ध नाही.",
    speakToSearch: "बोलून शोधा",
    listeningNow: "ऐकत आहे... आता बोला",
    voiceSearchPrompt: "पिकाचे नाव बोला जसे की 'टोमॅटो' किंवा 'गहू'",
    
    heroTitleFarmer: "तुमची पिके थेट विका.",
    heroTitleConsumer: "शेतकऱ्यांकडून थेट ताजी फळे व भाज्या खरेदी करा.",
    heroTagline: "सोपे. रास्त. थेट.",
    sellMyCrop: "तुमची पिके विका",
    buyFresh: "ताजी खरेदी",
    heroSubtext: "कष्टाळू भारतीय शेतकऱ्यांना थेट स्थानिक ग्राहकांशी जोडणारा मंच. दलाली नाही, रास्त भाव आणि खात्रीशीर ताजेपणा.",
    switchRolePrompt: "तुम्ही शेतकरी आहात की ग्राहक?",
    fairDirectSimple: "तुमचे पीक. तुमचा भाव. तुमचा खरेदीदार.",
    pillar1Title: "शेतकऱ्यांसाठी थेट नफा",
    pillar1Desc: "तुमचा ठरवलेला पूर्ण भाव तुम्हालाच मिळतो. कोणतीही दलाली किंवा मंडीची कपात नाही.",
    pillar2Title: "ग्राहकांसाठी शेतातून थेट ताजे",
    pillar2Desc: "आजच शेतातून काढलेले थेट तुमच्या घरापर्यंत पोहोचते.",
    pillar3Title: "पारदर्शक आणि विश्वासार्ह",
    pillar3Desc: "तुमचे अन्न कोणी पिकवले आणि तुमचा प्रत्येक रुपया कुठे जातो हे स्पष्ट दिसते.",
    
    farmerGreeting: "नमस्ते रमेश पाटील! 👋",
    farmerQuestion: "आज काय करायचे आहे?",
    farmerMainAction: "तुमची पिके विका",
    farmerMainActionSub: "३ सोप्या चरणांमध्ये आपली पिके जोडा",
    myCrops: "माझी पिके",
    myOrders: "माझे ऑर्डर",
    myEarnings: "माझी कमाई",
    earningsToday: "आजची कमाई",
    earningsThisWeek: "या आठवड्यात",
    earningsTotal: "एकूण कमाई",
    quickActions: "जलद पर्याय",
    kisanSathiHelp: "किसान साथी आवाज मदत",
    kisanSathiTagline: "हिंदी, मराठी किंवा इंग्रजीत प्रश्न विचारा",
    
    sellingStep1Title: "तुम्ही काय विकत आहात?",
    sellingStep1Sub: "पिकावर टॅप करा किंवा इतर निवडा",
    sellingStep2Title: "तुमच्याकडे किती माल आहे?",
    sellingStep2Sub: "किलोग्रॅममध्ये प्रमाण निवडा",
    sellingStep3Title: "तुम्हाला काय भाव हवा आहे?",
    sellingStep3Sub: "प्रति किलो योग्य भाव ठरवा",
    sellingStep4Title: "विक्रीसाठी तयार आहात?",
    sellingStep4Sub: "नोंदणी करण्यापूर्वी माहिती तपासा",
    cropSelected: "निवडलेले पीक",
    quantityLabel: "प्रमाण",
    unitKg: "किग्रॅ",
    priceLabel: "दर प्रति किग्रॅ",
    nearbyBenchmark: "जवळचे चालू भाव: ₹२२–₹२८/किग्रॅ",
    benchmarkDemoNote: "स्थानिक शेतकरी भावावर आधारित (डेमो माहिती)",
    confirmSellBtn: "तुमची पिके विका",
    listingSuccessTitle: "🎉 पीक नोंदवले गेले!",
    listingSuccessDesc: "तुमचे पीक आता पुणे व परिसरातील सर्व ग्राहकांसाठी उपलब्ध आहे.",
    viewMyCropsBtn: "माझी पिके पहा",
    goHomeBtn: "मुख्यपृष्ठावर जा",
    otherCrop: "इतर पीक",
    enterCropName: "पिकाचे नाव टाका",
    
    ordersTitle: "आलेले ऑर्डर",
    newOrder: "नवीन ऑर्डर",
    buyerLabel: "खरेदीदार",
    locationLabel: "ठिकाण",
    acceptOrderBtn: "ऑर्डर स्वीकारा",
    rejectOrderBtn: "नाकारा",
    orderAcceptedToast: "🎉 ऑर्डर स्वीकारली! माल तयार ठेवा.",
    orderRejectedToast: "ऑर्डर नाकारली गेली.",
    acceptedStatus: "स्वीकृत",
    rejectedStatus: "नाकारले",
    noOrdersYet: "अजून कोणतीही नवीन ऑर्डर नाही.",
    noOrdersSub: "ग्राहकांनी खरेदी करताच नवीन ऑर्डर येथे दिसतील.",
    
    activeCropsTitle: "माझी नोंदवलेली पिके",
    availableStock: "उपलब्ध साठा",
    pricePerKgLabel: "भाव",
    addNewCropBtn: "+ नवीन पीक जोडा",
    noCropsYet: "अजून पिके जोडली नाहीत.",
    noCropsSub: "पहिले पीक जोडून थेट विक्री सुरू करा.",
    markSoldOut: "विकले गेले म्हणून नोंदवा",
    markActive: "उपलब्ध ठेवा",
    
    earningsTitle: "माझी कमाई",
    payoutHistoryTitle: "अलीकडील थेट भरणा",
    directToBank: "थेट बँक खात्यात (डेमो)",
    paymentReceived: "पेमेंट मिळाले!",
    
    consumerGreeting: "शुभ प्रभात 👋",
    consumerQuestion: "आज आपल्याला काय ताजे हवे आहे?",
    searchPlaceholder: "भाज्या, फळे, धान्य शोधा...",
    locationCity: "पुणे, महाराष्ट्र",
    freshNearYou: "आपल्या जवळ ताजी पिके",
    categoryAll: "सर्व",
    categoryVegetables: "भाज्या",
    categoryFruits: "फळे",
    categoryGrains: "धान्य",
    categoryDairy: "दुग्धजन्य",
    perKg: "/ किग्रॅ",
    distanceAway: "लांब",
    addToBasket: "बास्केटमध्ये जोडा",
    addedToBasketToast: "बास्केटमध्ये जोडले! 🛒",
    noCropsFound: "कोणतेही पीक आढळले नाही.",
    tryAnotherSearch: "कृपया दुसरा शब्द शोधा किंवा वर्गवारी बदला.",
    viewProductHistory: "पिकाचा इतिहास पहा",
    priceBreakdownLink: "भावाची पारदर्शकता पहा",
    
    basketTitle: "आपली बास्केट",
    basketEmptyTitle: "आपली बास्केट रिकामी आहे.",
    basketEmptySub: "स्थानिक शेतकऱ्यांनी ताजी काढलेली पिके पहा.",
    startShoppingBtn: "खरेदी सुरू करा",
    itemsCount: "वस्तू",
    orderSummary: "ऑर्डर तपशील",
    subtotal: "एकूण रक्कम",
    deliveryFee: "डिलिव्हरी",
    deliveryFree: "मोफत",
    totalAmount: "एकूण देय",
    deliveryAddress: "डिलिव्हरी पत्ता",
    addressPlaceholder: "घर क्रमांक, गल्ली, परिसर, पुणे",
    checkoutBtn: "थेट ऑर्डर द्या",
    orderPlacedTitle: "🌱 आपली ऑर्डर नोंदवली गेली आहे!",
    orderPlacedDesc: "शेतकरी रमेश यांना आपली ऑर्डर मिळाली असून ते शेतातून ताजे उत्पादन पाठवतील.",
    continueShoppingBtn: "खरेदी सुरू ठेवा",
    
    kisanSathiTitle: "किसान साथी",
    kisanSathiWelcome: "नमस्ते! आपण बोला किंवा खालील पर्याय निवडा, मी आपल्याला पिके विकण्यासाठी पूर्ण मदत करेन.",
    kisanSathiPrompt1: "💰 पिकांचे चालू भाव",
    kisanSathiPrompt2: "📍 खरेदीदार शोधा",
    kisanSathiPrompt3: "🌾 विक्रीसाठी मदत",
    kisanSathiPrompt4: "📦 माझी ऑर्डर तपासा",
    kisanSathiAnswer1: "पुणे मार्केट यार्डमध्ये आज टोमॅटो ₹२२–₹२६/किग्रॅ आणि कांदा ₹१८–₹२४/किग्रॅ चालू आहे. किसान सेतूवर आपण थेट ₹२५–₹३०/किग्रॅ मिळवू शकता!",
    kisanSathiAnswer2: "पुणे आणि वाघोली परिसरात ४८ ग्राहक ताज्या भाजीपाल्याच्या प्रतीक्षेत आहेत.",
    kisanSathiAnswer3: "विक्रीचे ४ टप्पे: १) 'तुमची पिके विका' वर टॅप करा, २) पीक निवडा, ३) प्रमाण ठरवा, ४) भाव निश्चित करा. फक्त ३० सेकंदांचे काम आहे!",
    kisanSathiAnswer4: "आयशा (पुणे) कडून २० किलो टोमॅटोची ₹६०० ची ऑर्डर आली आहे. पुष्टीसाठी 'ऑर्डर स्वीकारा' वर क्लिक करा!",
    kisanSathiCustomPrompt: "शेती किंवा विक्री संदर्भात कोणताही प्रश्न विचारा...",
    askSathiBtn: "विचारा",
    
    transparencyTitle: "भावाची पारदर्शकता",
    transparencySub: "किसान सेतूमधून खरेदी करताना आपला प्रत्येक रुपया कुठे जातो ते पहा",
    traditionalChain: "पारंपरिक दलाल व्यवस्था",
    kisanSetuChain: "किसान सेतू थेट व्यवस्था",
    illustrativeNote: "१ किलो टोमॅटोवरील प्रातिनिधिक उदाहरण (डेमो)",
    middlemanCostTitle: "दलाल ६०% पर्यंत नफा घेतात",
    middlemanCostDesc: "शेतकऱ्याला मिळतात ₹१२ → दलाल ₹४ → वाहतूक ₹५ → मोठा व्यापारी ₹६ → किरकोळ विक्रेता ₹८ → ग्राहक देतो ₹३५.",
    directGainTitle: "शेतकऱ्याला ८५%+ थेट मिळतो",
    directGainDesc: "शेतकऱ्याला थेट ₹२४ → किसान सेतू पॅकिंग व डिलिव्हरी ₹४ → ग्राहकाला फक्त ₹२८ मध्ये मिळते!",
    
    blockchainTitle: "उत्पादनाचा उगम आणि इतिहास",
    blockchainSub: "प्रमाणित शेत ट्रेसिबिलिटी नोंद (प्रोटोटाइप डेमो)",
    batchIdLabel: "बॅच आयडी",
    harvestDateLabel: "काढणीची तारीख",
    farmOriginLabel: "शेताचे ठिकाण",
    qualityCheckLabel: "गुणवत्ता व औषध तपासणी",
    dispatchLabel: "डिलिव्हरी स्थिती",
    testedSafe: "तपासणी उत्तीर्ण — घातक रसायनांपासून १००% मुक्त",
    directFromFarm: "सकाळी ६:०० वाजता काढणी • शेतातून थेट लोडिंग",
    blockchainDemoNotice: "टीप: अन्न सुरक्षा आणि सत्यतेच्या प्रात्यक्षिकासाठी हा ब्लॉकचेन प्रोटोटाइप डेमो आहे.",
    
    cropTomato: "ताजा टोमॅटो",
    cropOnion: "लाल कांदा",
    cropPotato: "शेतातला बटाटा",
    cropMango: "हापूस आंबा",
    cropWheat: "शरबती गहू",
    cropVegetables: "ताजी पालकाची भाजी",
    cropSpinach: "गावरान पालक",
    cropMilk: "शुद्ध गाईचे दूध",
    cropBanana: "ताजी केळी",

    // Sell in 60 Seconds
    sellIn60SecondsTitle: "60 सेकंदात पीक विका",
    sellIn60SecondsSub: "फक्त ३ सोप्या टप्प्यांत पीक विका. कागदपत्र नाही, दलाल नाही.",
    step1Visual: "① पीक निवडा",
    step2Visual: "② प्रमाण टाका",
    step3Visual: "③ भाव ठरवा",
    step4Visual: "🎉 झाले!",
    start60sSell: "60 सेकंदात पीक विका",
    readyToSellPrompt: "पीक विकण्यास तयार आहात?",
    buyersCanSeeCropNow: "ग्राहक आता तुमचे पीक पाहू शकतात.",

    // Simple Crop Price Guidance
    priceGuidanceTitle: "मी काय भाव ठेवू?",
    priceGuidanceSub: "जवळचे शेतकरी आणि बाजारातील सोपे मार्गदर्शन",
    nearbyFarmersRange: "जवळचे शेतकरी / बाजार",
    suggestedRange: "सुचवलेला भाव",
    useSuggestedPriceBtn: "₹{price}/kg भाव निवडा",
    priceGuidanceDemoNote: "डेमो भाव / उदाहरणार्थ (थेट शासकीय API फीड नाही)",

    // Find Nearby Buyers
    findBuyersTitle: "ग्राहक शोधा",
    findBuyersSub: "स्थानिक दुकाने, हॉटेल्स आणि सोसायट्या ज्यांना ताजे शेतमाल हवे आहे",
    viewBuyerBtn: "ग्राहक पाहा",
    contactBuyerBtn: "संपर्क करा",
    callNowBtn: "फोन करा",
    whatsappMessageBtn: "व्हॉट्सॲपवर मेसेज करा",
    demoBuyerBadge: "डेमो खरेदीदार / प्रोटोटाइप",
    neededQuantityLabel: "आवश्यक प्रमाण",
    offeredRateLabel: "अपेक्षित भाव",
    urgencyUrgentLabel: "तातडीने हवे",
    urgencyRegularLabel: "नियमित ग्राहक",
    urgencyWeeklyLabel: "साप्ताहिक खरेदी",
    buyerDetailsTitle: "ग्राहकाच्या मागणीचा तपशील",
    buyerContactPrompt: "स्थानिक खरेदीदाराशी थेट संपर्क. ०% कमिशन.",

    // New Order Alert
    newOrderAlertTitle: "नवीन ऑर्डर आला आहे!",
    newOrderAlertSub: "जवळच्या ग्राहकाने आपल्या पिकाची ऑर्डर दिली आहे. लगेच तपासा आणि स्वीकारा.",
    simulateOrderAlertBtn: "नवीन ऑर्डर सूचना वाजवा 🔔",
    testAlertSoundNote: "ध्वनी आणि आवाजाद्वारे मराठीत सूचना देईल",
    orderChimeSpeech: "सूचना: नवीन ऑर्डर आला आहे! ग्राहकाने आपल्या पिकाची मागणी केली आहे.",
  }
};
