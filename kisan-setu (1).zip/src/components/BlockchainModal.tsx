import React from 'react';
import { Language, Product } from '../types';
import { translations } from '../translations';
import { X, Link2, ShieldCheck, CheckCircle2, QrCode, Calendar, MapPin } from 'lucide-react';

interface BlockchainModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  product: Product | null;
}

export const BlockchainModal: React.FC<BlockchainModalProps> = ({
  isOpen,
  onClose,
  language,
  product,
}) => {
  const t = translations[language];

  if (!isOpen || !product) return null;

  const translatedName =
    t[product.nameKey as keyof typeof t] as string || product.nameDefault;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-900 flex items-center justify-center font-bold">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-stone-900 leading-tight">
                {t.blockchainTitle}
              </h2>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
                {t.prototypeBadge} • {t.demoBadge}
              </span>
            </div>
          </div>

          <button
            id="blockchain-close-btn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Product Overview Card */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-4">
            <span className="text-4xl p-2.5 bg-white rounded-xl border border-stone-200 shadow-2xs">
              {product.emoji}
            </span>
            <div>
              <h3 className="font-extrabold text-base text-stone-900">
                {translatedName}
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                👨‍🌾 {product.farmerName} • 📍 {product.farmerLocation}
              </p>
            </div>
          </div>

          {/* Traceability Audit Trail (Farm to Fork) */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
              {language === 'hi' ? 'खेत से थाली तक की यात्रा' : language === 'mr' ? 'शेतातून ताटापर्यंतचा प्रवास' : 'Farm-to-Fork Traceability Log'}
            </h4>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-emerald-200">
              
              {/* Event 1: Harvest */}
              <div className="relative">
                <span className="absolute -left-6 top-1 w-4 h-4 rounded-full bg-emerald-600 border-2 border-white shadow-xs" />
                <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-emerald-800 block">
                    1. {t.harvestDateLabel}
                  </span>
                  <p className="text-xs font-semibold text-stone-900 mt-0.5">
                    {product.harvestDate}
                  </p>
                  <p className="text-[11px] text-stone-500">
                    {product.farmerLocation}
                  </p>
                </div>
              </div>

              {/* Event 2: Quality Inspection */}
              <div className="relative">
                <span className="absolute -left-6 top-1 w-4 h-4 rounded-full bg-emerald-600 border-2 border-white shadow-xs" />
                <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-2xs">
                  <span className="text-[11px] font-bold text-emerald-800 block">
                    2. {t.qualityCheckLabel}
                  </span>
                  <p className="text-xs font-semibold text-stone-900 mt-0.5">
                    {t.testedSafe}
                  </p>
                  <p className="text-[11px] text-emerald-700 font-medium">
                    ✅ Soil & Pesticide Residue: Passed (Grade A)
                  </p>
                </div>
              </div>

              {/* Event 3: Blockchain Hash Block */}
              <div className="relative">
                <span className="absolute -left-6 top-1 w-4 h-4 rounded-full bg-amber-500 border-2 border-white shadow-xs" />
                <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 shadow-2xs space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-bold text-amber-950">
                    <span>3. {t.batchIdLabel}</span>
                    <span className="font-mono text-[10px] text-stone-600">
                      {product.batchId}
                    </span>
                  </div>
                  <p className="text-[11px] font-mono text-stone-600 truncate">
                    Hash: 0x9f4a8b2c6e...d32a (Polygon Demo)
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Prototype disclaimer (Section 32 & 41) */}
          <div className="p-3 bg-stone-100 rounded-xl text-[11px] text-stone-500 text-center leading-relaxed">
            ⚠️ {t.blockchainDemoNotice}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50 text-center">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl cursor-pointer"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};
