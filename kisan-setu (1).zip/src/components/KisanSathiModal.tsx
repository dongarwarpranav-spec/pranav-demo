import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { HumanAvatar } from './HumanAvatar';
import { X, Send, Sparkles, Volume2, StopCircle } from 'lucide-react';

interface KisanSathiModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSpeakText: (text: string) => void;
  isSpeaking: boolean;
}

export const KisanSathiModal: React.FC<KisanSathiModalProps> = ({
  isOpen,
  onClose,
  language,
  onSpeakText,
  isSpeaking,
}) => {
  const t = translations[language];

  const [activeAnswer, setActiveAnswer] = useState<string>(t.kisanSathiAnswer1);
  const [activeQuestion, setActiveQuestion] = useState<string>(t.kisanSathiPrompt1);
  const [customInput, setCustomInput] = useState<string>('');

  if (!isOpen) return null;

  const quickPrompts = [
    {
      id: 'p1',
      question: t.kisanSathiPrompt1,
      answer: t.kisanSathiAnswer1,
    },
    {
      id: 'p2',
      question: t.kisanSathiPrompt2,
      answer: t.kisanSathiAnswer2,
    },
    {
      id: 'p3',
      question: t.kisanSathiPrompt3,
      answer: t.kisanSathiAnswer3,
    },
    {
      id: 'p4',
      question: t.kisanSathiPrompt4,
      answer: t.kisanSathiAnswer4,
    },
  ];

  const handleSelectPrompt = (q: string, a: string) => {
    setActiveQuestion(q);
    setActiveAnswer(a);
    // Automatically speak the answer in the user's selected language
    onSpeakText(a);
  };

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;

    const q = customInput;
    let a = "";
    if (language === 'hi') {
      a = `आपकी उपज के लिए किसान सेतु पर सीधे ग्राहक उपलब्ध हैं। सही भाव तय करें और ताज़ी फसल पैक करके रखें।`;
    } else if (language === 'mr') {
      a = `आपल्या पिकासाठी किसान सेतूवर थेट खरेदीदार उपलब्ध आहेत. योग्य दर ठरवून माल शेतातून तयार ठेवा.`;
    } else {
      a = `For your crop question: On Kisan Setu you can set your direct price without mandi commissions. Local buyers in Pune are ready to order directly.`;
    }

    setActiveQuestion(q);
    setActiveAnswer(a);
    setCustomInput('');
    onSpeakText(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        
        {/* Header with SAME Human Avatar */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-3">
            <HumanAvatar size="md" isSpeaking={isSpeaking} />
            <div>
              <h2 className="text-lg font-black text-stone-900 leading-tight flex items-center gap-1.5">
                <span>🌾</span>
                <span>{t.kisanSathiTitle}</span>
              </h2>
              <span className="text-xs text-amber-900 font-semibold">
                &ldquo;Aap bolo, hum madad karenge&rdquo;
              </span>
            </div>
          </div>

          <button
            id="kisan-sathi-close-btn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white hover:bg-stone-100 text-stone-600 flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          
          {/* Active Advice Box with Voice Readout */}
          <div className="bg-emerald-50/80 rounded-2xl p-4 sm:p-5 border border-emerald-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-800">
                {activeQuestion}
              </span>

              {/* Tap to speak / stop speaking */}
              <button
                type="button"
                onClick={() => onSpeakText(activeAnswer)}
                className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                  isSpeaking
                    ? 'bg-emerald-700 text-white animate-pulse'
                    : 'bg-white text-emerald-900 border border-emerald-300 hover:bg-emerald-100'
                }`}
              >
                {isSpeaking ? (
                  <>
                    <StopCircle className="w-3.5 h-3.5" />
                    <span>{t.stopListening}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{t.listenText}</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-sm font-medium text-stone-900 leading-relaxed">
              {activeAnswer}
            </p>
          </div>

          {/* 4 One-Tap Action Prompts (Section 34) */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-500 block">
              {language === 'hi' ? 'त्वरित प्रश्न चुनें:' : language === 'mr' ? 'जलद प्रश्न निवडा:' : 'Quick Questions:'}
            </span>

            <div className="grid grid-cols-2 gap-2">
              {quickPrompts.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectPrompt(p.question, p.answer)}
                  className={`p-3 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer ${
                    activeQuestion === p.question
                      ? 'border-emerald-600 bg-emerald-100/70 text-emerald-950 shadow-2xs ring-1 ring-emerald-400'
                      : 'border-stone-200 bg-stone-50 hover:bg-white text-stone-800'
                  }`}
                >
                  {p.question}
                </button>
              ))}
            </div>
          </div>

          {/* Ask Custom Question Input */}
          <form onSubmit={handleSendCustom} className="pt-2 border-t border-stone-100 flex gap-2">
            <input
              type="text"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder={t.kisanSathiCustomPrompt}
              className="flex-1 px-3.5 py-2.5 bg-stone-50 rounded-xl border border-stone-200 text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              <span>{t.askSathiBtn}</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-50 border-t border-stone-100 text-center">
          <p className="text-[11px] text-stone-500">
            {language === 'hi'
              ? 'किसान साथी आपकी भाषा समझता है और बोलने में मदद करता है।'
              : language === 'mr'
              ? 'किसान साथी आपली भाषा समजतो आणि बोलून मार्गदर्शन करतो.'
              : 'Kisan Sathi understands your language and speaks help aloud.'}
          </p>
        </div>

      </div>
    </div>
  );
};
