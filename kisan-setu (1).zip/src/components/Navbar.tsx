import React from 'react';
import { AppMode, Language } from '../types';
import { translations } from '../translations';
import { AvatarVoiceButton } from './AvatarVoiceButton';
import { ShoppingBasket, Sparkles, Scale } from 'lucide-react';

interface NavbarProps {
  mode: AppMode;
  onSelectMode: (mode: AppMode) => void;
  language: Language;
  onSelectLanguage: (lang: Language) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenPriceTransparency: () => void;
  onOpenKisanSathi: () => void;
  isSpeaking: boolean;
  onToggleVoice: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  mode,
  onSelectMode,
  language,
  onSelectLanguage,
  cartCount,
  onOpenCart,
  onOpenPriceTransparency,
  onOpenKisanSathi,
  isSpeaking,
  onToggleVoice,
}) => {
  const t = translations[language];

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-stone-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2 sm:gap-4">
          
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <button
              id="nav-logo-btn"
              type="button"
              onClick={() => onSelectMode('home')}
              className="flex items-center gap-2.5 text-left group cursor-pointer focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white flex items-center justify-center font-bold text-xl shadow-xs group-hover:scale-105 transition-transform">
                🌾
              </div>
              <div className="flex flex-col">
                <span className="font-extrabold text-lg sm:text-xl text-stone-900 tracking-tight leading-none">
                  {t.appName}
                </span>
                <span className="text-[11px] font-medium text-emerald-800 tracking-normal hidden sm:inline-block">
                  {t.tagline}
                </span>
              </div>
            </button>

            {/* Quick role toggle */}
            <div className="hidden md:flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 ml-3">
              <button
                id="nav-mode-home-btn"
                type="button"
                onClick={() => onSelectMode('home')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  mode === 'home'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {t.home}
              </button>
              <button
                id="nav-mode-farmer-btn"
                type="button"
                onClick={() => onSelectMode('farmer')}
                className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  mode === 'farmer'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-stone-600 hover:text-emerald-800'
                }`}
              >
                <span>👨‍🌾</span>
                <span>{language === 'hi' ? 'किसान मोड' : language === 'mr' ? 'शेतकरी मोड' : 'Farmer Mode'}</span>
              </button>
              <button
                id="nav-mode-consumer-btn"
                type="button"
                onClick={() => onSelectMode('consumer')}
                className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  mode === 'consumer'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-stone-600 hover:text-emerald-800'
                }`}
              >
                <span>🛒</span>
                <span>{language === 'hi' ? 'ग्राहक बाज़ार' : language === 'mr' ? 'ग्राहक बाजार' : 'Buyer Market'}</span>
              </button>
            </div>
          </div>

          {/* Right Controls: Voice Avatar, Language Switcher, Price Transparency, Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Human Voice Button (Consistent person illustration with text label) */}
            <AvatarVoiceButton
              language={language}
              isSpeaking={isSpeaking}
              onToggle={onToggleVoice}
            />

            {/* Language Selector Dropdown (Obvious & Accessible) */}
            <div className="relative inline-flex items-center">
              <label htmlFor="language-select" className="sr-only">
                {t.languageSelect}
              </label>
              <select
                id="language-select"
                value={language}
                onChange={(e) => onSelectLanguage(e.target.value as Language)}
                aria-label={t.languageSelect}
                className="bg-white border border-stone-300 text-stone-800 font-medium text-xs sm:text-sm rounded-lg py-1.5 px-2.5 sm:px-3 hover:border-emerald-600 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 cursor-pointer shadow-2xs"
              >
                <option value="en">🇬🇧 English</option>
                <option value="hi">🇮🇳 हिंदी</option>
                <option value="mr">🇮🇳 मराठी</option>
              </select>
            </div>

            {/* Price Transparency button */}
            <button
              id="nav-price-transparency-btn"
              type="button"
              onClick={onOpenPriceTransparency}
              title={t.priceBreakdownLink}
              className="hidden lg:inline-flex items-center gap-1.5 text-xs font-semibold text-stone-700 hover:text-emerald-800 bg-stone-50 hover:bg-stone-100 px-2.5 py-1.5 rounded-lg border border-stone-200 transition-colors cursor-pointer"
            >
              <Scale className="w-3.5 h-3.5 text-emerald-700" />
              <span>{language === 'hi' ? 'दाम पारदर्शिता' : language === 'mr' ? 'भाव पारदर्शकता' : 'Price Fair'}</span>
            </button>

            {/* Kisan Sathi quick trigger */}
            <button
              id="nav-kisan-sathi-btn"
              type="button"
              onClick={onOpenKisanSathi}
              title={t.kisanSathiTitle}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-amber-900 bg-amber-50 hover:bg-amber-100/80 px-2.5 py-1.5 rounded-lg border border-amber-200 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>{t.kisanSathiTitle}</span>
            </button>

            {/* Cart Button */}
            <button
              id="nav-cart-btn"
              type="button"
              onClick={onOpenCart}
              aria-label={t.basketTitle}
              className={`relative flex items-center justify-center p-2 rounded-xl border cursor-pointer transition-all ${
                cartCount > 0 
                  ? 'bg-orange-50 hover:bg-orange-100 border-[#FC8019] text-[#FC8019]' 
                  : 'text-stone-700 hover:text-stone-900 bg-stone-50 hover:bg-stone-100 border-stone-200'
              }`}
            >
              <ShoppingBasket className="w-5 h-5" />
              {cartCount > 0 && (
                <span
                  id="nav-cart-count-badge"
                  className="absolute -top-1.5 -right-1.5 bg-[#FC8019] text-white font-black text-[11px] w-5 h-5 rounded-full flex items-center justify-center shadow-xs animate-bounce"
                >
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile secondary navigation strip */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-stone-100 text-xs font-semibold">
          <button
            id="mobile-nav-home"
            type="button"
            onClick={() => onSelectMode('home')}
            className={`px-3 py-1 rounded-md ${mode === 'home' ? 'text-emerald-800 bg-emerald-50' : 'text-stone-600'}`}
          >
            {t.home}
          </button>
          <button
            id="mobile-nav-farmer"
            type="button"
            onClick={() => onSelectMode('farmer')}
            className={`px-3 py-1 rounded-md ${mode === 'farmer' ? 'text-emerald-800 bg-emerald-50' : 'text-stone-600'}`}
          >
            👨‍🌾 {language === 'hi' ? 'किसान' : language === 'mr' ? 'शेतकरी' : 'Farmer'}
          </button>
          <button
            id="mobile-nav-consumer"
            type="button"
            onClick={() => onSelectMode('consumer')}
            className={`px-3 py-1 rounded-md ${mode === 'consumer' ? 'text-emerald-800 bg-emerald-50' : 'text-stone-600'}`}
          >
            🛒 {language === 'hi' ? 'ग्राहक बाज़ार' : language === 'mr' ? 'ग्राहक' : 'Buyer'}
          </button>
        </div>
      </div>
    </header>
  );
};
