import React, { useState } from 'react';
import { Language, CropOption, FarmerCrop } from '../types';
import { translations } from '../translations';
import { CROP_OPTIONS } from '../data';
import { HumanAvatar } from './HumanAvatar';
import { ArrowLeft, ArrowRight, CheckCircle2, Minus, Plus, Sparkles } from 'lucide-react';

interface FarmerSellingFlowProps {
  language: Language;
  onListingComplete: (newCrop: FarmerCrop) => void;
  onGoBack: () => void;
  onViewMyCrops: () => void;
  onSpeakStep: (text: string) => void;
  isSpeaking: boolean;
}

export const FarmerSellingFlow: React.FC<FarmerSellingFlowProps> = ({
  language,
  onListingComplete,
  onGoBack,
  onViewMyCrops,
  onSpeakStep,
  isSpeaking,
}) => {
  const t = translations[language];

  // Steps: 1 (Crop Choice), 2 (Quantity), 3 (Price), 4 (Confirm), 5 (Success)
  const [step, setStep] = useState<number>(1);
  const [selectedCrop, setSelectedCrop] = useState<CropOption>(CROP_OPTIONS[1]); // Default Tomato
  const [isCustomCrop, setIsCustomCrop] = useState<boolean>(false);
  const [customCropName, setCustomCropName] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(100);
  const [price, setPrice] = useState<number>(25);

  const getCropDisplayName = (crop: CropOption) => {
    if (isCustomCrop && customCropName) return customCropName;
    return t[crop.nameKey as keyof typeof t] as string || crop.id;
  };

  const handleNextStep = () => {
    if (step < 4) {
      setStep(step + 1);
    } else if (step === 4) {
      // Publish new listing
      const newFarmerCrop: FarmerCrop = {
        id: `fc-${Date.now()}`,
        cropId: selectedCrop.id,
        name: getCropDisplayName(selectedCrop),
        emoji: isCustomCrop ? '🌱' : selectedCrop.emoji,
        quantity: quantity,
        unit: 'kg',
        pricePerUnit: price,
        dateListed: 'Just now',
        status: 'active',
        image: selectedCrop.image,
      };
      onListingComplete(newFarmerCrop);
      setStep(5); // Success celebration screen
    }
  };

  const handlePrevStep = () => {
    if (step > 1 && step < 5) {
      setStep(step - 1);
    } else {
      onGoBack();
    }
  };

  // Build audio narration for the current step
  const speakCurrentStep = () => {
    let narration = "";
    if (step === 1) {
      narration = `${t.sellingStep1Title}. ${t.sellingStep1Sub}`;
    } else if (step === 2) {
      narration = `${t.sellingStep2Title}. ${quantity} ${t.unitKg}`;
    } else if (step === 3) {
      narration = `${t.sellingStep3Title}. ₹${price} ${t.perKg}. ${t.nearbyBenchmark}`;
    } else if (step === 4) {
      narration = `${t.sellingStep4Title}. ${getCropDisplayName(selectedCrop)}, ${quantity} ${t.unitKg}, ₹${price} ${t.perKg}`;
    }
    onSpeakStep(narration);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Top Header & Step Progress Bar */}
      {step < 5 && (
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between gap-3">
          <button
            id="selling-back-btn"
            type="button"
            onClick={handlePrevStep}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-stone-600 hover:text-stone-950 px-3 py-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{t.back}</span>
          </button>

          {/* Progress Indicators */}
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`h-2 rounded-full transition-all ${
                  s === step
                    ? 'w-8 bg-emerald-700'
                    : s < step
                    ? 'w-4 bg-emerald-500'
                    : 'w-4 bg-stone-200'
                }`}
              />
            ))}
            <span className="text-xs font-bold text-stone-500 ml-1">
              {step}/4
            </span>
          </div>

          {/* Speak current step question */}
          <button
            id="selling-step-voice-btn"
            type="button"
            onClick={speakCurrentStep}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 cursor-pointer"
          >
            <HumanAvatar size="sm" isSpeaking={isSpeaking} />
            <span>{isSpeaking ? t.stopListening : t.listenText}</span>
          </button>
        </div>
      )}

      {/* Main Step Container */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200/90 shadow-sm">
        
        {/* STEP 1: What are you selling? (Visual Crop Choice) */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                Step 1 of 4
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 mt-1">
                {t.sellingStep1Title}
              </h2>
              <p className="text-sm text-stone-600 mt-1">
                {t.sellingStep1Sub}
              </p>
            </div>

            {/* Visual Crop Grid with REAL Photos & Names */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {CROP_OPTIONS.map((crop) => {
                const isSelected = !isCustomCrop && selectedCrop.id === crop.id;
                const cropName = t[crop.nameKey as keyof typeof t] as string || crop.id;
                return (
                  <button
                    key={crop.id}
                    id={`crop-choice-${crop.id}`}
                    type="button"
                    onClick={() => {
                      setSelectedCrop(crop);
                      setIsCustomCrop(false);
                      setPrice(crop.defaultPrice);
                    }}
                    className={`p-3 rounded-xl border-2 text-left transition-colors cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                      isSelected
                        ? 'border-[#1B5E20] bg-emerald-50/80 shadow-xs ring-2 ring-emerald-600/30'
                        : 'border-stone-300 hover:border-stone-400 bg-white'
                    }`}
                  >
                    {/* Real Crop Photo thumbnail */}
                    <div className="w-full h-24 sm:h-28 rounded-lg overflow-hidden mb-2 bg-stone-100 relative">
                      <img
                        src={crop.image}
                        alt={cropName}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/70 text-white text-[11px] font-bold">
                        {crop.emoji}
                      </span>
                    </div>

                    <div>
                      <span className="font-extrabold text-stone-900 text-sm sm:text-base leading-tight block">
                        {cropName}
                      </span>
                      <span className="text-xs text-stone-600 font-bold block mt-0.5">
                        ₹{crop.defaultPrice} / kg
                      </span>
                    </div>
                  </button>
                );
              })}

              {/* Other Crop Choice */}
              <button
                id="crop-choice-other"
                type="button"
                onClick={() => {
                  setIsCustomCrop(true);
                  setPrice(30);
                }}
                className={`p-3 rounded-xl border-2 flex flex-col items-center justify-center text-center transition-colors cursor-pointer min-h-[140px] ${
                  isCustomCrop
                    ? 'border-[#1B5E20] bg-emerald-50/80 shadow-xs ring-2 ring-emerald-600/30'
                    : 'border-dashed border-stone-300 hover:border-stone-400 bg-stone-50'
                }`}
              >
                <span className="text-3xl mb-1">🌱</span>
                <span className="font-bold text-stone-900 text-sm leading-tight">
                  {t.otherCrop}
                </span>
                <span className="text-[11px] text-stone-500 mt-0.5">
                  {language === 'hi' ? '+ अन्य फसल' : language === 'mr' ? '+ इतर पीक' : '+ Custom Crop'}
                </span>
              </button>
            </div>

            {/* If other crop is selected, provide simple input */}
            {isCustomCrop && (
              <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200 space-y-2">
                <label htmlFor="custom-crop-input" className="block text-xs font-bold text-amber-950">
                  {t.enterCropName}
                </label>
                <input
                  id="custom-crop-input"
                  type="text"
                  placeholder="e.g. Cauliflower, Guava, Carrot"
                  value={customCropName}
                  onChange={(e) => setCustomCropName(e.target.value)}
                  className="w-full px-4 py-3 bg-white rounded-xl border border-stone-300 font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            )}

            {/* Continue Button */}
            <button
              id="selling-step-1-continue-btn"
              type="button"
              onClick={handleNextStep}
              disabled={isCustomCrop && !customCropName.trim()}
              className="w-full py-4 px-6 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-lg rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{t.continueBtn}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 2: How much do you have? (Quantity stepper) */}
        {step === 2 && (
          <div className="space-y-6">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                Step 2 of 4
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 mt-1">
                {t.sellingStep2Title}
              </h2>
              <p className="text-sm text-stone-600 mt-1">
                {getCropDisplayName(selectedCrop)} • {t.sellingStep2Sub}
              </p>
            </div>

            {/* Stepper Control: [ - ] 100 [ + ] KG */}
            <div className="bg-stone-50 rounded-3xl p-6 sm:p-8 border border-stone-200 flex flex-col items-center justify-center space-y-6">
              
              <div className="flex items-center gap-4 sm:gap-6">
                <button
                  id="quantity-decrease-btn"
                  type="button"
                  onClick={() => setQuantity(Math.max(5, quantity - (quantity > 50 ? 25 : 5)))}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white hover:bg-stone-100 border-2 border-stone-300 flex items-center justify-center text-stone-800 font-black text-2xl shadow-xs active:scale-95 cursor-pointer"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-6 h-6" />
                </button>

                <div className="text-center min-w-[140px]">
                  <span className="text-4xl sm:text-6xl font-black text-stone-900 tracking-tight">
                    {quantity}
                  </span>
                  <span className="block text-base sm:text-lg font-bold text-emerald-800 uppercase mt-1">
                    {t.unitKg}
                  </span>
                </div>

                <button
                  id="quantity-increase-btn"
                  type="button"
                  onClick={() => setQuantity(quantity + (quantity >= 50 ? 25 : 5))}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white hover:bg-stone-100 border-2 border-stone-300 flex items-center justify-center text-stone-800 font-black text-2xl shadow-xs active:scale-95 cursor-pointer"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-6 h-6" />
                </button>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                {[25, 50, 100, 200, 500].map((preset) => (
                  <button
                    key={preset}
                    id={`qty-preset-${preset}`}
                    type="button"
                    onClick={() => setQuantity(preset)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      quantity === preset
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    {preset} {t.unitKg}
                  </button>
                ))}
              </div>
            </div>

            {/* Continue Button */}
            <button
              id="selling-step-2-continue-btn"
              type="button"
              onClick={handleNextStep}
              className="w-full py-4 px-6 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-lg rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{t.continueBtn}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 3: What price do you want? (Price per kg + Nearby benchmark) */}
        {step === 3 && (
          <div className="space-y-6">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                Step 3 of 4
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 mt-1">
                {t.sellingStep3Title}
              </h2>
              <p className="text-sm text-stone-600 mt-1">
                {getCropDisplayName(selectedCrop)} • {t.sellingStep3Sub}
              </p>
            </div>

            {/* Price Stepper: ₹25 / kg */}
            <div className="bg-stone-50 rounded-3xl p-6 sm:p-8 border border-stone-200 flex flex-col items-center justify-center space-y-5">
              
              <div className="flex items-center gap-4 sm:gap-6">
                <button
                  id="price-decrease-btn"
                  type="button"
                  onClick={() => setPrice(Math.max(1, price - 1))}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white hover:bg-stone-100 border-2 border-stone-300 flex items-center justify-center text-stone-800 font-black text-2xl shadow-xs active:scale-95 cursor-pointer"
                  aria-label="Decrease price"
                >
                  <Minus className="w-6 h-6" />
                </button>

                <div className="text-center min-w-[160px]">
                  <div className="flex items-center justify-center text-4xl sm:text-6xl font-black text-emerald-900 tracking-tight">
                    <span>₹</span>
                    <span>{price}</span>
                  </div>
                  <span className="block text-sm sm:text-base font-bold text-stone-500 mt-1">
                    {t.perKg}
                  </span>
                </div>

                <button
                  id="price-increase-btn"
                  type="button"
                  onClick={() => setPrice(price + 1)}
                  className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white hover:bg-stone-100 border-2 border-stone-300 flex items-center justify-center text-stone-800 font-black text-2xl shadow-xs active:scale-95 cursor-pointer"
                  aria-label="Increase price"
                >
                  <Plus className="w-6 h-6" />
                </button>
              </div>

              {/* Step 3: Simple Crop Price Guidance ("What price should I keep?") */}
              <div className="w-full bg-[#FAF7F0] p-4 rounded-xl border border-stone-300 text-left space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-black text-stone-900 text-sm">
                    <span>💡</span>
                    <span>{t.priceGuidanceTitle}</span>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-stone-500 bg-stone-200/80 px-2 py-0.5 rounded">
                    {t.priceGuidanceDemoNote.split('(')[0].trim()}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="bg-white p-2.5 rounded-lg border border-stone-200">
                    <span className="text-stone-500 block text-[11px] font-semibold">{t.nearbyFarmersRange}:</span>
                    <span className="font-black text-stone-900 text-sm sm:text-base">
                      ₹{selectedCrop.benchmarkMin}–₹{selectedCrop.benchmarkMax}/{t.unitKg}
                    </span>
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-emerald-300 bg-emerald-50/40">
                    <span className="text-emerald-800 block text-[11px] font-bold">{t.suggestedRange}:</span>
                    <span className="font-black text-emerald-950 text-sm sm:text-base">
                      ₹{Math.round((selectedCrop.benchmarkMin + selectedCrop.benchmarkMax) / 2) - 1}–₹{Math.round((selectedCrop.benchmarkMin + selectedCrop.benchmarkMax) / 2) + 1}/{t.unitKg}
                    </span>
                  </div>
                </div>

                {/* One-tap [ Use ₹X/kg ] button */}
                <div className="pt-1 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const recPrice = Math.round((selectedCrop.benchmarkMin + selectedCrop.benchmarkMax) / 2);
                      setPrice(recPrice);
                    }}
                    className="w-full py-2.5 px-3 bg-emerald-800 hover:bg-emerald-900 text-white text-xs sm:text-sm font-black rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>✓</span>
                    <span>
                      {t.useSuggestedPriceBtn.replace('{price}', Math.round((selectedCrop.benchmarkMin + selectedCrop.benchmarkMax) / 2).toString())}
                    </span>
                  </button>
                </div>

                <p className="text-[10px] text-stone-500 leading-tight">
                  ℹ️ {t.priceGuidanceDemoNote}
                </p>
              </div>

              {/* Projected Total Return calculation */}
              <div className="text-xs text-stone-600 font-semibold text-center">
                {language === 'hi' ? 'अनुमानित कुल कमाई: ' : language === 'mr' ? 'अंदाजे एकूण उत्पन्न: ' : 'Estimated Total Earning: '}
                <span className="text-stone-900 font-black text-sm">₹{(quantity * price).toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Continue Button */}
            <button
              id="selling-step-3-continue-btn"
              type="button"
              onClick={handleNextStep}
              className="w-full py-4 px-6 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-lg rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{t.continueBtn}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* STEP 4: Ready to sell? (Final Review Confirmation) */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                Step 4 of 4
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 mt-1">
                {t.sellingStep4Title}
              </h2>
              <p className="text-sm text-stone-600 mt-1">
                {t.sellingStep4Sub}
              </p>
            </div>

            {/* Realistic Mandi Paper Slip / Receipt confirmation */}
            <div className="bg-[#FAF8F5] rounded-xl p-5 border-2 border-dashed border-stone-400 space-y-4 font-mono text-stone-800">
              <div className="flex items-center justify-between border-b border-stone-300 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-lg overflow-hidden border border-stone-300 bg-white">
                    <img
                      src={selectedCrop.image}
                      alt={getCropDisplayName(selectedCrop)}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-stone-900 font-sans">
                      {getCropDisplayName(selectedCrop)}
                    </h3>
                    <p className="text-xs text-stone-600 font-sans">
                      रमेश पाटिल • वाघोली, पुणे
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-bold font-sans">
                    0% दलाली / No Middleman
                  </span>
                </div>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-stone-600">{t.quantityLabel}:</span>
                  <span className="font-bold text-stone-900 text-sm">{quantity} {t.unitKg}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-600">{t.priceLabel}:</span>
                  <span className="font-bold text-stone-900 text-sm">₹{price} / {t.unitKg}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-600">{language === 'hi' ? 'पुणे मंडी चालू भाव:' : language === 'mr' ? 'पुणे मार्केट भाव:' : 'Pune APMC Rate:'}</span>
                  <span className="text-stone-500">₹{selectedCrop.benchmarkMin}–₹{selectedCrop.benchmarkMax}/kg</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-stone-300 text-sm font-bold">
                  <span className="text-emerald-950 font-sans">{language === 'hi' ? 'कुल अनुमानित भुगतान:' : language === 'mr' ? 'एकूण अंदाजे रक्कम:' : 'Total Estimated Payout:'}</span>
                  <span className="text-emerald-800 font-black text-base">₹{(quantity * price).toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="p-2.5 bg-emerald-50 rounded border border-emerald-200 text-[11px] text-emerald-900 font-sans font-medium">
                ✅ {language === 'hi'
                  ? 'यह फसल सीधे स्थानीय खरीदारों को दिखेगी। कोई बिचौलिया या आढ़ती कमीशन नहीं काटा जाएगा।'
                  : language === 'mr'
                  ? 'हे पीक थेट स्थानिक ग्राहकांना दिसेल. कोणताही दलाल किंवा अडते कमिशन कापणार नाही.'
                  : 'Direct to local buyers. 0% broker commission deducted.'}
              </div>
            </div>

            {/* Final Action Button: Sell My Crop */}
            <button
              id="selling-step-4-confirm-btn"
              type="button"
              onClick={handleNextStep}
              className="w-full py-4 px-6 bg-[#1B5E20] hover:bg-[#154a1a] text-white font-black text-lg rounded-xl shadow-xs transition-colors flex items-center justify-center gap-3 cursor-pointer"
            >
              <span>🌾</span>
              <span>{t.confirmSellBtn}</span>
            </button>
          </div>
        )}

        {/* STEP 5: Success Celebration Screen (Section 12) */}
        {step === 5 && (
          <div className="text-center py-6 sm:py-8 space-y-6">
            <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-800 border-4 border-emerald-300 flex items-center justify-center mx-auto text-4xl shadow-sm animate-bounce">
              🎉
            </div>

            <div className="space-y-2 max-w-md mx-auto">
              <h2 className="text-2xl sm:text-3xl font-black text-stone-900">
                🎉 {t.listingSuccessTitle}
              </h2>
              <p className="text-base text-stone-700 font-bold leading-relaxed">
                "{t.buyersCanSeeCropNow}"
              </p>
              <p className="text-xs text-stone-500 font-medium">
                {t.listingSuccessDesc}
              </p>
            </div>

            {/* Summary Tag */}
            <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 font-bold text-sm">
              <span>{isCustomCrop ? '🌱' : selectedCrop.emoji}</span>
              <span>{getCropDisplayName(selectedCrop)}</span>
              <span>•</span>
              <span>{quantity} {t.unitKg}</span>
              <span>•</span>
              <span>₹{price}/{t.unitKg}</span>
            </div>

            {/* Action Buttons: View Crop, Go Home */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 max-w-sm mx-auto">
              <button
                id="listing-success-view-crops-btn"
                type="button"
                onClick={onViewMyCrops}
                className="w-full py-3.5 px-5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md cursor-pointer transition-colors"
              >
                {t.viewMyCropsBtn}
              </button>
              <button
                id="listing-success-go-home-btn"
                type="button"
                onClick={onGoBack}
                className="w-full py-3.5 px-5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold rounded-xl border border-stone-300 cursor-pointer transition-colors"
              >
                {t.goHomeBtn}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
