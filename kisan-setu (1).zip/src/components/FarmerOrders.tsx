import React from 'react';
import { Language, FarmerOrder } from '../types';
import { translations } from '../translations';
import { Check, X, MapPin, User, Clock, CheckCircle2 } from 'lucide-react';

interface FarmerOrdersProps {
  language: Language;
  orders: FarmerOrder[];
  onAcceptOrder: (orderId: string) => void;
  onRejectOrder: (orderId: string) => void;
  onGoBack: () => void;
}

export const FarmerOrders: React.FC<FarmerOrdersProps> = ({
  language,
  orders,
  onAcceptOrder,
  onRejectOrder,
  onGoBack,
}) => {
  const t = translations[language];

  const pendingOrders = orders.filter((o) => o.status === 'pending');
  const pastOrders = orders.filter((o) => o.status !== 'pending');

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Title */}
      <div>
        <h2 className="text-2xl font-extrabold text-stone-900 tracking-tight flex items-center gap-2">
          <span>📦</span>
          <span>{t.ordersTitle}</span>
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
          {language === 'hi' ? 'स्थानीय ग्राहकों द्वारा दिए गए सीधे ऑर्डर' : language === 'mr' ? 'स्थानिक ग्राहकांनी दिलेले थेट ऑर्डर' : 'Direct crop purchases from nearby consumers'}
        </p>
      </div>

      {/* Pending Orders Section (Visual Cards) */}
      {pendingOrders.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-amber-900 flex items-center gap-2">
            <span>🔥</span>
            <span>{t.newOrder} ({pendingOrders.length})</span>
          </h3>

          <div className="space-y-4">
            {pendingOrders.map((order) => (
              <div
                key={order.id}
                id={`order-card-${order.id}`}
                className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-amber-300 shadow-md relative overflow-hidden"
              >
                {/* Header Tag */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-900">
                    <span>📦</span>
                    <span>{t.newOrder}</span>
                  </span>
                  <span className="text-xs text-stone-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{order.time}</span>
                  </span>
                </div>

                {/* Crop & Quantity Info */}
                <div className="flex items-start justify-between gap-4 py-3 border-y border-stone-100">
                  <div className="flex items-center gap-3.5">
                    <span className="text-4xl p-2.5 bg-amber-50 rounded-2xl border border-amber-200">
                      {order.cropEmoji}
                    </span>
                    <div>
                      <h4 className="text-xl font-black text-stone-900">
                        {order.cropName}
                      </h4>
                      <p className="text-sm font-bold text-stone-600">
                        {order.quantity} {order.unit} • ₹{order.pricePerUnit}/{order.unit}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-stone-500 font-semibold block">
                      {language === 'hi' ? 'कुल राशि' : language === 'mr' ? 'एकूण रक्कम' : 'Total'}
                    </span>
                    <span className="text-2xl font-black text-emerald-800">
                      ₹{order.totalPrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                {/* Buyer Details */}
                <div className="py-3 flex flex-wrap items-center justify-between gap-2 text-xs text-stone-600 font-medium">
                  <div className="flex items-center gap-1.5">
                    <User className="w-4 h-4 text-stone-400" />
                    <span>{t.buyerLabel}: <strong className="text-stone-900">{order.buyerName}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-700" />
                    <span>{t.locationLabel}: <strong className="text-stone-900">{order.buyerLocation}</strong></span>
                  </div>
                </div>

                {/* Action Buttons: Accept / Reject (Section 14) */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    id={`accept-order-btn-${order.id}`}
                    type="button"
                    onClick={() => onAcceptOrder(order.id)}
                    className="py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm sm:text-base rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                  >
                    <Check className="w-5 h-5" />
                    <span>{t.acceptOrderBtn}</span>
                  </button>

                  <button
                    id={`reject-order-btn-${order.id}`}
                    type="button"
                    onClick={() => onRejectOrder(order.id)}
                    className="py-3.5 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-sm sm:text-base rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                    <span>{t.rejectOrderBtn}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State when no pending orders */}
      {pendingOrders.length === 0 && (
        <div className="bg-white rounded-3xl p-8 border border-stone-200 text-center space-y-3">
          <span className="text-4xl block">📦</span>
          <h3 className="text-lg font-bold text-stone-900">{t.noOrdersYet}</h3>
          <p className="text-xs sm:text-sm text-stone-500 max-w-sm mx-auto">
            {t.noOrdersSub}
          </p>
        </div>
      )}

      {/* Past/Fulfilled Orders List */}
      {pastOrders.length > 0 && (
        <div className="space-y-3 pt-4 border-t border-stone-200">
          <h3 className="text-sm font-bold text-stone-700">
            {language === 'hi' ? 'पूर्व ऑर्डर इतिहास' : language === 'mr' ? 'मागील ऑर्डर इतिहास' : 'Past Order History'}
          </h3>

          <div className="space-y-3">
            {pastOrders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl p-2 bg-stone-50 rounded-xl border border-stone-200">
                    {order.cropEmoji}
                  </span>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900">
                      {order.cropName} • {order.quantity} {order.unit}
                    </h4>
                    <p className="text-xs text-stone-500">
                      {order.buyerName} • {order.buyerLocation}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4">
                  <span className="font-extrabold text-sm text-stone-900">
                    ₹{order.totalPrice.toLocaleString('en-IN')}
                  </span>
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                      order.status === 'accepted' || order.status === 'delivered'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-stone-200 text-stone-700'
                    }`}
                  >
                    {order.status === 'accepted' || order.status === 'delivered' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.acceptedStatus}</span>
                      </>
                    ) : (
                      <span>{t.rejectedStatus}</span>
                    )}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
