import React, { useState } from 'react';
import { Language, NearbyBuyer } from '../types';
import { translations } from '../translations';
import { NEARBY_BUYERS } from '../data';
import { MapPin, Phone, MessageSquare, ShieldCheck, X, ExternalLink, ArrowLeft, Building2 } from 'lucide-react';

interface FarmerBuyersListProps {
  language: Language;
  onGoBack?: () => void;
  onSelectBuyerCrop?: (cropName: string) => void;
}

export const FarmerBuyersList: React.FC<FarmerBuyersListProps> = ({
  language,
  onGoBack,
  onSelectBuyerCrop,
}) => {
  const t = translations[language];
  const [selectedBuyer, setSelectedBuyer] = useState<NearbyBuyer | null>(null);
  const [isContactModalOpen, setIsContactModalOpen] = useState<boolean>(false);
  const [copiedPhone, setCopiedPhone] = useState<boolean>(false);

  const handleOpenContact = (buyer: NearbyBuyer) => {
    setSelectedBuyer(buyer);
    setIsContactModalOpen(true);
    setCopiedPhone(false);
  };

  const getWhatsAppGreeting = (buyer: NearbyBuyer) => {
    if (language === 'hi') {
      return `नमस्ते ${buyer.name}, मैं किसान सेतु से रमेश पाटिल बोल रहा हूँ। मेरे पास ताज़ा ${buyer.cropNeeded} उपलब्ध है। क्या आपको अभी ${buyer.quantityNeeded} ${buyer.unit} चाहिए?`;
    } else if (language === 'mr') {
      return `नमस्ते ${buyer.name}, मी किसान सेतूवरून शेतकरी रमेश बोलत आहे. माझ्याकडे ताजा ${buyer.cropNeeded} उपलब्ध आहे. आपल्याला ${buyer.quantityNeeded} ${buyer.unit} हवे आहे का?`;
    }
    return `Hello ${buyer.name}, I am Ramesh Patil from Kisan Setu. I have fresh ${buyer.cropNeeded} available for your requirement of ${buyer.quantityNeeded} ${buyer.unit}.`;
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5 pb-16">
      
      {/* Header */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-stone-300 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {onGoBack && (
              <button
                type="button"
                onClick={onGoBack}
                className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer mr-1"
                aria-label="Go Back"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-stone-900 flex items-center gap-2">
                <span>📍</span>
                <span>{t.findBuyersTitle}</span>
              </h1>
              <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
                {t.findBuyersSub}
              </p>
            </div>
          </div>

          <span className="text-[11px] uppercase font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-1 rounded">
            {t.demoBuyerBadge}
          </span>
        </div>

        {/* Informative banner: Direct connection */}
        <div className="bg-[#FAF7F0] p-3 rounded-lg border border-stone-200 flex items-start gap-2.5 text-xs text-stone-700">
          <span className="text-base">🤝</span>
          <div>
            <span className="font-bold text-stone-900 block">{t.buyerContactPrompt}</span>
            <span className="text-stone-500 text-[11px]">
              {language === 'hi' 
                ? 'इन खरीदारों को सीधे फ़ोन या व्हाट्सएप से कॉल करें। कोई कमीशन या बिचौलिया नहीं।'
                : language === 'mr'
                ? 'या ग्राहकांशी थेट फोन किंवा व्हॉट्सॲपवर संपर्क करा. अडत किंवा दलाली नाही.'
                : 'Connect directly via phone or WhatsApp. Keep 100% of your earnings.'}
            </span>
          </div>
        </div>
      </div>

      {/* Buyer Cards List */}
      <div className="space-y-3.5">
        {NEARBY_BUYERS.map((buyer) => {
          const estimatedOrderValue = buyer.quantityNeeded * buyer.offeredPrice;

          return (
            <div
              key={buyer.id}
              id={`buyer-card-${buyer.id}`}
              className="bg-white rounded-xl border border-stone-300 p-4 sm:p-5 shadow-2xs hover:border-stone-400 transition-colors space-y-4"
            >
              {/* Buyer Top Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-base sm:text-lg font-black text-stone-900">
                      {buyer.name}
                    </h2>
                    {buyer.verified && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                        <span>{language === 'hi' ? 'सत्यापित' : language === 'mr' ? 'प्रमाणित' : 'Verified'}</span>
                      </span>
                    )}
                    <span className="text-[10px] uppercase font-bold text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded">
                      {buyer.businessType}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-stone-600 font-medium">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-stone-400" />
                      <span>{buyer.location}</span>
                    </span>
                    <span>•</span>
                    <span className="font-bold text-stone-700">
                      🚚 {buyer.distanceKm} km {t.distanceAway}
                    </span>
                  </div>
                </div>

                {/* Urgency Badge */}
                <div>
                  <span className={`inline-block text-[11px] font-bold px-2.5 py-1 rounded ${
                    buyer.urgency === 'urgent'
                      ? 'bg-red-100 text-red-900 border border-red-200 animate-pulse'
                      : buyer.urgency === 'weekly'
                      ? 'bg-blue-100 text-blue-900 border border-blue-200'
                      : 'bg-stone-100 text-stone-800 border border-stone-200'
                  }`}>
                    {buyer.urgency === 'urgent' ? `🔥 ${t.urgencyUrgentLabel}` : buyer.urgency === 'weekly' ? `📅 ${t.urgencyWeeklyLabel}` : `🛒 ${t.urgencyRegularLabel}`}
                  </span>
                </div>
              </div>

              {/* Requirement Box */}
              <div className="bg-[#FAF8F5] p-3.5 rounded-lg border border-stone-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{buyer.cropEmoji}</span>
                  <div>
                    <span className="text-xs text-stone-500 font-medium block">
                      {language === 'hi' ? 'मांग (फसल):' : language === 'mr' ? 'आवश्यक पीक:' : 'Crop Needed:'}
                    </span>
                    <span className="text-base font-black text-stone-900">
                      {buyer.cropNeeded}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div>
                    <span className="text-xs text-stone-500 font-medium block">
                      {t.neededQuantityLabel}:
                    </span>
                    <span className="text-base font-black text-stone-900">
                      {buyer.quantityNeeded} {buyer.unit}
                    </span>
                  </div>

                  <div>
                    <span className="text-xs text-stone-500 font-medium block">
                      {t.offeredRateLabel}:
                    </span>
                    <span className="text-base font-black text-emerald-800">
                      ₹{buyer.offeredPrice}/{buyer.unit}
                    </span>
                  </div>

                  <div className="hidden sm:block text-right">
                    <span className="text-xs text-stone-500 font-medium block">
                      {language === 'hi' ? 'कुल राशि:' : language === 'mr' ? 'एकूण रक्कम:' : 'Total Value:'}
                    </span>
                    <span className="text-base font-black text-stone-900">
                      ₹{estimatedOrderValue.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons: [ View Buyer ] & [ Contact ] */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedBuyer(buyer);
                    setIsContactModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-lg border border-stone-300 hover:bg-stone-100 text-stone-800 font-bold text-xs cursor-pointer transition-colors"
                >
                  {t.viewBuyerBtn}
                </button>

                <button
                  type="button"
                  onClick={() => handleOpenContact(buyer)}
                  className="px-5 py-2.5 rounded-lg bg-[#1B5E20] hover:bg-[#154a1a] text-white font-bold text-xs flex items-center gap-2 shadow-xs cursor-pointer transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t.contactBuyerBtn}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Contact Buyer Modal */}
      {isContactModalOpen && selectedBuyer && (
        <div 
          className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 border border-stone-300 shadow-2xl space-y-4 animate-in fade-in duration-200">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedBuyer.cropEmoji}</span>
                <div>
                  <h3 className="font-black text-stone-900 text-lg">
                    {selectedBuyer.name}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {selectedBuyer.businessType} • {selectedBuyer.location}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsContactModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-800 hover:bg-stone-100 cursor-pointer"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Requirement Summary */}
            <div className="bg-[#FAF7F0] p-4 rounded-xl border border-stone-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-stone-600">{language === 'hi' ? 'मांग:' : language === 'mr' ? 'मागणी:' : 'Crop:'}</span>
                <span className="font-black text-stone-900 text-sm">{selectedBuyer.cropNeeded}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-600">{t.neededQuantityLabel}:</span>
                <span className="font-black text-stone-900 text-sm">{selectedBuyer.quantityNeeded} {selectedBuyer.unit}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-600">{t.offeredRateLabel}:</span>
                <span className="font-black text-emerald-800 text-sm">₹{selectedBuyer.offeredPrice}/{selectedBuyer.unit}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-stone-300">
                <span className="font-bold text-stone-800">{language === 'hi' ? 'कुल सौदा:' : language === 'mr' ? 'एकूण रक्कम:' : 'Total Deal Value:'}</span>
                <span className="font-black text-stone-900 text-base">₹{(selectedBuyer.quantityNeeded * selectedBuyer.offeredPrice).toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Phone & WhatsApp Actions */}
            <div className="space-y-2.5">
              <a
                href={`tel:${selectedBuyer.phone}`}
                className="w-full py-3 px-4 bg-[#1B5E20] hover:bg-[#154a1a] text-white font-bold text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Phone className="w-4 h-4" />
                <span>{t.callNowBtn} ({selectedBuyer.phone})</span>
              </a>

              <a
                href={`https://wa.me/${selectedBuyer.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(getWhatsAppGreeting(selectedBuyer))}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 px-4 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{t.whatsappMessageBtn}</span>
              </a>
            </div>

            {/* Demo Notice */}
            <p className="text-[11px] text-center text-stone-500">
              🏷️ {t.demoBuyerBadge} — {language === 'hi' ? 'यह प्रोटोटाइप प्रदर्शन के लिए है।' : language === 'mr' ? 'हे प्रात्यक्षिकासाठी डेमो खरेदीदार आहे.' : 'This is a prototype demonstration.'}
            </p>

            <button
              type="button"
              onClick={() => setIsContactModalOpen(false)}
              className="w-full py-2 text-xs font-bold text-stone-600 hover:text-stone-900 cursor-pointer"
            >
              {t.close}
            </button>

          </div>
        </div>
      )}

    </div>
  );
};
