import React from 'react';
import { Language, EarningsSummary } from '../types';
import { translations } from '../translations';
import { CheckCircle2, Building, ShieldCheck } from 'lucide-react';

interface FarmerEarningsProps {
  language: Language;
  earnings: EarningsSummary;
  onGoBack: () => void;
}

export const FarmerEarnings: React.FC<FarmerEarningsProps> = ({
  language,
  earnings,
  onGoBack,
}) => {
  const t = translations[language];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Title */}
      <div>
        <h2 className="text-2xl font-extrabold text-stone-900 tracking-tight flex items-center gap-2">
          <span>💰</span>
          <span>{t.earningsTitle}</span>
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
          {language === 'hi' ? 'सीधे आपके बैंक खाते में जमा राशि' : language === 'mr' ? 'थेट आपल्या बँक खात्यात जमा झालेली रक्कम' : 'Direct settlements without any middleman cut'}
        </p>
      </div>

      {/* 3 Main Earnings Cards (Section 15) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs font-bold text-stone-500 block uppercase">
            {t.earningsToday}
          </span>
          <span className="text-2xl sm:text-3xl font-black text-stone-900 mt-2 block">
            ₹{earnings.today.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-emerald-700 font-semibold mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t.paymentReceived}</span>
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs font-bold text-stone-500 block uppercase">
            {t.earningsThisWeek}
          </span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-800 mt-2 block">
            ₹{earnings.thisWeek.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-stone-500 font-semibold mt-1">
            {language === 'hi' ? '4 नए ऑर्डर पूरे हुए' : language === 'mr' ? '४ नवीन ऑर्डर पूर्ण' : '4 fulfilled orders'}
          </span>
        </div>

        <div className="bg-emerald-50/80 p-5 rounded-2xl border border-emerald-200 shadow-2xs">
          <span className="text-xs font-bold text-emerald-800 block uppercase">
            {t.earningsTotal}
          </span>
          <span className="text-2xl sm:text-3xl font-black text-emerald-950 mt-2 block">
            ₹{earnings.total.toLocaleString('en-IN')}
          </span>
          <span className="text-[11px] text-emerald-800 font-semibold mt-1 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>100% {language === 'hi' ? 'सीधा भुगतान' : language === 'mr' ? 'थेट भरणा' : 'Direct payout'}</span>
          </span>
        </div>
      </div>

      {/* Direct Bank Account Status Card */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-900 flex items-center justify-center border border-amber-200">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-stone-900">
              State Bank of India (SBI) •••• 4920
            </h4>
            <p className="text-xs text-stone-500">
              Ramesh Patil • Wagholi Branch • {t.directToBank}
            </p>
          </div>
        </div>
        <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full self-start sm:self-auto">
          ✅ {language === 'hi' ? 'सक्रिय खाता' : language === 'mr' ? 'सक्रिय खाते' : 'Active Account'}
        </span>
      </div>

      {/* Recent Payouts List */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
        <h3 className="font-bold text-base text-stone-900 flex items-center justify-between">
          <span>{t.payoutHistoryTitle}</span>
          <span className="text-xs font-semibold text-stone-500">{t.demoBadge}</span>
        </h3>

        <div className="divide-y divide-stone-100">
          {earnings.recentPayouts.map((payout) => (
            <div key={payout.id} className="py-3.5 flex items-center justify-between gap-3">
              <div>
                <h4 className="font-bold text-sm text-stone-900">
                  {payout.crop}
                </h4>
                <p className="text-xs text-stone-500">
                  {payout.buyerName} • {payout.date}
                </p>
              </div>

              <div className="text-right">
                <span className="font-extrabold text-base text-emerald-800 block">
                  +₹{payout.amount.toLocaleString('en-IN')}
                </span>
                <span className="text-[11px] font-semibold text-stone-500">
                  {t.paymentReceived}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
