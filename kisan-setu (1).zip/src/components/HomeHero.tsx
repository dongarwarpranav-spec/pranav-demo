import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { HumanAvatar } from './HumanAvatar';
import { ShieldCheck, ArrowRight, TrendingUp, Sparkles, Scale } from 'lucide-react';

interface HomeHeroProps {
  language: Language;
  onSelectFarmer: () => void;
  onSelectConsumer: () => void;
  onOpenPriceTransparency: () => void;
  onOpenKisanSathi: () => void;
  onSpeakWelcome: () => void;
  isSpeaking: boolean;
}

export const HomeHero: React.FC<HomeHeroProps> = ({
  language,
  onSelectFarmer,
  onSelectConsumer,
  onOpenPriceTransparency,
  onOpenKisanSathi,
  onSpeakWelcome,
  isSpeaking,
}) => {
  const t = translations[language];

  return (
    <div className="py-6 sm:py-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 space-y-8 sm:space-y-10">
        
        {/* Main Welcome Section - Clean, Human-Crafted, Grounded */}
        <section
          id="home-hero-card"
          className="bg-white rounded-2xl border border-stone-300 p-6 sm:p-9 shadow-xs"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left: Purpose and Direct Actions */}
            <div className="lg:col-span-8 space-y-5">
              
              {/* Locality & Voice Listen */}
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-[#F4EFE6] text-stone-800 border border-stone-300">
                  <span>📍</span>
                  <span>{language === 'hi' ? 'पुणे व महाराष्ट्र के किसान' : language === 'mr' ? 'पुणे व महाराष्ट्रातील शेतकरी' : 'Farmers of Pune & Maharashtra'}</span>
                </span>
                
                {/* Voice listen button */}
                <button
                  id="hero-voice-read-btn"
                  type="button"
                  onClick={onSpeakWelcome}
                  className={`inline-flex items-center gap-2 px-3 py-1 rounded-md text-xs font-bold border transition-colors cursor-pointer ${
                    isSpeaking
                      ? 'bg-emerald-700 text-white border-emerald-800'
                      : 'bg-white hover:bg-stone-50 text-stone-800 border-stone-300'
                  }`}
                >
                  <HumanAvatar size="sm" isSpeaking={isSpeaking} />
                  <span>{isSpeaking ? t.speakingText : t.listenText}</span>
                </button>
              </div>

              {/* Headings */}
              <div className="space-y-2">
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-stone-900 leading-tight">
                  {t.heroTitleFarmer}
                  <br />
                  <span className="text-emerald-800">
                    {t.heroTitleConsumer}
                  </span>
                </h1>
                
                <p className="text-sm sm:text-base text-stone-600 font-medium max-w-xl leading-relaxed">
                  {t.heroSubtext}
                </p>
              </div>

              {/* Two Direct Human Choices (Large, Clear, High-Contrast) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                {/* Farmer Option */}
                <button
                  id="home-action-sell-btn"
                  type="button"
                  onClick={onSelectFarmer}
                  className="flex items-center justify-between p-4 rounded-xl bg-[#1B5E20] hover:bg-[#154a1a] text-white transition-colors cursor-pointer text-left shadow-xs"
                >
                  <div>
                    <span className="block text-xs font-medium text-emerald-200 uppercase tracking-wider">
                      {language === 'hi' ? 'किसान भाई यहाँ दबाएं' : language === 'mr' ? 'शेतकरी बांधवांसाठी' : 'For Farmers'}
                    </span>
                    <span className="text-base sm:text-lg font-black block mt-0.5">
                      {t.sellMyCrop}
                    </span>
                    <span className="text-xs text-emerald-100/90 font-medium block mt-0.5">
                      {language === 'hi' ? 'सीधा दाम, कोई दलाल नहीं' : language === 'mr' ? 'थेट भाव, दलाल नाही' : 'Direct price in your bank'}
                    </span>
                  </div>
                  <ArrowRight className="w-5 h-5 text-emerald-200 shrink-0 ml-2" />
                </button>

                {/* Consumer Option */}
                <button
                  id="home-action-buy-btn"
                  type="button"
                  onClick={onSelectConsumer}
                  className="flex items-center justify-between p-4 rounded-xl bg-[#B45309] hover:bg-[#92400e] text-white transition-colors cursor-pointer text-left shadow-xs"
                >
                  <div>
                    <span className="block text-xs font-medium text-amber-200 uppercase tracking-wider">
                      {language === 'hi' ? 'ताज़ी फसल खरीदने के लिए' : language === 'mr' ? 'ताजी भाजी खरेदीसाठी' : 'For Household Buyers'}
                    </span>
                    <span className="text-base sm:text-lg font-black block mt-0.5">
                      {t.buyFresh}
                    </span>
                    <span className="text-xs text-amber-100/90 font-medium block mt-0.5">
                      {language === 'hi' ? 'सीधे खेत से ताज़ा माल' : language === 'mr' ? 'शेतातून थेट ताजी भाजी' : 'Fresh from nearby farms'}
                    </span>
                  </div>
                  <ArrowRight className="w-5 h-5 text-amber-200 shrink-0 ml-2" />
                </button>
              </div>

              {/* Practical reassurance note */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-stone-600 pt-1">
                <span className="flex items-center gap-1.5 font-bold text-emerald-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>{t.fairDirectSimple}</span>
                </span>
                <span>•</span>
                <span>{language === 'hi' ? 'वाघोली, हडपसर, सासवड व जुन्नर' : language === 'mr' ? 'वाघोली, हडपसर, सासवड व जुन्नर' : 'Wagholi, Hadapsar, Saswad & Junnar'}</span>
              </div>
            </div>

            {/* Right: Friendly Voice Guide Box */}
            <div className="lg:col-span-4 flex flex-col items-center">
              <div className="w-full bg-[#FAF7F0] p-5 rounded-xl border border-stone-300 text-center space-y-3">
                <div className="flex justify-center">
                  <HumanAvatar size="lg" isSpeaking={isSpeaking} />
                </div>

                <div>
                  <h3 className="font-extrabold text-stone-900 text-sm sm:text-base">
                    {t.kisanSathiTitle}
                  </h3>
                  <p className="text-xs text-stone-600 mt-0.5">
                    {language === 'hi' ? 'बोलकर पूछें — हम पूरी मदद करेंगे।' : language === 'mr' ? 'बोलून विचारा — आम्ही पूर्ण मदत करू.' : 'Speak your question in Hindi or Marathi.'}
                  </p>
                </div>

                <button
                  id="hero-open-sathi-btn"
                  type="button"
                  onClick={onOpenKisanSathi}
                  className="w-full py-2.5 px-3 bg-white hover:bg-stone-100 text-emerald-900 border border-stone-300 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  <span>🗣️</span>
                  <span>{t.kisanSathiHelp}</span>
                </button>

                <button
                  id="hero-open-transparency-btn"
                  type="button"
                  onClick={onOpenPriceTransparency}
                  className="w-full py-1.5 text-xs font-bold text-stone-700 hover:text-emerald-800 flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Scale className="w-3.5 h-3.5 text-stone-500" />
                  <span>{t.priceBreakdownLink}</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Real Ground Reality: Pune Market Yard vs. Kisan Setu Direct */}
        <section className="bg-white rounded-xl border border-stone-300 p-5 sm:p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-200 pb-3">
            <div>
              <h2 className="text-base font-black text-stone-900 flex items-center gap-2">
                <span>⚖️</span>
                <span>{language === 'hi' ? 'मंडी बनाम किसान सेतु — सच क्या है?' : language === 'mr' ? 'मार्केट यार्ड विरुद्ध किसान सेतू — खरा फरक' : 'Pune Mandi vs. Kisan Setu — Real Price Comparison'}</span>
              </h2>
              <p className="text-xs text-stone-600 mt-0.5">
                {language === 'hi' ? 'दलाल हटने से किसान को अधिक पैसा और ग्राहक को कम खर्च' : language === 'mr' ? 'दलाल हटल्यामुळे शेतकऱ्याला जास्त पैसे आणि ग्राहकाला बचत' : 'Removing middlemen gives farmers fair earnings while families pay less'}
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenPriceTransparency}
              className="text-xs font-bold text-emerald-800 hover:underline self-start sm:self-auto cursor-pointer"
            >
              {language === 'hi' ? 'विस्तार से समझें →' : language === 'mr' ? 'सविस्तर पाहा →' : 'View breakdown →'}
            </button>
          </div>

          {/* Simple comparison list */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-lg bg-stone-50 border border-stone-200 space-y-2">
              <span className="font-extrabold text-red-800 block text-xs">
                ❌ {language === 'hi' ? 'पारंपरिक मंडी (दलाल तंत्र)' : language === 'mr' ? 'पारंपरिक मार्केट यार्ड (दलाली)' : 'Traditional Mandi Chain'}
              </span>
              <ul className="space-y-1.5 text-stone-700 font-medium">
                <li className="flex justify-between">
                  <span>{language === 'hi' ? 'टमाटर किसान को मिलता है:' : language === 'mr' ? 'टोमॅटो शेतकऱ्याला मिळतात:' : 'Tomato: Farmer gets:'}</span>
                  <strong className="text-red-700 font-bold">₹12 / kg</strong>
                </li>
                <li className="flex justify-between">
                  <span>{language === 'hi' ? 'दलाल, आढ़ती व रिटेलर कट:' : language === 'mr' ? 'दलाल, अडत्या व किरकोळ नफा:' : 'Middlemen cuts:'}</span>
                  <span className="text-stone-600">+₹23 / kg</span>
                </li>
                <li className="flex justify-between pt-1 border-t border-stone-200 font-bold text-stone-900">
                  <span>{language === 'hi' ? 'पुणे में ग्राहक देता है:' : language === 'mr' ? 'पुण्यात ग्राहक देतो:' : 'Consumer in Pune pays:'}</span>
                  <span>₹35 / kg</span>
                </li>
              </ul>
            </div>

            <div className="p-3.5 rounded-lg bg-[#F0FDF4] border border-emerald-300 space-y-2">
              <span className="font-extrabold text-emerald-900 block text-xs">
                ✅ {language === 'hi' ? 'किसान सेतु (सीधा किसान से)' : language === 'mr' ? 'किसान सेतू (थेट शेतातून)' : 'Kisan Setu Direct'}
              </span>
              <ul className="space-y-1.5 text-stone-700 font-medium">
                <li className="flex justify-between">
                  <span>{language === 'hi' ? 'टमाटर किसान को मिलता है:' : language === 'mr' ? 'टोमॅटो शेतकऱ्याला थेट मिळतात:' : 'Tomato: Farmer gets direct:'}</span>
                  <strong className="text-emerald-800 font-bold text-sm">₹22 / kg</strong>
                </li>
                <li className="flex justify-between">
                  <span>{language === 'hi' ? 'पैकिंग व सीधी डिलीवरी:' : language === 'mr' ? 'पॅकिंग व थेट डिलिव्हरी:' : 'Packing & direct delivery:'}</span>
                  <span className="text-stone-600">+₹4 / kg</span>
                </li>
                <li className="flex justify-between pt-1 border-t border-emerald-200 font-bold text-emerald-950">
                  <span>{language === 'hi' ? 'पुणे में ग्राहक देता है:' : language === 'mr' ? 'पुण्यात ग्राहक देतो:' : 'Consumer in Pune pays:'}</span>
                  <span className="text-sm font-black text-emerald-900">₹26 / kg</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Quick entry bar */}
        <section className="bg-stone-100 rounded-xl p-4 border border-stone-300 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="text-lg">🌾</span>
            <span className="font-bold text-stone-800">
              {language === 'hi' ? 'वाघोली, सासवड व हडपसर से आज ताज़ी फसल उपलब्ध है।' : language === 'mr' ? 'वाघोली, सासवड व हडपसर येथून आज ताजी पिके उपलब्ध आहेत.' : 'Fresh harvests listed today from nearby Pune farms.'}
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              id="home-snapshot-farmer-btn"
              type="button"
              onClick={onSelectFarmer}
              className="flex-1 sm:flex-none font-bold px-3.5 py-2 rounded-lg bg-[#1B5E20] text-white hover:bg-[#154a1a] cursor-pointer"
            >
              {t.sellMyCrop}
            </button>
            <button
              id="home-snapshot-consumer-btn"
              type="button"
              onClick={onSelectConsumer}
              className="flex-1 sm:flex-none font-bold px-3.5 py-2 rounded-lg bg-white border border-stone-300 text-stone-800 hover:bg-stone-50 cursor-pointer"
            >
              {t.buyFresh}
            </button>
          </div>
        </section>

      </div>
    </div>
  );
};
