import React from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { X, Scale, ArrowRight, CheckCircle2 } from 'lucide-react';

interface PriceTransparencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const PriceTransparencyModal: React.FC<PriceTransparencyModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const t = translations[language];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center font-bold">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-stone-900 leading-tight">
                {t.transparencyTitle}
              </h2>
              <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider">
                {t.demoBadge} • {t.tagline}
              </span>
            </div>
          </div>

          <button
            id="transparency-close-btn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          <div className="text-xs text-stone-500 font-medium bg-amber-50/70 p-3 rounded-xl border border-amber-200 text-center">
            ℹ️ {t.illustrativeNote}
          </div>

          {/* Traditional Middleman Chain */}
          <div className="p-4 sm:p-5 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-stone-900 flex items-center gap-1.5">
                <span className="text-red-600">❌</span>
                <span>{t.traditionalChain}</span>
              </h3>
              <span className="text-xs font-bold text-red-700">
                {language === 'hi' ? 'किसान को मात्र 34%' : language === 'mr' ? 'शेतकऱ्याला फक्त ३४%' : 'Farmer gets only ~34%'}
              </span>
            </div>

            {/* Stepper visual */}
            <div className="flex flex-wrap items-center justify-between gap-1 text-[11px] font-semibold text-stone-600 py-2 border-y border-stone-200/80">
              <div className="text-center p-1.5 bg-white rounded-lg border border-stone-200">
                <span className="block text-stone-500">👨‍🌾 Farmer</span>
                <span className="font-bold text-stone-900">₹12</span>
              </div>
              <ArrowRight className="w-3 h-3 text-stone-400" />
              <div className="text-center p-1.5 bg-white rounded-lg border border-stone-200">
                <span className="block text-stone-500">🏢 Agent</span>
                <span className="font-bold text-red-700">+₹4</span>
              </div>
              <ArrowRight className="w-3 h-3 text-stone-400" />
              <div className="text-center p-1.5 bg-white rounded-lg border border-stone-200">
                <span className="block text-stone-500">🚛 Mandi</span>
                <span className="font-bold text-red-700">+₹5</span>
              </div>
              <ArrowRight className="w-3 h-3 text-stone-400" />
              <div className="text-center p-1.5 bg-white rounded-lg border border-stone-200">
                <span className="block text-stone-500">🏪 Trader</span>
                <span className="font-bold text-red-700">+₹6</span>
              </div>
              <ArrowRight className="w-3 h-3 text-stone-400" />
              <div className="text-center p-1.5 bg-white rounded-lg border border-stone-200">
                <span className="block text-stone-500">🛒 Retailer</span>
                <span className="font-bold text-red-700">+₹8</span>
              </div>
            </div>

            <div className="flex justify-between items-center text-xs">
              <span className="text-stone-500">{language === 'hi' ? 'ग्राहक द्वारा कुल भुगतान:' : language === 'mr' ? 'ग्राहकाने दिलेले एकूण मूल्य:' : 'Consumer final price:'}</span>
              <span className="font-black text-stone-900 text-sm">₹35 / kg</span>
            </div>
          </div>

          {/* Kisan Setu Direct Chain */}
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/80 border-2 border-emerald-500/50 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-emerald-950 flex items-center gap-1.5">
                <span className="text-emerald-700">✅</span>
                <span>{t.kisanSetuChain}</span>
              </h3>
              <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                {language === 'hi' ? 'किसान को 85%+' : language === 'mr' ? 'शेतकऱ्याला ८५%+' : 'Farmer gets ~86%'}
              </span>
            </div>

            {/* Stepper visual */}
            <div className="flex items-center justify-between gap-2 text-xs font-semibold text-stone-700 py-3 border-y border-emerald-200">
              <div className="flex-1 text-center p-2.5 bg-white rounded-xl border border-emerald-200 shadow-2xs">
                <span className="block text-stone-500 text-[11px]">👨‍🌾 {language === 'hi' ? 'किसान खाता' : language === 'mr' ? 'शेतकरी खात्यात' : 'Direct to Farmer'}</span>
                <span className="font-black text-emerald-900 text-base">₹24</span>
              </div>
              
              <ArrowRight className="w-4 h-4 text-emerald-700" />

              <div className="flex-1 text-center p-2.5 bg-white rounded-xl border border-emerald-200 shadow-2xs">
                <span className="block text-stone-500 text-[11px]">🌾 {language === 'hi' ? 'किसान सेतु लॉजिस्टिक्स' : language === 'mr' ? 'किसान सेतू डिलिव्हरी' : 'Kisan Setu Pack'}</span>
                <span className="font-bold text-stone-700 text-sm">+₹4</span>
              </div>

              <ArrowRight className="w-4 h-4 text-emerald-700" />

              <div className="flex-1 text-center p-2.5 bg-emerald-700 text-white rounded-xl shadow-2xs">
                <span className="block text-emerald-200 text-[11px]">🛒 {language === 'hi' ? 'ग्राहक मूल्य' : language === 'mr' ? 'ग्राहक मूल्य' : 'You Pay'}</span>
                <span className="font-black text-white text-base">₹28</span>
              </div>
            </div>

            <div className="space-y-1 text-xs text-emerald-900">
              <div className="flex items-center gap-1 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <span>{t.directGainTitle}</span>
              </div>
              <p className="text-[11px] text-emerald-800 leading-relaxed">
                {t.directGainDesc}
              </p>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50 text-center">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl cursor-pointer"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};
