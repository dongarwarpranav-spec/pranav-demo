import React from 'react';
import { Language, EarningsSummary, FarmerTab } from '../types';
import { translations } from '../translations';
import { NEARBY_BUYERS } from '../data';
import { HumanAvatar } from './HumanAvatar';
import { PlusCircle, Package, ArrowRight, Building, CheckCircle2, MessageCircle, MapPin, Users, BellRing, Phone, Sparkles } from 'lucide-react';

interface FarmerHomeProps {
  language: Language;
  earnings: EarningsSummary;
  pendingOrdersCount: number;
  activeCropsCount: number;
  onNavigateTab: (tab: FarmerTab) => void;
  onOpenKisanSathi: () => void;
  onSpeakSummary: () => void;
  onSimulateOrderAlert: () => void;
  isSpeaking: boolean;
}

export const FarmerHome: React.FC<FarmerHomeProps> = ({
  language,
  earnings,
  pendingOrdersCount,
  activeCropsCount,
  onNavigateTab,
  onOpenKisanSathi,
  onSpeakSummary,
  onSimulateOrderAlert,
  isSpeaking,
}) => {
  const t = translations[language];

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      
      {/* Top Welcome Bar */}
      <div className="bg-white rounded-xl border border-stone-300 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="flex items-center gap-3.5">
            <HumanAvatar size="md" isSpeaking={isSpeaking} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-stone-900 leading-tight">
                  {t.farmerGreeting}
                </h1>
                <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[11px] font-bold">
                  {language === 'hi' ? 'सत्यापित किसान' : language === 'mr' ? 'सत्यापित शेतकरी' : 'Verified Farmer'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-stone-600 font-medium mt-0.5">
                {t.farmerQuestion}
              </p>
            </div>
          </div>

          {/* Voice listen button & Test alert simulator */}
          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            <button
              id="farmer-home-voice-read-btn"
              type="button"
              onClick={onSpeakSummary}
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                isSpeaking
                  ? 'bg-emerald-700 text-white border-emerald-800'
                  : 'bg-[#FAF7F0] hover:bg-stone-100 text-stone-800 border-stone-300'
              }`}
            >
              <span>{isSpeaking ? '🛑 ' + t.stopListening : '🗣️ ' + t.listenText}</span>
            </button>

            <button
              id="simulate-order-alert-btn"
              type="button"
              onClick={onSimulateOrderAlert}
              title={t.testAlertSoundNote}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 transition-colors cursor-pointer"
            >
              <BellRing className="w-3.5 h-3.5 text-amber-700 animate-bounce" />
              <span>{t.simulateOrderAlertBtn}</span>
            </button>
          </div>
        </div>
      </div>

      {/* URGENT NOTICE: If an order is waiting, show directly at top */}
      {pendingOrdersCount > 0 && (
        <div className="bg-[#FEF3C7] border-2 border-[#D97706] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <span className="text-2xl animate-bounce">🔔</span>
            <div>
              <h2 className="text-sm sm:text-base font-black text-stone-900">
                {pendingOrdersCount} {t.newOrderAlertTitle}
              </h2>
              <p className="text-xs text-stone-700 mt-0.5">
                {t.newOrderAlertSub}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('orders')}
            className="px-4 py-2 bg-[#B45309] hover:bg-[#92400e] text-white font-bold text-xs sm:text-sm rounded-lg cursor-pointer self-start sm:self-auto"
          >
            {language === 'hi' ? 'ऑर्डर देखें व स्वीकार करें →' : language === 'mr' ? 'ऑर्डर पाहा व स्वीकारा →' : 'Review & Accept →'}
          </button>
        </div>
      )}

      {/* FEATURE 1: 🌾 SELL IN 60 SECONDS (Prominent on Farmer Home) */}
      <section className="bg-white rounded-xl border-2 border-emerald-800 p-4 sm:p-5 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🌾</span>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-stone-900">
                {t.sellIn60SecondsTitle}
              </h2>
              <p className="text-xs text-stone-600">
                {t.sellIn60SecondsSub}
              </p>
            </div>
          </div>

          <span className="text-[11px] font-extrabold uppercase px-2.5 py-1 rounded bg-emerald-100 text-emerald-900 border border-emerald-300">
            ⏱️ 60s
          </span>
        </div>

        {/* Visual Process Explanation: ① Choose Crop ↓ ② Enter Quantity ↓ ③ Set Price ↓ 🎉 Done! */}
        <div className="bg-[#FAF7F0] p-3 rounded-lg border border-stone-200">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs font-bold text-stone-800">
            <div className="p-2 bg-white rounded border border-stone-200 shadow-2xs">
              <span className="text-emerald-800 block text-xs">{t.step1Visual}</span>
              <span className="text-[10px] text-stone-500 font-normal">
                {language === 'hi' ? 'टमाटर, प्याज, आलू...' : language === 'mr' ? 'टोमॅटो, कांदा, बटाटा...' : 'Tomato, Onion...'}
              </span>
            </div>

            <div className="p-2 bg-white rounded border border-stone-200 shadow-2xs">
              <span className="text-emerald-800 block text-xs">{t.step2Visual}</span>
              <span className="text-[10px] text-stone-500 font-normal">
                {language === 'hi' ? '[ − ] 100 kg [ + ]' : language === 'mr' ? '[ − ] १०० kg [ + ]' : '[ − ] 100 kg [ + ]'}
              </span>
            </div>

            <div className="p-2 bg-white rounded border border-stone-200 shadow-2xs">
              <span className="text-emerald-800 block text-xs">{t.step3Visual}</span>
              <span className="text-[10px] text-stone-500 font-normal">
                {language === 'hi' ? 'सुझाव: ₹24–₹25' : language === 'mr' ? 'सुझाव: ₹२४–₹२५' : 'Guide: ₹24–₹25'}
              </span>
            </div>

            <div className="p-2 bg-emerald-50 rounded border border-emerald-300 shadow-2xs">
              <span className="text-emerald-900 block text-xs">{t.step4Visual}</span>
              <span className="text-[10px] text-emerald-700 font-normal">
                {language === 'hi' ? 'खरीदारों को दिखेगी' : language === 'mr' ? 'ग्राहकांना दिसेल' : 'Buyers can see'}
              </span>
            </div>
          </div>
        </div>

        {/* Primary 60s Selling Action Button */}
        <button
          id="farmer-home-sell-crop-main-btn"
          type="button"
          onClick={() => onNavigateTab('sell')}
          className="w-full py-3.5 px-5 bg-[#1B5E20] hover:bg-[#154a1a] text-white font-black text-sm sm:text-base rounded-lg shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-[#134417]"
        >
          <span>🌾</span>
          <span>{t.start60sSell}</span>
          <ArrowRight className="w-4 h-4 ml-1" />
        </button>
      </section>

      {/* FEATURE 3: 📍 FIND NEARBY BUYERS SECTION (Direct on Farmer Home) */}
      <section className="bg-white rounded-xl border border-stone-300 p-4 sm:p-5 space-y-3 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">📍</span>
            <div>
              <h3 className="text-base sm:text-lg font-black text-stone-900">
                {t.findBuyersTitle}
              </h3>
              <p className="text-xs text-stone-500">
                {language === 'hi' ? 'स्थानीय दुकानें और रेस्टोरेंट जो तुरंत फसल खरीदना चाहते हैं' : language === 'mr' ? 'स्थानिक दुकाने आणि हॉटेल्स ज्यांना त्वरित माल हवा आहे' : 'Local buyers looking for bulk produce near you'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('buyers')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
          >
            <span>{language === 'hi' ? 'सभी देखें' : language === 'mr' ? 'सर्व पाहा' : 'View All'}</span>
            <span>→</span>
          </button>
        </div>

        {/* 2 Quick Buyer Previews */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {NEARBY_BUYERS.slice(0, 2).map((buyer) => (
            <div
              key={buyer.id}
              className="bg-[#FAF8F5] p-3 rounded-lg border border-stone-200 flex items-center justify-between gap-2"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="text-lg">{buyer.cropEmoji}</span>
                  <span className="font-black text-stone-900 text-xs sm:text-sm">
                    {buyer.name.split('&')[0].trim()}
                  </span>
                </div>
                <p className="text-[11px] text-stone-500">
                  📍 {buyer.location} • 🚚 {buyer.distanceKm} km
                </p>
                <p className="text-xs font-bold text-emerald-900">
                  {buyer.quantityNeeded} {buyer.unit} {buyer.cropNeeded} @ ₹{buyer.offeredPrice}/{buyer.unit}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onNavigateTab('buyers')}
                className="px-3 py-1.5 bg-[#1B5E20] hover:bg-[#154a1a] text-white text-xs font-bold rounded cursor-pointer shrink-0"
              >
                {t.contactBuyerBtn}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Farmer's Bank & Earnings Card (Clear, honest numbers) */}
      <section className="bg-white rounded-xl border border-stone-300 p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between border-b border-stone-200 pb-2.5">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-stone-600" />
            <span className="text-xs font-bold text-stone-700">
              State Bank of India (SBI) •••• 4920
            </span>
          </div>
          <button
            id="farmer-view-earnings-btn"
            type="button"
            onClick={() => onNavigateTab('earnings')}
            className="text-xs font-bold text-emerald-800 hover:underline cursor-pointer"
          >
            {language === 'hi' ? 'पूरा हिसाब →' : language === 'mr' ? 'पूर्ण हिशोब →' : 'Full Account →'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center pt-1">
          {/* Today */}
          <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
            <span className="text-[11px] font-semibold text-stone-500 block">
              {t.earningsToday}
            </span>
            <span className="text-base sm:text-xl font-black text-stone-900 mt-0.5 block">
              ₹{earnings.today.toLocaleString('en-IN')}
            </span>
          </div>

          {/* This Week */}
          <div className="p-3 bg-stone-50 rounded-lg border border-stone-200">
            <span className="text-[11px] font-semibold text-stone-500 block">
              {t.earningsThisWeek}
            </span>
            <span className="text-base sm:text-xl font-black text-emerald-800 mt-0.5 block">
              ₹{earnings.thisWeek.toLocaleString('en-IN')}
            </span>
          </div>

          {/* Total */}
          <div className="p-3 bg-[#F0FDF4] rounded-lg border border-emerald-200">
            <span className="text-[11px] font-bold text-emerald-800 block">
              {t.earningsTotal}
            </span>
            <span className="text-base sm:text-xl font-black text-emerald-950 mt-0.5 block">
              ₹{earnings.total.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </section>

      {/* Two Direct Action Cards: My Crops & My Orders */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        
        {/* My Crops */}
        <button
          id="farmer-home-my-crops-card"
          type="button"
          onClick={() => onNavigateTab('crops')}
          className="bg-white p-4 rounded-xl border border-stone-300 hover:border-emerald-700 transition-colors text-left flex items-center justify-between cursor-pointer shadow-2xs"
        >
          <div className="flex items-center gap-3">
            <span className="text-2xl p-2 bg-stone-100 rounded-lg border border-stone-200">
              🌱
            </span>
            <div>
              <h4 className="font-bold text-sm sm:text-base text-stone-900">
                {t.myCrops}
              </h4>
              <p className="text-xs text-stone-500 mt-0.5">
                {activeCropsCount} {language === 'hi' ? 'फसलें बिक्री के लिए उपलब्ध' : language === 'mr' ? 'पिके विक्रीसाठी उपलब्ध' : 'crops available'}
              </p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-stone-500" />
        </button>

        {/* My Orders */}
        <button
          id="farmer-home-my-orders-card"
          type="button"
          onClick={() => onNavigateTab('orders')}
          className="bg-white p-4 rounded-xl border border-stone-300 hover:border-amber-700 transition-colors text-left flex items-center justify-between cursor-pointer shadow-2xs"
        >
          <div className="flex items-center gap-3">
            <span className="text-2xl p-2 bg-stone-100 rounded-lg border border-stone-200">
              📦
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-sm sm:text-base text-stone-900">
                  {t.myOrders}
                </h4>
                {pendingOrdersCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-red-600 text-white">
                    {pendingOrdersCount}
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-500 mt-0.5">
                {pendingOrdersCount > 0
                  ? (language === 'hi' ? 'पुष्टि के लिए प्रतीक्षा में' : language === 'mr' ? 'स्वीकारण्यासाठी बाकी' : 'Waiting for confirmation')
                  : (language === 'hi' ? 'सभी ऑर्डर पूरे हो चुके' : language === 'mr' ? 'सर्व ऑर्डर पूर्ण' : 'All orders fulfilled')}
              </p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-stone-500" />
        </button>
      </section>

      {/* Kisan Sathi Voice Help (Friendly person, no robotic AI buzzwords) */}
      <section className="bg-[#FAF7F0] rounded-xl p-4 border border-stone-300 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <HumanAvatar size="md" isSpeaking={isSpeaking} />
          <div>
            <h4 className="font-bold text-sm text-stone-900">
              {t.kisanSathiHelp}
            </h4>
            <p className="text-xs text-stone-600">
              {language === 'hi' ? 'भाव, मौसम या ऑर्डर संबंधी कोई भी सवाल पूछें' : language === 'mr' ? 'भाव, हवामान किंवा ऑर्डर संबंधित काहीही विचारा' : 'Ask any questions about rates, weather or orders'}
            </p>
          </div>
        </div>

        <button
          id="farmer-home-ask-sathi-btn"
          type="button"
          onClick={onOpenKisanSathi}
          className="w-full sm:w-auto px-4 py-2 bg-white hover:bg-stone-50 text-stone-900 font-bold text-xs rounded-lg border border-stone-300 flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
        >
          <MessageCircle className="w-4 h-4 text-emerald-700" />
          <span>{language === 'hi' ? 'बोलकर पूछें' : language === 'mr' ? 'बोलून विचारा' : 'Ask by voice'}</span>
        </button>
      </section>

    </div>
  );
};


