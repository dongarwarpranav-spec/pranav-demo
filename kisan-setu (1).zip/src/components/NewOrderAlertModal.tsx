import React, { useEffect } from 'react';
import { Language, FarmerOrder } from '../types';
import { translations } from '../translations';
import { playOrderAlertChime, speakText } from '../voice';
import { BellRing, Check, CheckCircle2, Volume2, X, ArrowRight, ShieldCheck } from 'lucide-react';

interface NewOrderAlertModalProps {
  language: Language;
  order: FarmerOrder;
  isOpen: boolean;
  onClose: () => void;
  onAcceptOrder: (orderId: string) => void;
  onReviewDetails: (orderId: string) => void;
}

export const NewOrderAlertModal: React.FC<NewOrderAlertModalProps> = ({
  language,
  order,
  isOpen,
  onClose,
  onAcceptOrder,
  onReviewDetails,
}) => {
  const t = translations[language];

  useEffect(() => {
    if (isOpen) {
      // 1. Sound audio chime
      playOrderAlertChime();

      // 2. Voice announcement in farmer's language
      const speechAnnouncement = language === 'hi'
        ? `नया ऑर्डर आया है! ग्राहक ${order.buyerName} ने ${order.quantity} किलो ${order.cropName} का ऑर्डर दिया है। कुल ₹${order.totalPrice}।`
        : language === 'mr'
        ? `नवीन ऑर्डर आला आहे! ग्राहक ${order.buyerName} यांनी ${order.quantity} किलो ${order.cropName} ची ऑर्डर दिली आहे. एकूण ₹${order.totalPrice}।`
        : `New order received! Customer ${order.buyerName} ordered ${order.quantity} kg ${order.cropName} for ₹${order.totalPrice}.`;

      const timer = setTimeout(() => {
        speakText(speechAnnouncement, language);
      }, 400);

      return () => clearTimeout(timer);
    }
  }, [isOpen, order, language]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-alert-title"
    >
      <div className="bg-white rounded-2xl max-w-md w-full border-2 border-emerald-700 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Urgent Header Banner */}
        <div className="bg-[#1B5E20] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-xl animate-bounce">
              🔔
            </div>
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-200">
                {language === 'hi' ? 'ताज़ा सूचना' : language === 'mr' ? 'नवीन सूचना' : 'Live Notification'}
              </span>
              <h2 id="order-alert-title" className="text-lg sm:text-xl font-black leading-tight">
                {t.newOrderAlertTitle}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Order Details Body */}
        <div className="p-5 sm:p-6 space-y-4">
          
          {/* Main highlights */}
          <div className="bg-[#FAF7F0] p-4 rounded-xl border border-stone-300 space-y-3">
            
            {/* Crop & Quantity */}
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{order.cropEmoji}</span>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-stone-900">
                    {order.quantity} {t.unitKg} {order.cropName}
                  </h3>
                  <span className="text-xs text-stone-500 font-medium">
                    ₹{order.pricePerUnit} / {t.unitKg}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-stone-500 block font-semibold">
                  {language === 'hi' ? 'कुल राशि' : language === 'mr' ? 'एकूण रक्कम' : 'Offer Value'}
                </span>
                <span className="text-xl sm:text-2xl font-black text-emerald-900">
                  ₹{order.totalPrice}
                </span>
              </div>
            </div>

            {/* Customer & Location */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-stone-500 block font-medium">
                  {language === 'hi' ? 'ग्राहक:' : language === 'mr' ? 'ग्राहक:' : 'Customer:'}
                </span>
                <span className="font-bold text-stone-900 text-sm">
                  {order.buyerName}
                </span>
                <span className="text-[11px] text-stone-500 block">
                  📍 {order.buyerLocation}
                </span>
              </div>

              <div>
                <span className="text-stone-500 block font-medium">
                  {language === 'hi' ? 'भुगतान माध्यम:' : language === 'mr' ? 'पेमेंट प्रकार:' : 'Payment:'}
                </span>
                <span className="font-bold text-emerald-800 text-sm inline-flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  <span>UPI / Direct Bank</span>
                </span>
                <span className="text-[11px] text-stone-500 block">
                  {language === 'hi' ? '0% दलाली कटौती' : language === 'mr' ? '०% कमिशन कपात' : '0% Broker Fee'}
                </span>
              </div>
            </div>

          </div>

          {/* Audio repeat trigger */}
          <div className="flex items-center justify-between px-1">
            <span className="text-xs text-stone-500 font-medium flex items-center gap-1.5">
              <span>🔊</span>
              <span>{language === 'hi' ? 'ध्वनि एवं आवाज़ में संदेश' : language === 'mr' ? 'आवाजात सूचना ऐका' : 'Audio announcement played'}</span>
            </span>
            <button
              type="button"
              onClick={() => {
                playOrderAlertChime();
                const text = language === 'hi'
                  ? `नया ऑर्डर! ${order.buyerName}, ${order.quantity} किलो ${order.cropName}, कुल ₹${order.totalPrice}।`
                  : language === 'mr'
                  ? `नवीन ऑर्डर! ${order.buyerName}, ${order.quantity} किलो ${order.cropName}, एकूण ₹${order.totalPrice}।`
                  : `New order from ${order.buyerName} for ${order.quantity} kg ${order.cropName}, total ₹${order.totalPrice}.`;
                speakText(text, language);
              }}
              className="text-xs font-bold text-emerald-800 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{t.listenText}</span>
            </button>
          </div>

          {/* Action Buttons: [ Accept Order ] & [ Review Details ] */}
          <div className="space-y-2.5 pt-1">
            <button
              id="accept-order-alert-btn"
              type="button"
              onClick={() => onAcceptOrder(order.id)}
              className="w-full py-4 px-5 bg-[#1B5E20] hover:bg-[#154a1a] text-white font-black text-base rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>{t.acceptOrderBtn} (₹{order.totalPrice})</span>
            </button>

            <button
              id="review-order-alert-btn"
              type="button"
              onClick={() => onReviewDetails(order.id)}
              className="w-full py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm rounded-xl border border-stone-300 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>{language === 'hi' ? 'ऑर्डर का पूरा विवरण देखें' : language === 'mr' ? 'ऑर्डरचा पूर्ण तपशील पाहा' : 'Review Details'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
