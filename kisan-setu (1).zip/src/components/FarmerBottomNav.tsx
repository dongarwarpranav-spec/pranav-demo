import React from 'react';
import { Language, FarmerTab } from '../types';
import { translations } from '../translations';
import { Home, Sprout, Package, IndianRupee, Users } from 'lucide-react';

interface FarmerBottomNavProps {
  language: Language;
  activeTab: FarmerTab;
  onSelectTab: (tab: FarmerTab) => void;
  pendingOrdersCount: number;
}

export const FarmerBottomNav: React.FC<FarmerBottomNavProps> = ({
  language,
  activeTab,
  onSelectTab,
  pendingOrdersCount,
}) => {
  const t = translations[language];

  return (
    <nav
      id="farmer-bottom-navigation"
      aria-label="Farmer Navigation"
      className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-stone-200 shadow-lg md:hidden"
    >
      <div className="max-w-md mx-auto grid grid-cols-5 h-16">
        
        {/* Home */}
        <button
          id="farmer-tab-home"
          type="button"
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
            activeTab === 'home' ? 'text-emerald-800 font-bold' : 'text-stone-500 font-medium'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">{t.home}</span>
        </button>

        {/* My Crops */}
        <button
          id="farmer-tab-crops"
          type="button"
          onClick={() => onSelectTab('crops')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
            activeTab === 'crops' ? 'text-emerald-800 font-bold' : 'text-stone-500 font-medium'
          }`}
        >
          <Sprout className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">{t.myCrops}</span>
        </button>

        {/* Find Buyers */}
        <button
          id="farmer-tab-buyers"
          type="button"
          onClick={() => onSelectTab('buyers')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
            activeTab === 'buyers' ? 'text-emerald-800 font-bold' : 'text-stone-500 font-medium'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">{t.findBuyersTitle}</span>
        </button>

        {/* Orders */}
        <button
          id="farmer-tab-orders"
          type="button"
          onClick={() => onSelectTab('orders')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
            activeTab === 'orders' ? 'text-emerald-800 font-bold' : 'text-stone-500 font-medium'
          }`}
        >
          <Package className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">{t.myOrders}</span>
          {pendingOrdersCount > 0 && (
            <span className="absolute top-2 right-4 w-2 h-2 rounded-full bg-red-600 animate-ping" />
          )}
        </button>

        {/* Earnings */}
        <button
          id="farmer-tab-earnings"
          type="button"
          onClick={() => onSelectTab('earnings')}
          className={`flex flex-col items-center justify-center min-h-[44px] transition-colors cursor-pointer ${
            activeTab === 'earnings' ? 'text-emerald-800 font-bold' : 'text-stone-500 font-medium'
          }`}
        >
          <IndianRupee className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] leading-tight">{t.myEarnings}</span>
        </button>

      </div>
    </nav>
  );
};

