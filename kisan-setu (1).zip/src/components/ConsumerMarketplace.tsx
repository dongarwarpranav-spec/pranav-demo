import React, { useState, useMemo } from 'react';
import { Language, Product, CartItem } from '../types';
import { translations } from '../translations';
import { HumanAvatar } from './HumanAvatar';
import { 
  Search, 
  MapPin, 
  Mic, 
  Plus, 
  Minus, 
  ShieldCheck, 
  Link2, 
  Clock, 
  Zap, 
  SlidersHorizontal, 
  ChevronDown, 
  Tag, 
  Sparkles,
  ArrowRight,
  ShoppingBag
} from 'lucide-react';

interface ConsumerMarketplaceProps {
  language: Language;
  products: Product[];
  onAddToCart: (product: Product, quantity: number) => void;
  onOpenProductHistory: (product: Product) => void;
  onOpenPriceTransparency: () => void;
  onStartVoiceSearch: () => void;
  isListeningVoiceSearch: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  cartCount?: number;
  onOpenCart?: () => void;
}

export const ConsumerMarketplace: React.FC<ConsumerMarketplaceProps> = ({
  language,
  products,
  onAddToCart,
  onOpenProductHistory,
  onOpenPriceTransparency,
  onStartVoiceSearch,
  isListeningVoiceSearch,
  searchQuery,
  setSearchQuery,
  cartCount = 0,
  onOpenCart,
}) => {
  const t = translations[language];

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSort, setSelectedSort] = useState<'recommended' | 'price_low' | 'distance' | 'freshness'>('recommended');
  const [filterOrganicOnly, setFilterOrganicOnly] = useState<boolean>(false);
  const [productQuantities, setProductQuantities] = useState<Record<string, number>>({});

  const categories = [
    { id: 'all', label: t.categoryAll, emoji: '🧺', count: '12 items' },
    { id: 'vegetable', label: t.categoryVegetables, emoji: '🥬', count: '6 items' },
    { id: 'fruit', label: t.categoryFruits, emoji: '🍎', count: '3 items' },
    { id: 'grain', label: t.categoryGrains, emoji: '🌾', count: '2 items' },
    { id: 'dairy', label: t.categoryDairy, emoji: '🥛', count: '1 item' },
  ];

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = products.filter((item) => {
      const translatedName = t[item.nameKey as keyof typeof t] as string || item.nameDefault;
      const matchesSearch =
        searchQuery.trim() === '' ||
        translatedName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.nameDefault.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.farmerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.farmerLocation.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory =
        selectedCategory === 'all' || item.category === selectedCategory;

      const matchesOrganic = !filterOrganicOnly || item.soilTested;

      return matchesSearch && matchesCategory && matchesOrganic;
    });

    if (selectedSort === 'price_low') {
      result.sort((a, b) => a.pricePerKg - b.pricePerKg);
    } else if (selectedSort === 'distance') {
      result.sort((a, b) => a.distanceKm - b.distanceKm);
    } else if (selectedSort === 'freshness') {
      // Harvested today first
      result.sort((a, b) => (b.harvestDate.includes('Today') ? 1 : 0) - (a.harvestDate.includes('Today') ? 1 : 0));
    }

    return result;
  }, [products, searchQuery, selectedCategory, selectedSort, filterOrganicOnly, t]);

  const getQuantityForProduct = (productId: string) => {
    return productQuantities[productId] || 1;
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    const current = getQuantityForProduct(productId);
    const updated = Math.max(1, Math.min(50, current + delta));
    setProductQuantities((prev) => ({ ...prev, [productId]: updated }));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      
      {/* 1. Swiggy Instamart-Style Location & Delivery Speed Hero Bar */}
      <div className="bg-gradient-to-r from-[#FC8019] via-[#FF6D00] to-[#E65100] text-white rounded-2xl p-5 shadow-lg relative overflow-hidden">
        {/* Subtle patterned backdrop */}
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-8 text-8xl">
          🌾
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-black/25 backdrop-blur-xs text-white px-2.5 py-1 rounded-full text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                <span>INSTA-FARM DIRECT</span>
              </span>
              <span className="bg-white/20 text-white px-2.5 py-1 rounded-full text-[11px] font-extrabold flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>15-25 MINS</span>
              </span>
              <span className="bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded-full text-[10px] font-bold">
                0% Middleman
              </span>
            </div>

            <div className="flex items-center gap-2 pt-0.5">
              <MapPin className="w-5 h-5 text-amber-200 shrink-0" />
              <div className="flex items-baseline gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight leading-tight">
                  Wakad & Haveli, Pune
                </h1>
                <span className="text-xs text-amber-100 font-medium hidden sm:inline">
                  (Delivering direct from Wagholi & Saswad farms)
                </span>
              </div>
            </div>
            
            <p className="text-xs sm:text-sm text-white/90 font-medium">
              {language === 'hi' 
                ? 'स्थानीय किसानों से सीधे ताजा फसलें — शहर की दुकानों से 35% सस्ती और 100% ताजा।' 
                : language === 'mr' 
                ? 'स्थानिक शेतकऱ्यांकडून थेट ताजी पिके — शहरातील दुकानांपेक्षा ३५% स्वस्त आणि १००% ताजी.' 
                : 'Direct from verified farm gates. 0% broker fee. 100% farmer payment.'}
            </p>
          </div>

          {/* Quick Stats / Transparency Modal Trigger */}
          <div className="flex items-center gap-2.5 self-start md:self-auto">
            <button
              id="marketplace-price-transparency-btn"
              type="button"
              onClick={onOpenPriceTransparency}
              className="bg-white hover:bg-stone-50 text-stone-900 px-4 py-2.5 rounded-xl text-xs font-black shadow-sm transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <span>⚖️</span>
              <span>{t.priceBreakdownLink}</span>
            </button>

            {cartCount > 0 && onOpenCart && (
              <button
                type="button"
                onClick={onOpenCart}
                className="bg-stone-900 hover:bg-black text-white px-4 py-2.5 rounded-xl text-xs font-black shadow-sm transition-all flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <ShoppingBag className="w-4 h-4 text-orange-400" />
                <span>{cartCount} in Basket</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Swiggy-Style Search Bar with Voice Assist & Prompts */}
      <div className="space-y-2">
        <div className="relative flex items-center shadow-xs">
          <div className="absolute left-4 pointer-events-none text-stone-400">
            <Search className="w-5 h-5 text-orange-500" />
          </div>

          <input
            id="consumer-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              language === 'hi'
                ? 'खोजें "टमाटर", "प्याज़", "रमेश पाटिल" या "वाघोली"...'
                : language === 'mr'
                ? 'शोधा "टोमॅटो", "कांदा", "रमेश पाटील" किंवा "वाघोली"...'
                : 'Search "Tomatoes", "Onions", "Ramesh Patil" or "Wagholi farm"...'
            }
            className="w-full pl-12 pr-36 py-3.5 bg-white rounded-2xl border-2 border-stone-200 focus:border-[#FC8019] focus:ring-2 focus:ring-orange-200 focus:outline-none text-stone-900 text-sm font-semibold transition-all shadow-2xs"
          />

          {/* Voice Search with Friendly Avatar */}
          <button
            id="consumer-voice-search-btn"
            type="button"
            onClick={onStartVoiceSearch}
            title={t.speakToSearch}
            className={`absolute right-2 px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              isListeningVoiceSearch
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-orange-50 hover:bg-orange-100 text-orange-950 border border-orange-200'
            }`}
          >
            <HumanAvatar size="sm" isSpeaking={isListeningVoiceSearch} />
            <span className="hidden sm:inline font-black">
              {isListeningVoiceSearch ? t.listeningNow : t.speakToSearch}
            </span>
            <Mic className="w-4 h-4 sm:hidden text-orange-600" />
          </button>
        </div>

        {/* Voice prompt hint */}
        {isListeningVoiceSearch && (
          <p className="text-xs text-center font-bold text-red-700 animate-pulse">
            🎙️ {t.voiceSearchPrompt}
          </p>
        )}
      </div>

      {/* 3. Swiggy Instamart Category Grid / Story Bubbles */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black uppercase tracking-wider text-stone-500">
            {language === 'hi' ? 'श्रेणियां' : language === 'mr' ? 'श्रेण्या' : 'Explore Farm Categories'}
          </span>
          <span className="text-xs font-bold text-orange-600">Direct Delivery ⚡</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                id={`category-filter-${cat.id}`}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-orange-50 border-[#FC8019] shadow-sm ring-2 ring-orange-200'
                    : 'bg-white hover:bg-stone-50 border-stone-200 shadow-2xs'
                }`}
              >
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-2xl shrink-0 ${
                  isSelected ? 'bg-orange-100' : 'bg-stone-100'
                }`}>
                  {cat.emoji}
                </div>
                <div className="min-w-0">
                  <span className={`text-xs sm:text-sm font-black block truncate ${
                    isSelected ? 'text-orange-950' : 'text-stone-900'
                  }`}>
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-stone-400 font-medium block">
                    {cat.count}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Swiggy Quick Filter Pills (Sorting, Soil-tested) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span className="text-stone-400 font-bold flex items-center gap-1 shrink-0 pl-1">
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Filters:</span>
        </span>

        <button
          type="button"
          onClick={() => setSelectedSort('recommended')}
          className={`px-3 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap cursor-pointer ${
            selectedSort === 'recommended'
              ? 'bg-stone-900 text-white'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          Featured 🌟
        </button>

        <button
          type="button"
          onClick={() => setSelectedSort('price_low')}
          className={`px-3 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap cursor-pointer ${
            selectedSort === 'price_low'
              ? 'bg-stone-900 text-white'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          Lowest Price 💰
        </button>

        <button
          type="button"
          onClick={() => setSelectedSort('distance')}
          className={`px-3 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap cursor-pointer ${
            selectedSort === 'distance'
              ? 'bg-stone-900 text-white'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          Fastest Delivery ⚡
        </button>

        <button
          type="button"
          onClick={() => setSelectedSort('freshness')}
          className={`px-3 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap cursor-pointer ${
            selectedSort === 'freshness'
              ? 'bg-stone-900 text-white'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-100'
          }`}
        >
          Harvested Today ⏱️
        </button>

        <button
          type="button"
          onClick={() => setFilterOrganicOnly(!filterOrganicOnly)}
          className={`px-3 py-1.5 rounded-full font-bold transition-colors whitespace-nowrap cursor-pointer ${
            filterOrganicOnly
              ? 'bg-emerald-800 text-white'
              : 'bg-white text-emerald-800 border border-emerald-300 hover:bg-emerald-50'
          }`}
        >
          Soil Tested ✓
        </button>
      </div>

      {/* 5. Main Swiggy Food/Grocery Style Products Bento Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-black text-stone-900 flex items-center gap-2">
              <span>🌱</span>
              <span>{t.freshNearYou}</span>
            </h2>
            <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-600 text-xs font-bold">
              {filteredProducts.length} {t.itemsCount}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-stone-500 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
            <span>Live farm stock</span>
          </div>
        </div>

        {/* Empty state */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-10 border border-stone-200 text-center space-y-3 shadow-sm">
            <span className="text-4xl block">🔍</span>
            <h3 className="text-base font-black text-stone-900">{t.noCropsFound}</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              {t.tryAnotherSearch}
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setFilterOrganicOnly(false);
                setSelectedSort('recommended');
              }}
              className="px-5 py-2.5 bg-[#FC8019] hover:bg-[#e46f10] text-white font-black text-xs rounded-xl cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
            {filteredProducts.map((prod) => {
              const translatedName = t[prod.nameKey as keyof typeof t] as string || prod.nameDefault;
              const currentQty = getQuantityForProduct(prod.id);
              // Market retail rate for consumer perception
              const estimatedRetailRate = Math.round(prod.pricePerKg * 1.38);
              const savingsPercentage = Math.round(((estimatedRetailRate - prod.pricePerKg) / estimatedRetailRate) * 100);

              return (
                <div
                  key={prod.id}
                  id={`product-card-${prod.id}`}
                  className="bg-white rounded-2xl border border-stone-200 shadow-2xs hover:shadow-md hover:border-orange-200 transition-all overflow-hidden flex flex-col justify-between group"
                >
                  {/* Real Crop Photo with Swiggy Delivery ETA & Badges */}
                  <div className="relative h-44 w-full bg-stone-100 overflow-hidden">
                    <img
                      src={prod.image}
                      alt={translatedName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    
                    {/* Swiggy Style Delivery Time Badge */}
                    <div className="absolute bottom-2.5 left-2.5 bg-stone-900/90 backdrop-blur-xs text-white px-2.5 py-1 rounded-lg text-[11px] font-black flex items-center gap-1.5 shadow-sm">
                      <Clock className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{Math.round(prod.distanceKm * 4 + 10)} mins</span>
                      <span className="text-stone-400">•</span>
                      <span>{prod.distanceKm} km</span>
                    </div>

                    {/* Savings pill */}
                    <div className="absolute top-2.5 left-2.5 bg-[#1B5E20] text-white px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider shadow-sm">
                      {savingsPercentage}% OFF RETAIL
                    </div>

                    {/* Fresh Harvest Pill */}
                    <div className="absolute top-2.5 right-2.5 bg-white/95 backdrop-blur-xs text-emerald-950 px-2 py-0.5 rounded-md text-[10px] font-extrabold border border-emerald-200 shadow-2xs">
                      ⏱️ {prod.harvestDate.split(',')[0]}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Name & Pricing Header */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-black text-base text-stone-900 leading-snug">
                            {translatedName}
                          </h3>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-base font-black text-stone-900">
                              ₹{prod.pricePerKg}
                            </span>
                            <span className="text-xs text-stone-400 line-through">
                              ₹{estimatedRetailRate}
                            </span>
                            <span className="text-[10px] font-bold text-emerald-700">
                              /{t.unitKg}
                            </span>
                          </div>
                        </div>

                        <span className="text-2xl">{prod.emoji}</span>
                      </div>

                      {/* Farmer Profile & Village */}
                      <div className="mt-2.5 p-2.5 bg-[#FAF7F0] rounded-xl border border-stone-200/80 space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-stone-900">
                          <span className="flex items-center gap-1 truncate">
                            <span>👨‍🌾</span>
                            <span className="truncate">{prod.farmerName}</span>
                          </span>
                          <span className="text-[10px] text-emerald-800 font-black flex items-center gap-0.5 shrink-0">
                            <ShieldCheck className="w-3 h-3 text-emerald-700" />
                            <span>100% Direct</span>
                          </span>
                        </div>

                        <div className="text-[11px] text-stone-500 flex items-center justify-between">
                          <span className="flex items-center gap-1 truncate">
                            <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
                            <span className="truncate">{prod.farmerLocation}</span>
                          </span>
                          <span className="font-bold text-stone-700 shrink-0">
                            {prod.availableKg} kg left
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Traceability link */}
                    <button
                      id={`prod-history-btn-${prod.id}`}
                      type="button"
                      onClick={() => onOpenProductHistory(prod)}
                      className="w-full text-left flex items-center justify-between text-xs font-bold text-emerald-800 hover:text-emerald-950 py-1 cursor-pointer transition-colors"
                    >
                      <span className="flex items-center gap-1">
                        <Link2 className="w-3.5 h-3.5" />
                        <span>{t.viewProductHistory}</span>
                      </span>
                      <span className="text-[10px] font-semibold text-stone-400">
                        {language === 'hi' ? 'खेत रिकॉर्ड →' : language === 'mr' ? 'शेत नोंद →' : 'Farm record →'}
                      </span>
                    </button>

                    {/* Swiggy Style Stepper & Add Button */}
                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                      {/* Quantity Stepper */}
                      <div className="flex items-center bg-stone-100 rounded-xl p-0.5 border border-stone-200">
                        <button
                          type="button"
                          onClick={() => handleUpdateQuantity(prod.id, -1)}
                          className="w-7 h-7 rounded-lg bg-white flex items-center justify-center text-stone-800 font-bold hover:bg-stone-50 active:scale-95 cursor-pointer shadow-2xs"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-10 text-center text-xs font-black text-stone-900">
                          {currentQty}kg
                        </span>
                        <button
                          type="button"
                          onClick={() => handleUpdateQuantity(prod.id, 1)}
                          className="w-7 h-7 rounded-lg bg-white flex items-center justify-center text-stone-800 font-bold hover:bg-stone-50 active:scale-95 cursor-pointer shadow-2xs"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Swiggy Orange 'ADD' CTA Button */}
                      <button
                        id={`add-to-basket-btn-${prod.id}`}
                        type="button"
                        onClick={() => onAddToCart(prod, currentQty)}
                        className="flex-1 py-2.5 px-3 bg-white hover:bg-orange-50 active:bg-orange-100 text-[#FC8019] border-2 border-[#FC8019] font-black text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <span>ADD</span>
                        <span className="text-[11px] font-bold text-stone-500">
                          • ₹{currentQty * prod.pricePerKg}
                        </span>
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Bottom Cart Bar for Mobile (Swiggy Signature Sticky Strip) */}
      {cartCount > 0 && onOpenCart && (
        <div className="fixed bottom-4 left-4 right-4 z-40 max-w-md mx-auto sm:hidden">
          <button
            type="button"
            onClick={onOpenCart}
            className="w-full bg-[#FC8019] hover:bg-[#e46f10] text-white p-3.5 rounded-2xl shadow-xl flex items-center justify-between font-black text-sm cursor-pointer animate-in slide-in-from-bottom-3 duration-200"
          >
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-xs">
                {cartCount}
              </span>
              <span>{language === 'hi' ? 'टोकरी देखें' : language === 'mr' ? 'बास्केट पाहा' : 'View Basket'}</span>
            </div>
            <div className="flex items-center gap-1 text-xs uppercase tracking-wider bg-black/15 px-3 py-1 rounded-xl">
              <span>Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </button>
        </div>
      )}

    </div>
  );
};
