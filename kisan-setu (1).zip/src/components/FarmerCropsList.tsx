import React from 'react';
import { Language, FarmerCrop } from '../types';
import { translations } from '../translations';
import { Plus, CheckCircle, Clock } from 'lucide-react';

interface FarmerCropsListProps {
  language: Language;
  crops: FarmerCrop[];
  onAddNewCrop: () => void;
  onToggleStatus: (cropId: string) => void;
  onGoBack: () => void;
}

export const FarmerCropsList: React.FC<FarmerCropsListProps> = ({
  language,
  crops,
  onAddNewCrop,
  onToggleStatus,
  onGoBack,
}) => {
  const t = translations[language];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-stone-900 tracking-tight flex items-center gap-2">
            <span>🌱</span>
            <span>{t.activeCropsTitle}</span>
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
            {language === 'hi' ? 'आपकी वर्तमान में उपलब्ध फसलें' : language === 'mr' ? 'आपली सध्या विक्रीसाठी असलेली पिके' : 'Your currently listed harvests'}
          </p>
        </div>

        <button
          id="farmer-crops-add-new-btn"
          type="button"
          onClick={onAddNewCrop}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-sm transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t.addNewCropBtn}</span>
        </button>
      </div>

      {/* Crops List or Empty State */}
      {crops.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-stone-200 text-center space-y-4">
          <span className="text-5xl block">🌱</span>
          <div className="space-y-1 max-w-sm mx-auto">
            <h3 className="text-lg font-bold text-stone-900">{t.noCropsYet}</h3>
            <p className="text-xs sm:text-sm text-stone-500">{t.noCropsSub}</p>
          </div>
          <button
            type="button"
            onClick={onAddNewCrop}
            className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-xl shadow-sm cursor-pointer"
          >
            {t.addNewCropBtn}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {crops.map((crop) => (
            <div
              key={crop.id}
              className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 flex flex-col justify-between space-y-4 hover:border-emerald-300 transition-colors"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-4xl p-2.5 bg-stone-50 rounded-xl border border-stone-200">
                    {crop.emoji}
                  </span>
                  <div>
                    <h3 className="font-extrabold text-base text-stone-900 leading-tight">
                      {crop.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-stone-500 mt-1">
                      <Clock className="w-3 h-3" />
                      <span>{crop.dateListed}</span>
                    </div>
                  </div>
                </div>

                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    crop.status === 'active'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-700'
                  }`}
                >
                  {crop.status === 'active' ? (language === 'hi' ? 'सक्रिय' : language === 'mr' ? 'उपलब्ध' : 'Active') : (language === 'hi' ? 'बिका' : language === 'mr' ? 'विकले' : 'Sold Out')}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 bg-stone-50 p-3 rounded-xl border border-stone-100 text-center">
                <div>
                  <span className="text-[11px] text-stone-500 block font-medium">
                    {t.availableStock}
                  </span>
                  <span className="text-sm font-bold text-stone-900">
                    {crop.quantity} {crop.unit}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-stone-500 block font-medium">
                    {t.pricePerKgLabel}
                  </span>
                  <span className="text-sm font-bold text-emerald-800">
                    ₹{crop.pricePerUnit} / {crop.unit}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                <span className="text-xs text-stone-500 font-medium">
                  {language === 'hi' ? 'अनुमानित कुल:' : language === 'mr' ? 'एकूण उत्पन्न:' : 'Total Value:'}{' '}
                  <strong className="text-stone-900">₹{(crop.quantity * crop.pricePerUnit).toLocaleString('en-IN')}</strong>
                </span>

                <button
                  type="button"
                  onClick={() => onToggleStatus(crop.id)}
                  className="text-xs font-bold text-stone-600 hover:text-emerald-800 cursor-pointer"
                >
                  {crop.status === 'active' ? t.markSoldOut : t.markActive}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
