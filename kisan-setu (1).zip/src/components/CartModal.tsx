import React, { useState } from 'react';
import { Language, CartItem } from '../types';
import { translations } from '../translations';
import { 
  X, 
  Minus, 
  Plus, 
  Trash2, 
  ArrowRight, 
  ShoppingBag, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  CreditCard, 
  CheckCircle2, 
  Tag, 
  Sparkles,
  Info
} from 'lucide-react';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckoutComplete: () => void;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  language,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckoutComplete,
}) => {
  const t = translations[language];

  const [address, setAddress] = useState<string>('Flat 402, Green Meadows, Wakad, Pune');
  const [addressType, setAddressType] = useState<'home' | 'work' | 'other'>('home');
  const [cookingInstructions, setCookingInstructions] = useState<string>('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'upi' | 'cod' | 'card'>('upi');
  const [tipAmount, setTipAmount] = useState<number>(10);
  const [isOrdered, setIsOrdered] = useState<boolean>(false);
  const [couponCode, setCouponCode] = useState<string>('DIRECTFARM');
  const [couponApplied, setCouponApplied] = useState<boolean>(true);

  if (!isOpen) return null;

  const itemTotal = cartItems.reduce(
    (acc, item) => acc + item.product.pricePerKg * item.quantity,
    0
  );
  
  // Swiggy style transparent breakdown
  const discountAmount = couponApplied ? Math.min(40, Math.round(itemTotal * 0.1)) : 0;
  const deliveryPartnerFee = 0; // FREE Farm direct delivery
  const handlingCharges = 5; // Direct packaging & hygiene
  const platformFee = 0; // 0% commission promise
  const grandTotal = Math.max(0, itemTotal - discountAmount + deliveryPartnerFee + handlingCharges + tipAmount);

  const handlePlaceOrder = () => {
    setIsOrdered(true);
    setTimeout(() => {
      onCheckoutComplete();
      setIsOrdered(false);
      onClose();
    }, 2200);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-end sm:justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="swiggy-cart-title"
    >
      <div className="bg-[#F4F5F7] h-full sm:h-auto sm:max-h-[92vh] max-w-lg w-full sm:rounded-3xl flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        
        {/* Swiggy Instamart-style Header */}
        <div className="bg-white px-5 py-4 border-b border-stone-200 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center font-bold">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="swiggy-cart-title" className="text-base font-black text-stone-900 leading-tight">
                  {language === 'hi' ? 'आपकी टोकरी' : language === 'mr' ? 'तुमची बास्केट' : 'Your Basket'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase tracking-wider">
                  INSTA-FARM
                </span>
              </div>
              <p className="text-xs text-stone-500 font-medium flex items-center gap-1.5 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-emerald-700" />
                <span>{language === 'hi' ? 'डिलीवरी: 15-25 मिनट' : language === 'mr' ? 'डिलिव्हरी: १५-२५ मिनिटे' : 'Delivering in 15-25 mins'}</span>
              </p>
            </div>
          </div>

          <button
            id="swiggy-cart-close-btn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 flex items-center justify-center cursor-pointer transition-colors"
            aria-label="Close cart"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto flex-1 p-4 space-y-4">
          
          {isOrdered ? (
            /* Order placed celebration screen */
            <div className="bg-white rounded-2xl p-8 border border-stone-200 text-center space-y-4 shadow-sm my-auto">
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-500 to-emerald-600 text-white flex items-center justify-center mx-auto text-4xl shadow-md animate-bounce">
                🚀
              </div>
              <span className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-800 font-black text-xs uppercase tracking-wider">
                {language === 'hi' ? 'ऑर्डर पुष्टि हो गई' : language === 'mr' ? 'ऑर्डर पुष्टी झाली' : 'Order Confirmed!'}
              </span>
              <h3 className="text-xl font-black text-stone-900">
                {t.orderPlacedTitle}
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 max-w-xs mx-auto">
                {language === 'hi'
                  ? 'किसान को सूचना भेज दी गई है। फसल पैक होकर 15-25 मिनट में आपके पते पर पहुंचेगी।'
                  : language === 'mr'
                  ? 'शेतकऱ्याला थेट सूचना पाठवली आहे. १५-२५ मिनिटांत ताजे पीक थेट पोहोचेल.'
                  : 'Farmer alerted directly with zero intermediary cut. Delivery partner is assigned!'}
              </p>
              
              <div className="p-3 bg-[#FAF7F0] rounded-xl border border-stone-200 text-xs font-bold text-stone-800 flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>100% Direct Payout to Farmer • 0% Broker Cut</span>
              </div>
            </div>
          ) : cartItems.length === 0 ? (
            /* Empty Basket State */
            <div className="bg-white rounded-2xl p-8 border border-stone-200 text-center space-y-4 shadow-sm">
              <div className="w-20 h-20 rounded-2xl bg-orange-50 text-orange-500 flex items-center justify-center mx-auto text-4xl">
                🧺
              </div>
              <h3 className="text-lg font-black text-stone-900">
                {t.basketEmptyTitle}
              </h3>
              <p className="text-xs text-stone-500 max-w-xs mx-auto">
                {t.basketEmptySub}
              </p>
              <button
                id="cart-start-shopping-btn"
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 bg-[#FC8019] hover:bg-[#e46f10] text-white font-black text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                {t.startShoppingBtn}
              </button>
            </div>
          ) : (
            <>
              {/* Delivery Address Card (Swiggy Style) */}
              <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-orange-600" />
                    <span className="text-xs font-black text-stone-900 uppercase tracking-wide">
                      {language === 'hi' ? 'डिलीवरी का पता' : language === 'mr' ? 'डिलिव्हरी पत्ता' : 'Delivery Address'}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    {(['home', 'work', 'other'] as const).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setAddressType(type)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition-colors ${
                          addressType === type 
                            ? 'bg-stone-900 text-white' 
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>
                
                <input
                  id="swiggy-delivery-address-input"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={t.addressPlaceholder}
                  className="w-full px-3 py-2 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-900 font-semibold focus:outline-none focus:border-orange-500 focus:bg-white transition-colors"
                />
              </div>

              {/* Items in Cart Card */}
              <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                  <span className="text-xs font-black text-stone-900 uppercase tracking-wide">
                    {cartItems.length} {t.itemsCount}
                  </span>
                  <span className="text-[11px] font-bold text-emerald-700">
                    🌱 {language === 'hi' ? 'खेत से ताज़ा चयनित' : language === 'mr' ? 'थेट शेतातून ताजे' : 'Harvested today'}
                  </span>
                </div>

                <div className="divide-y divide-stone-100">
                  {cartItems.map((item) => {
                    const translatedName = t[item.product.nameKey as keyof typeof t] as string || item.product.nameDefault;
                    const lineTotal = item.product.pricePerKg * item.quantity;

                    return (
                      <div key={item.product.id} className="py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{item.product.emoji}</span>
                          <div>
                            <h4 className="text-xs sm:text-sm font-black text-stone-900 leading-tight">
                              {translatedName}
                            </h4>
                            <p className="text-[11px] text-stone-500">
                              ₹{item.product.pricePerKg} / kg • {item.product.farmerName}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {/* Swiggy Green Pill Counter */}
                          <div className="flex items-center bg-white border border-emerald-600 rounded-lg overflow-hidden shadow-2xs">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(item.product.id, -1)}
                              className="w-7 h-7 flex items-center justify-center text-emerald-800 hover:bg-emerald-50 active:bg-emerald-100 transition-colors font-black cursor-pointer"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3 h-3 stroke-[3]" />
                            </button>
                            <span className="w-8 text-center text-xs font-black text-emerald-900">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(item.product.id, 1)}
                              className="w-7 h-7 flex items-center justify-center text-emerald-800 hover:bg-emerald-50 active:bg-emerald-100 transition-colors font-black cursor-pointer"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3 h-3 stroke-[3]" />
                            </button>
                          </div>

                          <span className="w-12 text-right text-xs sm:text-sm font-black text-stone-900">
                            ₹{lineTotal}
                          </span>

                          <button
                            type="button"
                            onClick={() => onRemoveItem(item.product.id)}
                            className="text-stone-400 hover:text-red-600 p-1 cursor-pointer transition-colors"
                            aria-label="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Coupon / Savings Banner (Swiggy Style) */}
              <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-2xl p-3.5 border border-orange-200/70 flex items-center justify-between shadow-2xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-orange-500 text-white flex items-center justify-center font-black text-xs">
                    %
                  </div>
                  <div>
                    <span className="text-xs font-black text-stone-900 block leading-tight">
                      DIRECTFARM Applied
                    </span>
                    <span className="text-[11px] text-emerald-800 font-bold">
                      {language === 'hi' ? '₹40 की सीधी बचत' : language === 'mr' ? '₹४० ची थेट बचत' : 'You saved ₹40 on farm delivery!'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setCouponApplied(!couponApplied)}
                  className="text-xs font-black text-orange-600 uppercase hover:underline cursor-pointer"
                >
                  {couponApplied ? 'Remove' : 'Apply'}
                </button>
              </div>

              {/* Delivery Partner Tip (Swiggy Feature) */}
              <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-stone-900">
                    🚴‍♂️ {language === 'hi' ? 'डिलीवरी पार्टनर को टिप दें' : language === 'mr' ? 'डिलिव्हरी मित्राला टीप द्या' : 'Tip your delivery partner'}
                  </span>
                  <span className="text-[10px] text-stone-400">100% goes to partner</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[0, 10, 20, 30].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setTipAmount(amt)}
                      className={`py-1.5 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                        tipAmount === amt
                          ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                          : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200'
                      }`}
                    >
                      {amt === 0 ? 'No tip' : `₹${amt}`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs space-y-2.5">
                <span className="text-xs font-black text-stone-900 uppercase tracking-wide block">
                  {language === 'hi' ? 'भुगतान का विकल्प' : language === 'mr' ? 'पेमेंट पर्याय' : 'Payment Method'}
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'upi', label: 'UPI / GPay', emoji: '⚡' },
                    { id: 'cod', label: 'Cash on Del.', emoji: '💵' },
                    { id: 'card', label: 'Card / Net', emoji: '💳' },
                  ].map((pay) => (
                    <button
                      key={pay.id}
                      type="button"
                      onClick={() => setSelectedPaymentMethod(pay.id as any)}
                      className={`p-2 rounded-xl text-xs font-bold border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                        selectedPaymentMethod === pay.id
                          ? 'bg-emerald-50 border-emerald-600 text-emerald-950 font-black'
                          : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      <span>{pay.emoji}</span>
                      <span className="text-[11px]">{pay.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Bill Details (Swiggy Style Breakdown) */}
              <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs space-y-2 text-xs">
                <h4 className="font-black text-stone-900 text-xs uppercase tracking-wide pb-1 border-b border-stone-100">
                  {language === 'hi' ? 'बिल विवरण' : language === 'mr' ? 'बिल तपशील' : 'Bill Details'}
                </h4>
                
                <div className="flex justify-between text-stone-600">
                  <span>{t.subtotal}</span>
                  <span className="font-bold text-stone-900">₹{itemTotal}</span>
                </div>

                {couponApplied && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Farm direct discount</span>
                    <span className="font-bold">-₹{discountAmount}</span>
                  </div>
                )}

                <div className="flex justify-between text-stone-600">
                  <span className="flex items-center gap-1">
                    <span>Delivery partner fee</span>
                    <span className="text-[10px] text-stone-400">(Direct)</span>
                  </span>
                  <span className="font-black text-emerald-700 uppercase">FREE</span>
                </div>

                <div className="flex justify-between text-stone-600">
                  <span>Direct packing & quality check</span>
                  <span className="font-bold text-stone-900">₹{handlingCharges}</span>
                </div>

                {tipAmount > 0 && (
                  <div className="flex justify-between text-stone-600">
                    <span>Delivery partner tip</span>
                    <span className="font-bold text-stone-900">₹{tipAmount}</span>
                  </div>
                )}

                <div className="flex justify-between text-stone-600">
                  <span>Platform fee / Brokerage</span>
                  <span className="font-black text-emerald-700">₹0 (Zero Cut)</span>
                </div>

                <div className="pt-2 border-t border-stone-200 flex justify-between font-black text-sm text-stone-900">
                  <span>{t.totalAmount}</span>
                  <span className="text-emerald-900 text-base">₹{grandTotal}</span>
                </div>
              </div>

              {/* Cancellation Policy note */}
              <div className="p-3 bg-stone-100/80 rounded-xl text-[11px] text-stone-500 space-y-1">
                <p className="font-bold text-stone-700">Cancellation Policy</p>
                <p>100% refund if harvest quality differs or cancellation requested within 2 mins of order placement.</p>
              </div>
            </>
          )}

        </div>

        {/* Swiggy Orange Sticky Checkout CTA Bar */}
        {!isOrdered && cartItems.length > 0 && (
          <div className="p-4 bg-white border-t border-stone-200 shadow-lg">
            <button
              id="swiggy-pay-checkout-btn"
              type="button"
              onClick={handlePlaceOrder}
              className="w-full py-4 px-5 bg-[#FC8019] hover:bg-[#e46f10] active:scale-[0.99] text-white font-black text-base rounded-2xl shadow-md transition-all flex items-center justify-between cursor-pointer"
            >
              <div className="text-left">
                <span className="text-[11px] uppercase tracking-wider block opacity-90">
                  {selectedPaymentMethod.toUpperCase()} • {cartItems.length} {t.itemsCount}
                </span>
                <span className="text-lg leading-tight">
                  ₹{grandTotal}
                </span>
              </div>
              
              <div className="flex items-center gap-1 text-sm uppercase tracking-wider font-extrabold bg-black/15 px-3 py-1.5 rounded-xl">
                <span>{language === 'hi' ? 'ऑर्डर करें' : language === 'mr' ? 'ऑर्डर द्या' : 'Proceed to Pay'}</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </div>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
