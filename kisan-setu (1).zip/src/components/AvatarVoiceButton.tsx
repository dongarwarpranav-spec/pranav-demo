import React from 'react';
import { HumanAvatar } from './HumanAvatar';
import { Language } from '../types';
import { translations } from '../translations';

interface AvatarVoiceButtonProps {
  language: Language;
  isSpeaking: boolean;
  onToggle: () => void;
  className?: string;
  variant?: 'nav' | 'floating' | 'card';
}

export const AvatarVoiceButton: React.FC<AvatarVoiceButtonProps> = ({
  language,
  isSpeaking,
  onToggle,
  className = '',
  variant = 'nav',
}) => {
  const t = translations[language];

  if (variant === 'floating') {
    return (
      <button
        id="floating-voice-guide-btn"
        type="button"
        onClick={onToggle}
        title={isSpeaking ? t.stopListening : t.listenText}
        className={`fixed bottom-20 right-4 z-40 sm:bottom-6 sm:right-6 flex items-center gap-2.5 px-4 py-2.5 rounded-full shadow-lg border transition-all duration-200 cursor-pointer active:scale-95 ${
          isSpeaking
            ? 'bg-emerald-700 text-white border-emerald-800 ring-4 ring-emerald-300/60 animate-pulse'
            : 'bg-white hover:bg-amber-50/90 text-stone-900 border-amber-300/80 shadow-amber-900/10'
        } ${className}`}
      >
        <HumanAvatar size="md" isSpeaking={isSpeaking} />
        <div className="flex flex-col text-left">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-900/80 flex items-center gap-1">
            {t.appName}
            {isSpeaking && <span className="inline-block w-2 h-2 rounded-full bg-emerald-300 animate-ping" />}
          </span>
          <span className="text-sm font-bold leading-tight">
            {isSpeaking ? t.stopListening : t.listenText}
          </span>
        </div>
      </button>
    );
  }

  // Default 'nav' variant
  return (
    <button
      id="nav-voice-avatar-btn"
      type="button"
      onClick={onToggle}
      aria-label={isSpeaking ? t.stopListening : t.listenText}
      className={`group inline-flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all duration-200 cursor-pointer select-none active:scale-95 ${
        isSpeaking
          ? 'bg-emerald-50 text-emerald-800 border-emerald-500 shadow-sm ring-2 ring-emerald-300/60'
          : 'bg-amber-50/80 hover:bg-amber-100/90 text-stone-800 border-amber-200 shadow-xs'
      } ${className}`}
    >
      <HumanAvatar size="sm" isSpeaking={isSpeaking} />
      <span className="text-sm font-bold whitespace-nowrap text-emerald-900 group-hover:text-emerald-950">
        {isSpeaking ? t.speakingText : t.listenText}
      </span>
      {isSpeaking && (
        <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-200/80 text-emerald-900 font-semibold">
          {t.stopListening}
        </span>
      )}
    </button>
  );
};
