import React from 'react';

interface HumanAvatarProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isSpeaking?: boolean;
  className?: string;
}

export const HumanAvatar: React.FC<HumanAvatarProps> = ({
  size = 'md',
  isSpeaking = false,
  className = '',
}) => {
  const sizeMap = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-full bg-amber-100/90 border-2 ${
        isSpeaking ? 'border-emerald-600 shadow-md ring-4 ring-emerald-300/60' : 'border-amber-300/80 shadow-xs'
      } transition-all duration-300 ${sizeMap[size]} ${className}`}
    >
      {/* SVG Avatar: Friendly Indian Farmer with traditional safa/turban and gentle smile */}
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full rounded-full overflow-hidden"
        aria-hidden="true"
      >
        {/* Background circle */}
        <circle cx="50" cy="50" r="48" fill="#FEF3C7" />
        
        {/* Kurta & Shoulders */}
        <path
          d="M20 96 C22 72 32 68 50 68 C68 68 78 72 80 96 Z"
          fill="#15803D"
        />
        {/* Kurta collar & button line */}
        <path
          d="M45 68 L50 78 L55 68"
          stroke="#DC2626"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
        />
        <circle cx="50" cy="85" r="1.5" fill="#FEF08A" />

        {/* Neck */}
        <rect x="42" y="55" width="16" height="15" fill="#E09F67" rx="3" />

        {/* Face */}
        <ellipse cx="50" cy="46" rx="19" ry="21" fill="#F3B37C" />

        {/* Ears */}
        <circle cx="31" cy="46" r="4.5" fill="#E09F67" />
        <circle cx="69" cy="46" r="4.5" fill="#E09F67" />

        {/* Eyes (warm, friendly) */}
        <circle cx="43" cy="43" r="2.2" fill="#292524" />
        <circle cx="57" cy="43" r="2.2" fill="#292524" />
        <circle cx="44" cy="42" r="0.7" fill="#FFFFFF" />
        <circle cx="58" cy="42" r="0.7" fill="#FFFFFF" />

        {/* Eyebrows */}
        <path d="M39 39 Q43 37 47 39" stroke="#573824" strokeWidth="1.6" fill="none" strokeLinecap="round" />
        <path d="M53 39 Q57 37 61 39" stroke="#573824" strokeWidth="1.6" fill="none" strokeLinecap="round" />

        {/* Nose */}
        <path d="M50 43 L48 48 L52 48" stroke="#D97736" strokeWidth="1.5" fill="none" strokeLinecap="round" />

        {/* Friendly Mustache & Smile */}
        <path
          d="M40 51 Q46 54 50 51 Q54 54 60 51"
          stroke="#451A03"
          strokeWidth="2.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M45 54 Q50 58 55 54"
          stroke="#78350F"
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />

        {/* Tilak / Teeka */}
        <path d="M50 32 L50 38" stroke="#DC2626" strokeWidth="1.8" strokeLinecap="round" />
        <circle cx="50" cy="39.5" r="1.1" fill="#F59E0B" />

        {/* Turban / Safa (Traditional Indian Saffron/Mustard with layered folds) */}
        <path
          d="M28 34 C28 20 40 14 50 14 C62 14 72 20 72 34 C72 37 68 40 50 40 C32 40 28 37 28 34 Z"
          fill="#EA580C"
        />
        {/* Turban top crest & folds */}
        <path
          d="M34 26 C42 16 58 16 66 26"
          stroke="#FDBA74"
          strokeWidth="3.2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M30 32 C42 24 58 24 70 32"
          stroke="#F97316"
          strokeWidth="2.8"
          fill="none"
        />
        <path
          d="M46 12 Q50 6 54 12"
          fill="#EA580C"
        />
        {/* Small wheat ear badge on turban */}
        <path
          d="M50 20 L50 28 M48 22 L50 25 M52 22 L50 25 M48 25 L50 28 M52 25 L50 28"
          stroke="#FEF08A"
          strokeWidth="1.2"
          strokeLinecap="round"
        />
      </svg>

      {/* Speaking Soundwave / Indicator Badge */}
      {isSpeaking && (
        <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-600 border border-white items-center justify-center text-[8px] text-white">
            ♪
          </span>
        </span>
      )}
    </div>
  );
};
